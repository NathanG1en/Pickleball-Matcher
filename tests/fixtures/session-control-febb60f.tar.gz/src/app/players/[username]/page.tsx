import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import {
  getActionRepository,
  getActivePlayerAccountId,
} from "@/app/actions/action-context";
import {
  PlayerProfileHeader,
} from "@/components/players/player-profile-controls";
import { ScoreHistoryChart } from "@/components/players/score-history-chart";
import { SynergyExplainerButton } from "@/components/players/synergy-explainer";
import { StatCard } from "@/components/ui";
import { GlobeIcon, LockIcon, ChevronRightIcon, UsersIcon } from "@/components/ui/icons";
import { eloToDupr, formatDupr, getSkillTier } from "@/lib/domain/rating-display";
import { ClientDate } from "@/components/ui/client-date-time";
import { canViewPortion, parseProfileVisibilitySettings } from "@/lib/privacy/profile-visibility";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ username: string }>;
}) {
  const { username } = await params;
  const decoded = decodeURIComponent(username).replace(/^@/, "");
  return {
    title: `@${decoded} · Profile | Pickleball Matcher`,
  };
}

export default async function PlayerPublicProfilePage({
  params,
}: {
  params: Promise<{ username: string }>;
}) {
  const { username: rawUsername } = await params;
  const username = decodeURIComponent(rawUsername).replace(/^@/, "").trim().toLowerCase();

  const repository = getActionRepository();
  const targetAccount = await repository.getPlayerAccountByUsername(username);

  if (!targetAccount) {
    notFound();
  }

  const viewerAccountId = await getActivePlayerAccountId();
  if (!viewerAccountId) {
    redirect(`/player-login?next=${encodeURIComponent(`/players/${rawUsername}`)}`);
  }
  const isOwner = Boolean(viewerAccountId === targetAccount.id);

  const [history, groups, bestPartner, viewerSynergy, viewerGroups] = await Promise.all([
    repository.listPlayerSessionHistory(targetAccount.id),
    repository.listAccountGroups(targetAccount.id),
    repository.getBestPartner(targetAccount.id),
    viewerAccountId && viewerAccountId !== targetAccount.id
      ? repository.getPairSynergy(viewerAccountId, targetAccount.id)
      : Promise.resolve(null),
    viewerAccountId && viewerAccountId !== targetAccount.id
      ? repository.listAccountGroups(viewerAccountId)
      : Promise.resolve([]),
  ]);

  const targetGroupIds = new Set(groups.map((g) => g.id));
  const isGroupMember = Boolean(viewerGroups?.some((g) => targetGroupIds.has(g.id)));

  const visibilitySettings = parseProfileVisibilitySettings(
    targetAccount.visibilitySettings,
    targetAccount.isPublic ?? true,
  );

  const canViewProfile = isOwner || canViewPortion({
    portion: "profile",
    viewerAccountId,
    targetAccount,
    isGroupMember,
  });

  if (!canViewProfile) {
    const isRestrictedByGroup = visibilitySettings.profile === "group_members" && targetAccount.isPublic !== false;
    return (
      <main className="min-h-screen p-4 sm:p-6 lg:p-8">
        <section className="mx-auto max-w-xl md:max-w-2xl space-y-5">
          <header className="rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5 lg:p-6">
            <div className="space-y-1">
              <h1 className="font-display text-3xl font-black uppercase truncate text-black">
                {targetAccount.name}
              </h1>
              <p className="text-sm font-bold text-neutral-600">
                @{targetAccount.username}
              </p>
            </div>
            <div className="mt-3 flex items-center gap-1.5">
              <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-black bg-neutral-200 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-black">
                <LockIcon className="h-2.5 w-2.5 shrink-0" />
                <span>{isRestrictedByGroup ? "Restricted" : "Private"}</span>
              </span>
            </div>
          </header>

          <section className="rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-6 text-center">
            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl border-2 border-black bg-neutral-100">
              <LockIcon className="h-6 w-6 text-neutral-700" />
            </div>
            <h2 className="font-display text-xl font-black uppercase text-black">
              {isRestrictedByGroup ? "This Profile is Restricted" : "This Profile is Private"}
            </h2>
            <p className="mt-1 text-xs font-bold text-neutral-600 max-w-sm mx-auto">
              {isRestrictedByGroup
                ? `@${targetAccount.username} only shares their profile with members of their groups.`
                : `@${targetAccount.username} has chosen to keep their stats, match history, and rating private.`}
            </p>
          </section>
        </section>
      </main>
    );
  }

  const canViewRatingStats = isOwner || canViewPortion({
    portion: "ratingStats",
    viewerAccountId,
    targetAccount,
    isGroupMember,
  });

  const canViewChemistry = isOwner || canViewPortion({
    portion: "chemistry",
    viewerAccountId,
    targetAccount,
    isGroupMember,
  });

  const canViewGroupMemberships = isOwner || canViewPortion({
    portion: "groups",
    viewerAccountId,
    targetAccount,
    isGroupMember,
  });

  const canViewActivities = isOwner || canViewPortion({
    portion: "activities",
    viewerAccountId,
    targetAccount,
    isGroupMember,
  });

  const wins = history.reduce((total, session) => total + session.wins, 0);
  const losses = history.reduce((total, session) => total + session.losses, 0);
  const currentRating = targetAccount.rating ?? targetAccount.initialRating;

  return (
    <main className="min-h-screen p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-xl md:max-w-2xl lg:max-w-6xl xl:max-w-7xl space-y-5">
        <header className="rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5 lg:p-6">
          {isOwner ? (
            <PlayerProfileHeader
              initialName={targetAccount.name}
              initialUsername={targetAccount.username}
              initialGender={targetAccount.gender}
              initialEmail={targetAccount.email ?? undefined}
              initialEmailVerified={targetAccount.emailVerified ?? false}
              hasPassword={Boolean(targetAccount.passwordHash)}
              skillLevel={targetAccount.skillLevel}
              currentRating={currentRating}
              initialIsPublic={targetAccount.isPublic ?? true}
              initialVisibilitySettings={visibilitySettings}
            />
          ) : (
            <>
              <div className="min-w-0 flex-1 space-y-2">
                <h1 className="font-display text-3xl font-black uppercase truncate text-black">
                  {targetAccount.name}
                </h1>
              <p className="text-sm font-bold text-neutral-600">
                @{targetAccount.username}
              </p>
              {targetAccount.gender && (
                <p className="text-xs font-bold uppercase text-neutral-600">
                  {targetAccount.gender === "male" ? "Male" : "Female"}
                </p>
              )}
              <div className="flex items-center gap-2 pt-0.5">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full border-2 border-black ${
                    visibilitySettings.profile === "everyone"
                      ? "bg-[#ccff00]"
                      : visibilitySettings.profile === "group_members"
                      ? "bg-[#e0e7ff]"
                      : "bg-neutral-200"
                  } px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-black`}
                >
                  {visibilitySettings.profile === "everyone" ? (
                    <>
                      <GlobeIcon className="h-2.5 w-2.5 shrink-0" />
                      <span>Everyone</span>
                    </>
                  ) : visibilitySettings.profile === "group_members" ? (
                    <>
                      <UsersIcon className="h-2.5 w-2.5 shrink-0" />
                      <span>Group Members Only</span>
                    </>
                  ) : (
                    <>
                      <LockIcon className="h-2.5 w-2.5 shrink-0" />
                      <span>Only You</span>
                    </>
                  )}
                </span>
              </div>
              <div className="pt-2 border-t-2 border-neutral-100">
                {canViewRatingStats ? (
                  <p className="text-xs font-bold uppercase text-neutral-600">
                    {getSkillTier(eloToDupr(currentRating)).name} · current rating {formatDupr(currentRating)}
                  </p>
                ) : (
                  <p className="inline-flex items-center gap-1.5 text-xs font-bold uppercase text-neutral-500">
                    <LockIcon className="h-3 w-3" />
                    <span>Rating &amp; stats are private</span>
                  </p>
                )}
              </div>
            </div>
            </>
          )}
        </header>

        {/* Top Row: Chemistry Spotlight & Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          {/* Chemistry Spotlight */}
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col justify-center">
            {!canViewChemistry ? (
              <section className="h-full rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5 flex flex-col justify-center">
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-[10px] font-black uppercase tracking-wider text-neutral-500">Chemistry Spotlight</p>
                    <LockIcon className="h-3 w-3 text-neutral-500" />
                  </div>
                  <h2 className="font-display text-xl font-black uppercase text-neutral-800">Chemistry Private</h2>
                  <p className="mt-1 text-xs font-bold text-neutral-600">
                    @{targetAccount.username} has chosen to keep their partner chemistry private.
                  </p>
                </div>
              </section>
            ) : bestPartner ? (
              <section className="h-full rounded-3xl border-[3px] border-black bg-gradient-to-br from-[#ccff00] to-[#fde047] p-5 flex flex-col justify-center">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <p className="text-[10px] font-black uppercase tracking-wider text-neutral-800">Chemistry Spotlight</p>
                      <SynergyExplainerButton />
                    </div>
                    <h2 className="font-display text-2xl font-black uppercase">Best Partner</h2>
                    <p className="text-sm font-bold text-neutral-800">
                      <Link
                        href={`/players/${encodeURIComponent(bestPartner.username)}`}
                        className="underline hover:text-black"
                      >
                        @{bestPartner.username}
                      </Link>
                    </p>
                  </div>
                  <div className="text-right">
                    {(() => {
                      const raw = bestPartner.synergyScore;
                      const score = Math.round(raw > -1 && raw < 1 && raw !== 0 ? raw * 100 : raw);
                      const sign = score > 0 ? `+${score}%` : `${score}%`;
                      return (
                        <span className={`inline-block rounded-xl border-2 border-black px-3 py-1 font-display text-xl font-black ${
                          score > 0
                            ? "bg-emerald-100 text-emerald-950"
                            : score < 0
                            ? "bg-rose-100 text-rose-950"
                            : "bg-white text-black"
                        }`}>
                          {sign} Synergy
                        </span>
                      );
                    })()}
                    <p className="mt-1 text-[11px] font-bold text-neutral-800">
                      {bestPartner.matchesPlayed} {bestPartner.matchesPlayed === 1 ? "match" : "matches"} together
                    </p>
                  </div>
                </div>
              </section>
            ) : (
              <section className="h-full rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5 flex flex-col justify-center">
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-[10px] font-black uppercase tracking-wider text-neutral-500">Chemistry Spotlight</p>
                    <SynergyExplainerButton />
                  </div>
                  <h2 className="font-display text-xl font-black uppercase text-neutral-800">No Partner Yet</h2>
                  <p className="mt-1 text-xs font-bold text-neutral-600">
                    {isOwner
                      ? "Chemistry tracks partners who have player accounts. Play doubles with them to see who you click with."
                      : "Chemistry shows up after doubles games with partners who have player accounts."}
                  </p>
                </div>
              </section>
            )}
          </div>

          {/* Sessions / Wins / Losses */}
          <div className="lg:col-span-5 xl:col-span-4 flex flex-col justify-center">
            {canViewRatingStats ? (
              <section className="grid grid-cols-3 gap-3 text-center h-full items-stretch">
                <StatCard label="Sessions" value={new Set(history.map((item) => item.sessionId)).size} className="flex flex-col justify-center" />
                <StatCard label="Wins" value={wins} className="flex flex-col justify-center" />
                <StatCard label="Losses" value={losses} className="flex flex-col justify-center" />
              </section>
            ) : (
              <section className="rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5 text-center flex flex-col justify-center h-full items-center">
                <LockIcon className="h-5 w-5 text-neutral-500 mb-1" />
                <h2 className="font-display text-lg font-black uppercase text-neutral-800">Stats Private</h2>
                <p className="text-xs font-bold text-neutral-600">Performance stats are hidden by player.</p>
              </section>
            )}
          </div>
        </div>

        {/* Bottom Row: Groups & Everything Else */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Groups: 1st on mobile, right column (4-5 cols) on desktop */}
          <div className="space-y-5 lg:col-span-5 xl:col-span-4 order-1 lg:order-2">
            {!canViewGroupMemberships ? (
              <section className="rounded-3xl border-[3px] border-black bg-neutral-100 p-5">
                <div className="mb-2 flex items-center gap-2">
                  <LockIcon className="h-4 w-4 text-neutral-500" />
                  <h2 className="font-display text-2xl font-black uppercase text-neutral-800">Groups</h2>
                </div>
                <p className="text-sm font-bold text-neutral-600">
                  @{targetAccount.username} has chosen to keep their group memberships private.
                </p>
              </section>
            ) : (
              <section className="rounded-3xl border-[3px] border-black bg-[#ccff00] p-5">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <h2 className="font-display text-2xl font-black uppercase">
                    {isOwner ? "My Groups" : "Groups"}
                  </h2>
                  {isOwner && (
                    <div className="flex gap-2">
                      <Link href="/setup" className="rounded-xl border-2 border-black bg-[#fde047] px-3 py-2 text-xs font-black uppercase shadow-[2px_2px_0px_0px_#000] hover:shadow-[3px_3px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all">Create</Link>
                      <Link href="/players/groups" className="rounded-xl border-2 border-black bg-[#FFFDF7] px-3 py-2 text-xs font-black uppercase shadow-[2px_2px_0px_0px_#000] hover:shadow-[3px_3px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all">Find groups</Link>
                    </div>
                  )}
                </div>
                {groups.length === 0 ? (
                  <p className="text-sm font-bold">
                    {isOwner ? "You haven't joined any groups yet." : "No groups joined yet."}
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {groups.map((group) => (
                      <li key={group.id}>
                        <Link
                          href={`/g/${group.id}`}
                          aria-label={`Go to ${group.name}`}
                          title={`Go to ${group.name}`}
                          className="group flex items-center justify-between gap-3 rounded-xl border-2 border-black bg-[#FFFDF7] px-3 py-2 text-sm font-bold shadow-[2px_2px_0px_0px_#000] hover:shadow-[3px_3px_0px_0px_#000] hover:bg-neutral-50 active:translate-x-0.5 active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                        >
                          <div className="min-w-0 flex-1">
                            <span className="block truncate font-black text-black group-hover:underline">{group.name}</span>
                            <span className="text-xs font-semibold text-neutral-600">{group.playerCount} {group.playerCount === 1 ? "player" : "players"}</span>
                          </div>
                          <div className="p-1.5 text-black group-hover:translate-x-0.5 transition-transform shrink-0">
                            <ChevronRightIcon className="w-5 h-5 stroke-[2.5]" />
                          </div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            )}
          </div>

          {/* Everything Else (Mutual Chemistry, Score History Chart & Past Sessions): 2nd on mobile, left column (7-8 cols) on desktop */}
          <div className="space-y-5 lg:col-span-7 xl:col-span-8 order-2 lg:order-1">
            {canViewChemistry && viewerSynergy && viewerSynergy.matchesPlayed > 0 && (
              <section className="rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-wider text-neutral-500">Mutual Chemistry</p>
                    <h2 className="font-display text-xl font-black uppercase text-neutral-800">Partner Chemistry With You</h2>
                    <p className="mt-1 text-xs font-bold text-neutral-600">
                      {viewerSynergy.wins} wins in {viewerSynergy.matchesPlayed} matches together
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-block rounded-xl border-2 border-black bg-[#ccff00] px-3 py-1 font-display text-xl font-black">
                      {(() => {
                        const raw = viewerSynergy.synergyScore;
                        const score = Math.round(raw > -1 && raw < 1 && raw !== 0 ? raw * 100 : raw);
                        return score > 0 ? `+${score}%` : `${score}%`;
                      })()}
                    </span>
                  </div>
                </div>
              </section>
            )}

            {canViewRatingStats && (
              <section className="rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5">
                <ScoreHistoryChart history={history} startingRating={targetAccount.initialRating} />
              </section>
            )}

            {!canViewActivities ? (
              <section className="space-y-3 rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5">
                <div className="flex items-center gap-2">
                  <LockIcon className="h-4 w-4 text-neutral-500" />
                  <h2 className="font-display text-2xl font-black uppercase text-neutral-800">Past Sessions</h2>
                </div>
                <p className="text-sm font-bold text-neutral-600">
                  @{targetAccount.username} has chosen to keep their session history private.
                </p>
              </section>
            ) : (
              <section className="space-y-3 rounded-3xl border-[3px] border-black bg-[#FFFDF7] p-5">
                <h2 className="font-display text-2xl font-black uppercase">Past Sessions</h2>
                {history.length === 0 ? (
                  <p className="text-sm font-bold text-neutral-600">No sessions played yet.</p>
                ) : (
                  history.map((item) => {
                    return (
                      <article
                        key={`${item.groupId}-${item.sessionId}`}
                        data-testid={`player-session-${item.sessionId}`}
                        className="flex items-center justify-between gap-3 border-t-2 border-neutral-100 py-3"
                      >
                        <div>
                          <h3 className="font-black text-black">
                            {item.sessionName ? `${item.sessionName} · ` : null}
                            <ClientDate date={item.startedAt} options={{ month: "short", day: "numeric", year: "numeric" }} />
                          </h3>
                          <p className="text-xs font-bold text-neutral-600">
                            {item.groupName}
                            {item.type === "open_play" ? " (Open Play)" : ""}
                            {" · "}
                            {item.wins}W – {item.losses}L
                          </p>
                        </div>
                        {isOwner && (
                          <Link
                            href={`/g/${item.groupId}/sessions/${item.sessionId}?from=profile`}
                            aria-label="Go to session"
                            title="Go to session"
                            className="p-1.5 text-black hover:translate-x-0.5 transition-transform cursor-pointer shrink-0"
                          >
                            <span className="sr-only">Go to session</span>
                            <ChevronRightIcon className="w-5 h-5 stroke-[2.5]" />
                          </Link>
                        )}
                      </article>
                    );
                  })
                )}
              </section>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

