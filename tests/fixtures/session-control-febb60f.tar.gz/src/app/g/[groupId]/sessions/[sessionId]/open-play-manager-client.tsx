"use client";

import React, { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { BackButton } from "@/components/groups/back-button";
import { Badge } from "@/components/ui/badge";
import { Toast } from "@/components/ui/toast";
import { CustomDropdown } from "@/components/ui/custom-dropdown";
import { PickleCelebration, isPickleScore } from "@/components/results/pickle-celebration";
import { SessionSignOff } from "@/components/sessions/session-signoff";
import { SessionNameEditor } from "@/components/sessions/session-name-editor";
import { SessionOptionsMenu } from "@/components/sessions/session-options-menu";
import { FilterablePlayerSelect } from "@/components/groups/filterable-player-select";
import { formatDupr } from "@/lib/domain/rating-display";
import { SessionHighlights } from "@/components/sessions/session-highlights";
import {
  sortPlayersWithPinned,
  usePinnedPlayerIds,
} from "@/lib/storage/pinned-players";
import { markSessionEnded } from "@/lib/animations/session-signoff";
import { useRouter } from "next/navigation";
import {
  addOpenPlayGuestAction,
  addOpenPlayPlayerAction,
  deleteOpenPlayGameAction,
  endOpenPlaySessionAction,
  joinOpenPlaySessionAction,
  removeOpenPlayPlayerAction,
  submitOpenPlayGameAction,
  syncOpenPlaySessionAction,
  updateOpenPlayGameAction,
} from "@/app/actions/open-play";
import { createIdempotencyKey } from "@/lib/utils/idempotency";
import type {
  AttendanceRecord,
  MatchPlayerRecord,
  MatchRecord,
  PlayerRecord,
  SessionRecord,
  StartedRoundRecord,
} from "@/lib/domain/types";

import { RatingSlider, RATING_TICKS, type RatingTick } from "@/components/ui/rating-slider";
import { ClientDate, ClientTime } from "@/components/ui/client-date-time";
import { formatSessionDate } from "@/lib/utils/date";
import { useHydrated } from "@/lib/utils/hydration";
import {
  ArrowLeftRightIcon,
  ChevronDownIcon,
  CrownIcon,
  RotateCwIcon,
  UserPlusIcon,
  UsersIcon,
  XIcon,
} from "@/components/ui/icons";
import {
  DISMISS_GUEST_DESC_STORAGE_KEY,
  getGuestDescDismissedSnapshot,
  subscribeGuestDescDismissed,
} from "@/components/groups/group-organizers-panel";
export { RATING_TICKS, type RatingTick };

export interface OpenPlayManagerClientProps {
  readonly groupId: string;
  readonly groupName?: string;
  readonly session: SessionRecord;
  readonly players: readonly PlayerRecord[];
  readonly attendance?: readonly AttendanceRecord[];
  readonly startedRounds: readonly StartedRoundRecord[];
  readonly isOrganizer?: boolean;
  readonly isHost?: boolean;
  readonly isMember?: boolean;
  readonly currentViewerPlayerId?: string | null;
  readonly isFromProfile?: boolean;
  readonly initialMatchType?: "doubles" | "singles";
}

export function OpenPlayManagerClient({
  groupId,
  groupName,
  session,
  players,
  attendance = [],
  startedRounds,
  isOrganizer = false,
  isHost = false,
  isMember = false,
  currentViewerPlayerId = null,
  isFromProfile = false,
  initialMatchType = "doubles",
}: OpenPlayManagerClientProps) {
  const router = useRouter();
  const isHydrated = useHydrated();

  // Local state for instant UI updates without waiting for router.refresh()
  const [prevSession, setPrevSession] = useState(session);
  const [currentSession, setCurrentSession] = useState(session);
  if (session !== prevSession) {
    setPrevSession(session);
    setCurrentSession(session);
  }
  const [sessionName, setSessionName] = useState(session.name ?? null);
  const formattedDate = isHydrated ? formatSessionDate(session.startedAt) : "";
  const initialSessionName = sessionName || formattedDate;

  const [prevPlayers, setPrevPlayers] = useState(players);
  const [localPlayers, setLocalPlayers] = useState<readonly PlayerRecord[]>(players);
  if (players !== prevPlayers) {
    setPrevPlayers(players);
    const serverIds = new Set(players.map((p) => p.id));
    const pendingLocal = localPlayers.filter((p) => !serverIds.has(p.id));
    setLocalPlayers([...players, ...pendingLocal]);
  }

  const [prevAttendance, setPrevAttendance] = useState(attendance);
  const [localAttendance, setLocalAttendance] = useState<readonly AttendanceRecord[]>(attendance);
  if (attendance !== prevAttendance) {
    setPrevAttendance(attendance);
    const serverPids = new Set(attendance.map((a) => a.playerId));
    const pendingLocal = localAttendance.filter((a) => !serverPids.has(a.playerId));
    setLocalAttendance([...attendance, ...pendingLocal]);
  }

  // Maps
  const playerMap = useMemo(() => new Map<string, PlayerRecord>(localPlayers.map((p) => [p.id, p])), [localPlayers]);

  // Checked-in players
  const presentAttendance = localAttendance.filter((a) => a.leftRound === null);
  const presentPlayerIds = useMemo(() => new Set(presentAttendance.map((a) => a.playerId)), [presentAttendance]);
  const checkedInPlayers = useMemo(
    () =>
      localPlayers
        .filter((p) => presentPlayerIds.has(p.id) && p.active)
        .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" })),
    [localPlayers, presentPlayerIds],
  );

  const pinnedPlayerIds = usePinnedPlayerIds(groupId);

  // Group players not yet checked in
  const availableRosterPlayers = useMemo(
    () =>
      sortPlayersWithPinned(
        localPlayers.filter((p) => !presentPlayerIds.has(p.id) && p.active),
        pinnedPlayerIds,
      ),
    [localPlayers, presentPlayerIds, pinnedPlayerIds],
  );

  const isViewerCheckedIn = Boolean(
    currentViewerPlayerId && presentPlayerIds.has(currentViewerPlayerId),
  );

  const isSessionActive = currentSession.status === "active";
  const canManage = Boolean(isOrganizer || isHost);
  const canEditOrDelete = isSessionActive ? (canManage || isMember) : canManage;

  const selectableGamePlayers = checkedInPlayers;

  const [prevStartedRounds, setPrevStartedRounds] = useState(startedRounds);
  const [localStartedRounds, setLocalStartedRounds] = useState<readonly StartedRoundRecord[]>(startedRounds);
  if (startedRounds !== prevStartedRounds) {
    setPrevStartedRounds(startedRounds);
    const serverMatchIds = new Set(startedRounds.flatMap((sr) => sr.matches.map((m) => m.id)));
    const pendingLocalMatches = localStartedRounds.flatMap((sr) =>
      sr.matches.filter((m) => !serverMatchIds.has(m.id))
    );
    const pendingLocalMatchPlayers = localStartedRounds.flatMap((sr) =>
      sr.matchPlayers.filter((mp) => !serverMatchIds.has(mp.matchId))
    );
    if (startedRounds.length > 0) {
      setLocalStartedRounds(
        startedRounds.map((sr, idx) =>
          idx === 0
            ? {
                ...sr,
                matches: [...sr.matches, ...pendingLocalMatches],
                matchPlayers: [...sr.matchPlayers, ...pendingLocalMatchPlayers],
              }
            : sr
        )
      );
    } else if (pendingLocalMatches.length > 0) {
      setLocalStartedRounds(localStartedRounds);
    } else {
      setLocalStartedRounds(startedRounds);
    }
  }

  const [deletedMatchIds, setDeletedMatchIds] = useState<Set<string>>(() => new Set());

  // Games list from started rounds (excludes deleted/cancelled games)
  const allMatches = useMemo(() => localStartedRounds.flatMap((sr) =>
    sr.matches
      .filter((m) => m.status !== "cancelled" && !deletedMatchIds.has(m.id))
      .map((m) => {
        const t1MPs = sr.matchPlayers.filter((mp) => mp.matchId === m.id && mp.team === 1);
        const t2MPs = sr.matchPlayers.filter((mp) => mp.matchId === m.id && mp.team === 2);
        const t1 = t1MPs.map((mp) => playerMap.get(mp.playerId)?.name ?? mp.playerId);
        const t2 = t2MPs.map((mp) => playerMap.get(mp.playerId)?.name ?? mp.playerId);
        return {
          ...m,
          team1PlayerIds: t1MPs.map((mp) => mp.playerId),
          team2PlayerIds: t2MPs.map((mp) => mp.playerId),
          team1Names: t1,
          team2Names: t2,
        };
      }),
  ), [localStartedRounds, playerMap, deletedMatchIds]);

  const completedMatches = useMemo(
    () => allMatches.filter((m) => m.status === "completed"),
    [allMatches],
  );

  const openPlayPlayerStats = useMemo(() => {
    const participantIds = new Set<string>();
    for (const p of checkedInPlayers) {
      participantIds.add(p.id);
    }
    for (const m of completedMatches) {
      for (const id of [...m.team1PlayerIds, ...m.team2PlayerIds]) {
        participantIds.add(id);
      }
    }

    return Array.from(participantIds)
      .map((pId) => {
        const player = playerMap.get(pId);
        let gamesPlayed = 0;
        let wins = 0;
        let losses = 0;

        for (const m of completedMatches) {
          if (m.team1Score === null || m.team2Score === null) continue;
          const isT1 = m.team1PlayerIds.includes(pId);
          const isT2 = m.team2PlayerIds.includes(pId);
          if (!isT1 && !isT2) continue;
          gamesPlayed += 1;
          if (isT1 && m.team1Score > m.team2Score) wins += 1;
          else if (isT2 && m.team2Score > m.team1Score) wins += 1;
          else losses += 1;
        }

        const winRate = gamesPlayed > 0 ? Math.round((wins / gamesPlayed) * 100) : 0;
        return {
          id: pId,
          name: player?.name ?? pId,
          gamesPlayed,
          wins,
          losses,
          winRate,
        };
      })
      .sort((a, b) => b.wins - a.wins || b.winRate - a.winRate || a.name.localeCompare(b.name));
  }, [checkedInPlayers, completedMatches, playerMap]);

  const viewerSessionStats = currentViewerPlayerId
    ? openPlayPlayerStats.find((stat) => stat.id === currentViewerPlayerId) ?? {
        id: currentViewerPlayerId,
        name: playerMap.get(currentViewerPlayerId)?.name ?? "You",
        gamesPlayed: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
      }
    : null;

  let durationFormatted: string | null = null;
  if (session.endedAt && session.startedAt) {
    const startMs = new Date(session.startedAt).getTime();
    const endMs = new Date(session.endedAt).getTime();
    const diffMinutes = Math.max(1, Math.round((endMs - startMs) / (1000 * 60)));
    const hours = Math.floor(diffMinutes / 60);
    const mins = diffMinutes % 60;
    if (hours > 0) {
      durationFormatted = `${hours}h ${mins}m`;
    } else {
      durationFormatted = `${mins}m`;
    }
  }

  // User/client-local match submission state
  const isViewerPresent = Boolean(
    currentViewerPlayerId && presentPlayerIds.has(currentViewerPlayerId),
  );

  const [matchType, setMatchType] = useState<"doubles" | "singles">(initialMatchType);
  const [t1p1, setT1p1] = useState(() => (isViewerPresent && currentViewerPlayerId ? currentViewerPlayerId : ""));
  const [t1p2, setT1p2] = useState("");
  const [t2p1, setT2p1] = useState("");
  const [t2p2, setT2p2] = useState("");
  const [t1Score, setT1Score] = useState("");
  const [t2Score, setT2Score] = useState("");
  const [rotateBase, setRotateBase] = useState<[string, string, string, string] | null>(null);

  // Local record of the most recent game submitted by this user/device in this session
  const [lastSubmittedGame, setLastSubmittedGame] = useState<{
    matchType: "doubles" | "singles";
    team1PlayerIds: string[];
    team2PlayerIds: string[];
  } | null>(null);

  const parsedT1 = parseInt(t1Score, 10);
  const parsedT2 = parseInt(t2Score, 10);
  const isT1Winner = !isNaN(parsedT1) && (isNaN(parsedT2) ? parsedT1 >= 11 : parsedT1 > parsedT2);
  const isT2Winner = !isNaN(parsedT2) && (isNaN(parsedT1) ? parsedT2 >= 11 : parsedT2 > parsedT1);

  const handleSelectWinner = (team: 1 | 2) => {
    if (team === 1) {
      setT1Score("11");
      const curT2 = parseInt(t2Score, 10);
      if (curT2 >= 11) {
        setT2Score("");
      }
    } else {
      setT2Score("11");
      const curT1 = parseInt(t1Score, 10);
      if (curT1 >= 11) {
        setT1Score("");
      }
    }
  };

  // Automatically populate viewer as first player upon joining if not set
  const [hasSetInitialViewer, setHasSetInitialViewer] = useState(() =>
    Boolean(currentViewerPlayerId && presentPlayerIds.has(currentViewerPlayerId)),
  );
  if (!hasSetInitialViewer && currentViewerPlayerId && presentPlayerIds.has(currentViewerPlayerId)) {
    setHasSetInitialViewer(true);
    if (!t1p1) {
      setT1p1(currentViewerPlayerId);
    }
  }

  // Check if a player is selected in another slot in the current match
  const isPlayerSelectedElsewhere = (
    playerId: string,
    currentSlot: "t1p1" | "t1p2" | "t2p1" | "t2p2",
  ) => {
    if (!playerId) return false;
    if (currentSlot !== "t1p1" && t1p1 === playerId) return true;
    if (currentSlot !== "t1p2" && matchType === "doubles" && t1p2 === playerId) return true;
    if (currentSlot !== "t2p1" && t2p1 === playerId) return true;
    if (currentSlot !== "t2p2" && matchType === "doubles" && t2p2 === playerId) return true;
    return false;
  };

  const handleSelectGamePlayer = (
    slot: "t1p1" | "t1p2" | "t2p1" | "t2p2",
    playerId: string,
  ) => {
    if (playerId) {
      if (slot !== "t1p1" && t1p1 === playerId) setT1p1("");
      if (slot !== "t1p2" && t1p2 === playerId) setT1p2("");
      if (slot !== "t2p1" && t2p1 === playerId) setT2p1("");
      if (slot !== "t2p2" && t2p2 === playerId) setT2p2("");
    }
    if (slot === "t1p1") setT1p1(playerId);
    else if (slot === "t1p2") setT1p2(playerId);
    else if (slot === "t2p1") setT2p1(playerId);
    else if (slot === "t2p2") setT2p2(playerId);
  };

  const getSlotOptions = (slot: "t1p1" | "t1p2" | "t2p1" | "t2p2") => {
    return selectableGamePlayers.map((p) => ({
      id: p.id,
      name: p.name,
      selectedElsewhere: isPlayerSelectedElsewhere(p.id, slot),
    }));
  };

  // Drawer & Tab state
  const [isPlayersDrawerOpen, setIsPlayersDrawerOpen] = useState(true);
  const [addPlayerTab, setAddPlayerTab] = useState<"member" | "guest">(() =>
    availableRosterPlayers.length > 0 ? "member" : "guest"
  );

  // Guest / Add player state
  const [guestName, setGuestName] = useState("");
  const [guestGender, setGuestGender] = useState<"male" | "female">("male");
  const [guestRating, setGuestRating] = useState(3.5);

  const isGuestDescDismissed = useSyncExternalStore(
    subscribeGuestDescDismissed,
    getGuestDescDismissedSnapshot,
    getGuestDescDismissedSnapshot
  );

  const handleDismissGuestDesc = () => {
    try {
      if (typeof window !== "undefined") {
        window.sessionStorage.setItem(DISMISS_GUEST_DESC_STORAGE_KEY, "true");
        window.dispatchEvent(new Event("pickleball_guest_desc_dismissed"));
      }
    } catch {
      // sessionStorage unavailable
    }
  };

  const rosterPlayerOptions = useMemo(
    () =>
      availableRosterPlayers.map((p) => ({
        id: p.id,
        name: `${p.name} (${formatDupr(p.rating)})`,
        isPinned: pinnedPlayerIds.has(p.id),
      })),
    [availableRosterPlayers, pinnedPlayerIds],
  );

  // Loading & feedback states
  const [pickledGameId, setPickledGameId] = useState<string | null>(null);
  const [isSubmittingGame, setIsSubmittingGame] = useState(false);
  const [isAddingGuest, setIsAddingGuest] = useState(false);
  const [isAddingPlayer, setIsAddingPlayer] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const [isEnding, setIsEnding] = useState(false);
  const [justEndedSession, setJustEndedSession] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const toastTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [guestAddedPopup, setGuestAddedPopup] = useState<string | null>(null);
  const guestPopupTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (toastTimeoutRef.current !== null) clearTimeout(toastTimeoutRef.current);
    if (guestPopupTimeoutRef.current !== null) clearTimeout(guestPopupTimeoutRef.current);
  }, []);

  // Live Sync polling effect to keep session state in sync across devices
  useEffect(() => {
    if (!isSessionActive) return;

    let isSubscribed = true;

    const performSync = async () => {
      if (typeof document !== "undefined" && document.hidden) return;
      try {
        const res = await syncOpenPlaySessionAction({ groupId, sessionId: session.id });
        if (res.ok && isSubscribed) {
          const { session: serverSession, players: serverPlayers, attendance: serverAttendance, startedRounds: serverStartedRounds } = res.data;

          setLocalPlayers((prev) => {
            const serverIds = new Set(serverPlayers.map((p) => p.id));
            const pendingLocal = prev.filter((p) => !serverIds.has(p.id));
            return [...serverPlayers, ...pendingLocal];
          });

          setLocalAttendance((prev) => {
            const serverPids = new Set(serverAttendance.map((a) => a.playerId));
            const pendingLocal = prev.filter((a) => !serverPids.has(a.playerId));
            return [...serverAttendance, ...pendingLocal];
          });

          setLocalStartedRounds((prev) => {
            const serverMatchIds = new Set(serverStartedRounds.flatMap((sr) => sr.matches.map((m) => m.id)));
            const pendingLocalMatches = prev.flatMap((sr) =>
              sr.matches.filter((m) => !serverMatchIds.has(m.id) && m.id.startsWith("opt_"))
            );
            const pendingLocalMatchPlayers = prev.flatMap((sr) =>
              sr.matchPlayers.filter((mp) => !serverMatchIds.has(mp.matchId) && mp.matchId.startsWith("opt_"))
            );
            if (serverStartedRounds.length > 0) {
              return serverStartedRounds.map((sr, idx) =>
                idx === 0
                  ? {
                      ...sr,
                      matches: [...sr.matches, ...pendingLocalMatches],
                      matchPlayers: [...sr.matchPlayers, ...pendingLocalMatchPlayers],
                    }
                  : sr
              );
            }
            return serverStartedRounds;
          });

          if (serverSession.status === "completed" && currentSession.status === "active") {
            setCurrentSession(serverSession);
            router.refresh();
          }
        }
      } catch {
        // Silently catch background poll failures
      }
    };

    const intervalId = setInterval(performSync, 5000);

    const handleVisibilityChange = () => {
      if (typeof document !== "undefined" && !document.hidden) {
        void performSync();
      }
    };

    const handleOnline = () => {
      void performSync();
    };

    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", handleVisibilityChange);
    }
    if (typeof window !== "undefined") {
      window.addEventListener("online", handleOnline);
    }

    return () => {
      isSubscribed = false;
      clearInterval(intervalId);
      if (typeof document !== "undefined") {
        document.removeEventListener("visibilitychange", handleVisibilityChange);
      }
      if (typeof window !== "undefined") {
        window.removeEventListener("online", handleOnline);
      }
    };
  }, [groupId, session.id, isSessionActive, router, currentSession.status]);

  const showToast = (msg: string) => {
    if (guestPopupTimeoutRef.current !== null) {
      clearTimeout(guestPopupTimeoutRef.current);
      guestPopupTimeoutRef.current = null;
    }
    setGuestAddedPopup(null);
    if (toastTimeoutRef.current !== null) clearTimeout(toastTimeoutRef.current);
    setSuccessToast(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setSuccessToast(null);
      toastTimeoutRef.current = null;
    }, 3000);
  };

  // Handlers
  const handleJoin = async () => {
    setIsJoining(true);
    setError(null);
    try {
      const res = await joinOpenPlaySessionAction({ groupId, sessionId: session.id });
      if (res.ok) {
        if (currentViewerPlayerId) {
          setLocalAttendance((prev) => {
            const filtered = prev.filter((a) => a.playerId !== currentViewerPlayerId);
            return [
              ...filtered,
              {
                sessionId: session.id,
                playerId: currentViewerPlayerId,
                joinedRound: 1,
                leftRound: null,
              },
            ];
          });
        }
        showToast("You joined Open Play!");
      } else {
        setError(res.error ?? "Failed to join session.");
      }
    } catch {
      setError("An unexpected error occurred while joining.");
    } finally {
      setIsJoining(false);
    }
  };

  const handleAddGuest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;
    setIsAddingGuest(true);
    setError(null);
    const ratingToAdd = guestRating;
    const genderToAdd = guestGender;
    try {
      const res = await addOpenPlayGuestAction({
        groupId,
        sessionId: session.id,
        guestName: guestName.trim(),
        gender: genderToAdd,
        initialRating: ratingToAdd,
      });
      if (res.ok) {
        const guestPlayer = res.data;
        setLocalPlayers((prev) => {
          if (prev.some((p) => p.id === guestPlayer.id)) return prev;
          return [...prev, guestPlayer];
        });
        setLocalAttendance((prev) => {
          const filtered = prev.filter((a) => a.playerId !== guestPlayer.id);
          return [
            ...filtered,
            {
              sessionId: session.id,
              playerId: guestPlayer.id,
              joinedRound: 1,
              leftRound: null,
            },
          ];
        });
        setGuestName("");
        setGuestGender("male");
        setGuestRating(3.5);
        if (guestPopupTimeoutRef.current !== null) clearTimeout(guestPopupTimeoutRef.current);
        setGuestAddedPopup(guestPlayer.name);
        guestPopupTimeoutRef.current = setTimeout(() => {
          setGuestAddedPopup(null);
          guestPopupTimeoutRef.current = null;
        }, 10000);
      } else {
        setError(res.error ?? "Failed to add guest.");
      }
    } catch {
      setError("An unexpected error occurred while adding guest.");
    } finally {
      setIsAddingGuest(false);
    }
  };

  const handleSelectRosterPlayer = async (playerId: string) => {
    if (!playerId || isAddingPlayer) return;
    setIsAddingPlayer(true);
    setError(null);
    try {
      const res = await addOpenPlayPlayerAction({
        groupId,
        sessionId: session.id,
        playerId,
      });
      if (res.ok) {
        const addedName = playerMap.get(playerId)?.name ?? "Player";
        setLocalAttendance((prev) => {
          const filtered = prev.filter((a) => a.playerId !== playerId);
          return [
            ...filtered,
            {
              sessionId: session.id,
              playerId,
              joinedRound: 1,
              leftRound: null,
            },
          ];
        });
        showToast(`Added ${addedName} to session!`);
      } else {
        setError(res.error ?? "Failed to add player.");
      }
    } catch {
      setError("An unexpected error occurred while adding player.");
    } finally {
      setIsAddingPlayer(false);
    }
  };

  const handleRemovePlayer = async (playerId: string) => {
    setError(null);
    if (t1p1 === playerId) setT1p1("");
    if (t1p2 === playerId) setT1p2("");
    if (t2p1 === playerId) setT2p1("");
    if (t2p2 === playerId) setT2p2("");
    try {
      const res = await removeOpenPlayPlayerAction({
        groupId,
        sessionId: session.id,
        playerId,
      });
      if (res.ok) {
        setLocalAttendance((prev) =>
          prev.map((a) => (a.playerId === playerId ? { ...a, leftRound: 1 } : a)),
        );
        showToast("Player removed from session.");
      } else {
        setError(res.error ?? "Failed to remove player.");
      }
    } catch {
      setError("An unexpected error occurred.");
    }
  };


  // Rotate Partners (Split & Switch) handler
  const canRotate = Boolean(
    (t1p1 && t1p2 && t2p1 && t2p2) ||
      (lastSubmittedGame &&
        lastSubmittedGame.matchType === "doubles" &&
        lastSubmittedGame.team1PlayerIds.length === 2 &&
        lastSubmittedGame.team2PlayerIds.length === 2)
  );

  const handleRotatePartners = () => {
    setError(null);
    let current4: [string, string, string, string] | null = null;
    if (t1p1 && t1p2 && t2p1 && t2p2) {
      current4 = [t1p1, t1p2, t2p1, t2p2];
    } else if (
      lastSubmittedGame &&
      lastSubmittedGame.matchType === "doubles" &&
      lastSubmittedGame.team1PlayerIds.length === 2 &&
      lastSubmittedGame.team2PlayerIds.length === 2
    ) {
      current4 = [
        lastSubmittedGame.team1PlayerIds[0],
        lastSubmittedGame.team1PlayerIds[1],
        lastSubmittedGame.team2PlayerIds[0],
        lastSubmittedGame.team2PlayerIds[1],
      ];
    }

    if (!current4) {
      setError("Please select 4 players first to rotate partners.");
      return;
    }

    const currentSet = new Set(current4);
    let base = rotateBase;
    if (!base || base.length !== 4 || base.some((id) => !currentSet.has(id))) {
      let p1 = current4[0];
      let p2 = current4[1];
      let p3 = current4[2];
      let p4 = current4[3];
      if (currentViewerPlayerId && current4.includes(currentViewerPlayerId) && p1 !== currentViewerPlayerId) {
        const remaining = current4.filter((id) => id !== currentViewerPlayerId);
        p1 = currentViewerPlayerId;
        p2 = remaining[0];
        p3 = remaining[1];
        p4 = remaining[2];
      }
      base = [p1, p2, p3, p4];
      setRotateBase(base);
    }

    const [p1, p2, p3, p4] = base;

    // Determine who is currently partnered with p1
    let currentPartner: string;
    if (t1p1 === p1) currentPartner = t1p2;
    else if (t1p2 === p1) currentPartner = t1p1;
    else if (t2p1 === p1) currentPartner = t2p2;
    else if (t2p2 === p1) currentPartner = t2p1;
    else currentPartner = p2;

    // Cycle combinations: (p1, p2) -> (p1, p3) -> (p1, p4) -> (p1, p2)
    if (currentPartner === p2) {
      // Rotation 1: p1 and p3 vs p2 and p4
      setT1p1(p1);
      setT1p2(p3);
      setT2p1(p2);
      setT2p2(p4);
    } else if (currentPartner === p3) {
      // Rotation 2: p1 and p4 vs p2 and p3
      setT1p1(p1);
      setT1p2(p4);
      setT2p1(p2);
      setT2p2(p3);
    } else {
      // Rotation 3: p1 and p2 vs p3 and p4
      setT1p1(p1);
      setT1p2(p2);
      setT2p1(p3);
      setT2p2(p4);
    }

    setT1Score("");
    setT2Score("");
    showToast("Partners rotated!");
  };

  // Swap sides for singles and doubles
  const canSwapSides =
    matchType === "doubles"
      ? Boolean(
          (t1p1 || t1p2 || t2p1 || t2p2) ||
            (lastSubmittedGame && lastSubmittedGame.matchType === "doubles")
        )
      : Boolean(
          (t1p1 && t2p1) ||
            (lastSubmittedGame && lastSubmittedGame.matchType === "singles")
        );

  const handleSwapSides = () => {
    setError(null);
    if (matchType === "doubles") {
      let t1_1 = t1p1;
      let t1_2 = t1p2;
      let t2_1 = t2p1;
      let t2_2 = t2p2;

      if (
        !t1_1 &&
        !t1_2 &&
        !t2_1 &&
        !t2_2 &&
        lastSubmittedGame &&
        lastSubmittedGame.matchType === "doubles"
      ) {
        t1_1 = lastSubmittedGame.team1PlayerIds[0] ?? "";
        t1_2 = lastSubmittedGame.team1PlayerIds[1] ?? "";
        t2_1 = lastSubmittedGame.team2PlayerIds[0] ?? "";
        t2_2 = lastSubmittedGame.team2PlayerIds[1] ?? "";
      }

      setT1p1(t2_1);
      setT1p2(t2_2);
      setT2p1(t1_1);
      setT2p2(t1_2);
    } else {
      let t1_1 = t1p1;
      let t2_1 = t2p1;

      if (
        !t1_1 &&
        !t2_1 &&
        lastSubmittedGame &&
        lastSubmittedGame.matchType === "singles"
      ) {
        t1_1 = lastSubmittedGame.team1PlayerIds[0] ?? "";
        t2_1 = lastSubmittedGame.team2PlayerIds[0] ?? "";
      }

      setT1p1(t2_1);
      setT2p1(t1_1);
    }
    setT1Score("");
    setT2Score("");
    setRotateBase(null);
    showToast("Sides swapped!");
  };

  // Clear slots handler
  const handleClearSlots = () => {
    setT1p1(currentViewerPlayerId && presentPlayerIds.has(currentViewerPlayerId) ? currentViewerPlayerId : "");
    setT1p2("");
    setT2p1("");
    setT2p2("");
    setT1Score("");
    setT2Score("");
    setRotateBase(null);
  };

  const handleSubmitGame = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!isViewerCheckedIn) {
      setError("You must be checked in to this session to record games.");
      return;
    }

    const team1Ids = matchType === "doubles" ? [t1p1, t1p2] : [t1p1];
    const team2Ids = matchType === "doubles" ? [t2p1, t2p2] : [t2p1];

    if (team1Ids.some((id) => !id) || team2Ids.some((id) => !id)) {
      setError("Please select all players for both teams.");
      return;
    }

    const allSelected = [...team1Ids, ...team2Ids];
    if (new Set(allSelected).size !== allSelected.length) {
      setError("A player cannot be selected more than once in the same game.");
      return;
    }

    if (allSelected.some((id) => !presentPlayerIds.has(id))) {
      setError("All players in a game must be currently checked in to the open play session.");
      return;
    }

    const s1 = parseInt(t1Score, 10);
    const s2 = parseInt(t2Score, 10);
    if (isNaN(s1) || isNaN(s2) || s1 < 0 || s2 < 0) {
      setError("Please enter valid scores (non-negative whole numbers).");
      return;
    }

    if (s1 === s2) {
      setError("Scores cannot be tied. Enter two different scores.");
      return;
    }

    // Optimistic match generation for instant feedback
    const optimisticMatchId = createIdempotencyKey("opt");
    const targetRoundId = localStartedRounds[0]?.round.id ?? `rnd_${session.id}`;
    const courtNumber = 1;

    const optimisticMatch: MatchRecord = {
      id: optimisticMatchId,
      roundId: targetRoundId,
      courtNumber,
      status: "completed",
      team1Score: s1,
      team2Score: s2,
      completedAt: new Date(),
      version: 1,
      rated: true,
    };

    const optimisticMatchPlayers: MatchPlayerRecord[] = [
      ...team1Ids.map((p) => ({
        matchId: optimisticMatchId,
        playerId: p,
        team: 1 as const,
        ratingBefore: null,
        ratingAfter: null,
      })),
      ...team2Ids.map((p) => ({
        matchId: optimisticMatchId,
        playerId: p,
        team: 2 as const,
        ratingBefore: null,
        ratingAfter: null,
      })),
    ];

    setLocalStartedRounds((prev) => {
      if (prev.length === 0) {
        const newSr: StartedRoundRecord = {
          round: {
            id: targetRoundId,
            sessionId: session.id,
            roundNumber: 1,
            status: "started",
            seed: 0,
            scoreBreakdown: {
              playingTime: 0,
              consecutiveSit: 0,
              partnerRepeat: 0,
              skillBalance: 0,
              opponentRepeat: 0,
              tieBreak: 0,
              total: 0,
            },
            createdAt: new Date(),
            startedAt: new Date(),
            completedAt: null,
            version: 1,
          },
          matches: [optimisticMatch],
          matchPlayers: optimisticMatchPlayers,
          sits: [],
        };
        return [newSr];
      }
      return prev.map((sr) =>
        sr.round.id === targetRoundId || prev.length === 1
          ? {
              ...sr,
              matches: [...sr.matches.filter((m) => m.id !== optimisticMatchId), optimisticMatch],
              matchPlayers: [
                ...sr.matchPlayers.filter((mp) => mp.matchId !== optimisticMatchId),
                ...optimisticMatchPlayers,
              ],
            }
          : sr
      );
    });

    setT1Score("");
    setT2Score("");
    setIsSubmittingGame(true);
    try {
      const res = await submitOpenPlayGameAction({
        groupId,
        sessionId: session.id,
        team1PlayerIds: team1Ids,
        team2PlayerIds: team2Ids,
        team1Score: s1,
        team2Score: s2,
      });

      if (res.ok) {
        const newMatch = res.data;
        setLastSubmittedGame({
          matchType,
          team1PlayerIds: team1Ids,
          team2PlayerIds: team2Ids,
        });
        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.map((m) => (m.id === optimisticMatchId ? newMatch : m)),
            matchPlayers: sr.matchPlayers.map((mp) =>
              mp.matchId === optimisticMatchId ? { ...mp, matchId: newMatch.id } : mp
            ),
          }))
        );
        showToast("Game submitted successfully!");
        if (isPickleScore(newMatch.team1Score, newMatch.team2Score)) {
          setPickledGameId(newMatch.id);
        } else {
          setPickledGameId(null);
        }
      } else {
        // Rollback optimistic update
        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.filter((m) => m.id !== optimisticMatchId),
            matchPlayers: sr.matchPlayers.filter((mp) => mp.matchId !== optimisticMatchId),
          }))
        );
        setPickledGameId(null);
        setT1Score(String(s1));
        setT2Score(String(s2));
        setError(res.error ?? "Failed to submit game.");
      }
    } catch {
      setLocalStartedRounds((prev) =>
        prev.map((sr) => ({
          ...sr,
          matches: sr.matches.filter((m) => m.id !== optimisticMatchId),
          matchPlayers: sr.matchPlayers.filter((mp) => mp.matchId !== optimisticMatchId),
        }))
      );
      setPickledGameId(null);
      setT1Score(String(s1));
      setT2Score(String(s2));
      setError("An unexpected error occurred while submitting game.");
    } finally {
      setIsSubmittingGame(false);
    }
  };

  // Edit match state and handlers
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [editMatchType, setEditMatchType] = useState<"doubles" | "singles">("doubles");
  const [editT1p1, setEditT1p1] = useState("");
  const [editT1p2, setEditT1p2] = useState("");
  const [editT2p1, setEditT2p1] = useState("");
  const [editT2p2, setEditT2p2] = useState("");
  const [editT1Score, setEditT1Score] = useState("");
  const [editT2Score, setEditT2Score] = useState("");
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  const handleStartEdit = (match: (typeof allMatches)[number]) => {
    setEditingMatchId(match.id);
    const isSingles = match.team1PlayerIds.length === 1 && match.team2PlayerIds.length === 1;
    setEditMatchType(isSingles ? "singles" : "doubles");
    setEditT1p1(match.team1PlayerIds[0] ?? "");
    setEditT1p2(match.team1PlayerIds[1] ?? "");
    setEditT2p1(match.team2PlayerIds[0] ?? "");
    setEditT2p2(match.team2PlayerIds[1] ?? "");
    setEditT1Score(String(match.team1Score ?? ""));
    setEditT2Score(String(match.team2Score ?? ""));
    setError(null);
  };

  const handleCancelEdit = () => {
    setEditingMatchId(null);
    setError(null);
  };

  const isEditPlayerSelectedElsewhere = (
    playerId: string,
    currentSlot: "t1p1" | "t1p2" | "t2p1" | "t2p2",
  ) => {
    if (!playerId) return false;
    if (currentSlot !== "t1p1" && editT1p1 === playerId) return true;
    if (currentSlot !== "t1p2" && editMatchType === "doubles" && editT1p2 === playerId) return true;
    if (currentSlot !== "t2p1" && editT2p1 === playerId) return true;
    if (currentSlot !== "t2p2" && editMatchType === "doubles" && editT2p2 === playerId) return true;
    return false;
  };

  const editSelectablePlayers = useMemo(() => {
    if (!editingMatchId) return checkedInPlayers;
    const editingMatch = allMatches.find((m) => m.id === editingMatchId);
    if (!editingMatch) return checkedInPlayers;
    const ids = new Set(checkedInPlayers.map((p) => p.id));
    const list = [...checkedInPlayers];
    for (const pid of [...editingMatch.team1PlayerIds, ...editingMatch.team2PlayerIds]) {
      if (!ids.has(pid)) {
        const p = playerMap.get(pid);
        if (p) {
          ids.add(p.id);
          list.push(p);
        }
      }
    }
    return list.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
  }, [checkedInPlayers, editingMatchId, allMatches, playerMap]);

  const handleSelectEditPlayer = (
    slot: "t1p1" | "t1p2" | "t2p1" | "t2p2",
    playerId: string,
  ) => {
    if (playerId) {
      if (slot !== "t1p1" && editT1p1 === playerId) setEditT1p1("");
      if (slot !== "t1p2" && editT1p2 === playerId) setEditT1p2("");
      if (slot !== "t2p1" && editT2p1 === playerId) setEditT2p1("");
      if (slot !== "t2p2" && editT2p2 === playerId) setEditT2p2("");
    }
    if (slot === "t1p1") setEditT1p1(playerId);
    else if (slot === "t1p2") setEditT1p2(playerId);
    else if (slot === "t2p1") setEditT2p1(playerId);
    else if (slot === "t2p2") setEditT2p2(playerId);
  };

  const getEditSlotOptions = (slot: "t1p1" | "t1p2" | "t2p1" | "t2p2") => {
    return editSelectablePlayers.map((p) => ({
      id: p.id,
      name: p.name,
      selectedElsewhere: isEditPlayerSelectedElsewhere(p.id, slot),
    }));
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMatchId) return;
    setError(null);

    const team1Ids = editMatchType === "doubles" ? [editT1p1, editT1p2] : [editT1p1];
    const team2Ids = editMatchType === "doubles" ? [editT2p1, editT2p2] : [editT2p1];

    if (team1Ids.some((id) => !id) || team2Ids.some((id) => !id)) {
      setError("Please select all players for both teams.");
      return;
    }

    const allSelected = [...team1Ids, ...team2Ids];
    if (new Set(allSelected).size !== allSelected.length) {
      setError("A player cannot be selected more than once in the same game.");
      return;
    }

    const editingMatch = allMatches.find((m) => m.id === editingMatchId);
    const existingMatchPids = new Set(
      editingMatch ? [...editingMatch.team1PlayerIds, ...editingMatch.team2PlayerIds] : [],
    );
    if (allSelected.some((id) => !presentPlayerIds.has(id) && !existingMatchPids.has(id))) {
      setError("All players in a game must be currently checked in to the open play session.");
      return;
    }

    const s1 = parseInt(editT1Score, 10);
    const s2 = parseInt(editT2Score, 10);
    if (isNaN(s1) || isNaN(s2) || s1 < 0 || s2 < 0) {
      setError("Please enter valid scores (non-negative whole numbers).");
      return;
    }

    if (s1 === s2) {
      setError("Scores cannot be tied. Enter two different scores.");
      return;
    }

    setIsSavingEdit(true);
    try {
      const res = await updateOpenPlayGameAction({
        groupId,
        sessionId: session.id,
        matchId: editingMatchId,
        team1PlayerIds: team1Ids,
        team2PlayerIds: team2Ids,
        team1Score: s1,
        team2Score: s2,
      });

      if (res.ok) {
        const updatedMatchId = editingMatchId;
        const updatedMatchPlayers: MatchPlayerRecord[] = [
          ...team1Ids.map((p) => ({ matchId: updatedMatchId, playerId: p, team: 1 as const, ratingBefore: null, ratingAfter: null })),
          ...team2Ids.map((p) => ({ matchId: updatedMatchId, playerId: p, team: 2 as const, ratingBefore: null, ratingAfter: null })),
        ];

        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.map((m) =>
              m.id === updatedMatchId
                ? { ...m, team1Score: s1, team2Score: s2 }
                : m
            ),
            matchPlayers: [
              ...sr.matchPlayers.filter((mp) => mp.matchId !== updatedMatchId),
              ...updatedMatchPlayers,
            ],
          }))
        );

        if (pickledGameId === editingMatchId) setPickledGameId(null);
        setEditingMatchId(null);
        showToast("Game updated successfully!");
      } else {
        setError(res.error ?? "Failed to update game.");
      }
    } catch {
      setError("An unexpected error occurred while updating the game.");
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleDeleteMatch = async (matchId: string) => {
    if (!confirm("Are you sure you want to delete this game result?")) return;
    setDeletedMatchIds((prev) => new Set([...prev, matchId]));
    try {
      const res = await deleteOpenPlayGameAction({
        groupId,
        sessionId: session.id,
        matchId,
      });
      if (res.ok) {
        if (pickledGameId === matchId) setPickledGameId(null);
        showToast("Game deleted.");
      } else {
        setDeletedMatchIds((prev) => {
          const next = new Set(prev);
          next.delete(matchId);
          return next;
        });
        setError(res.error ?? "Failed to delete game.");
      }
    } catch {
      setDeletedMatchIds((prev) => {
        const next = new Set(prev);
        next.delete(matchId);
        return next;
      });
      setError("An unexpected error occurred while deleting game.");
    }
  };

  const handleEndSession = async () => {
    if (!confirm("End this session? Match history and ratings will be finalized.")) return;
    setIsEnding(true);
    setError(null);
    try {
      const res = await endOpenPlaySessionAction({ groupId, sessionId: currentSession.id });
      if (res.ok) {
        markSessionEnded(groupId, currentSession.id);
        setCurrentSession((prev) => ({ ...prev, status: "completed", endedAt: new Date() }));
        setPickledGameId(null);
        setJustEndedSession(true);
        router.refresh();
      } else {
        setError(res.error ?? "Failed to end session.");
      }
    } catch {
      setError("An unexpected error occurred while ending session.");
    } finally {
      setIsEnding(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Dismissable Guest Added Popup */}
      {guestAddedPopup && !successToast && (
        <Toast
          testId="guest-added-popup"
          role="status"
          onDismiss={() => {
            if (guestPopupTimeoutRef.current !== null) clearTimeout(guestPopupTimeoutRef.current);
            setGuestAddedPopup(null);
          }}
        >
          <span>you have added &quot;{guestAddedPopup}&quot; to the roster</span>
        </Toast>
      )}

      {/* Toast Notification */}
      {successToast && (
        <Toast
          role="status"
          onDismiss={() => {
            if (toastTimeoutRef.current !== null) clearTimeout(toastTimeoutRef.current);
            setSuccessToast(null);
          }}
        >
          <span>{successToast}</span>
        </Toast>
      )}

      {/* Top Header Controls */}
      <div className="flex items-center justify-between gap-1.5 sm:gap-2 flex-nowrap">
        <BackButton
          href={isFromProfile ? "/players" : `/g/${groupId}`}
          label={
            <>
              <span className="sm:hidden">← Back</span>
              <span className="hidden sm:inline">{isFromProfile ? "← Back to Profile" : "← Back to Group"}</span>
            </>
          }
          ariaLabel={isFromProfile ? "Go back to profile" : "Go back"}
          className="inline-flex items-center shrink-0 h-7 sm:h-9 px-2 sm:px-3 rounded-lg sm:rounded-xl bg-white border-2 border-black font-black uppercase text-[10px] sm:text-xs text-black shadow-[1px_1px_0px_0px_#000] sm:shadow-[2px_2px_0px_0px_#000] hover:bg-neutral-50 active:translate-x-0.5 active:translate-y-0.5 transition-transform cursor-pointer"
        />
        {isSessionActive ? (
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {canManage && (
              <button
                type="button"
                onClick={handleEndSession}
                disabled={isEnding}
                aria-label="End Session"
                data-testid="end-session-button"
                className="inline-flex items-center shrink-0 h-7 sm:h-9 px-2 sm:px-2.5 rounded-lg sm:rounded-xl bg-[#ff6b6b] border-2 border-black font-black uppercase text-[10px] sm:text-xs text-black shadow-[1px_1px_0px_0px_#000] sm:shadow-[2px_2px_0px_0px_#000] hover:bg-[#ff5252] active:translate-x-0.5 active:translate-y-0.5 cursor-pointer disabled:opacity-60"
              >
                {isEnding ? "Ending..." : (
                  <>
                    <span className="sm:hidden">End</span>
                    <span className="hidden sm:inline">End Session</span>
                  </>
                )}
              </button>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <Badge
              variant="muted"
              data-testid="completed-session-badge"
              className="shrink-0 h-7 sm:h-9 px-2 sm:px-2.5 text-[10px] sm:text-xs font-black uppercase flex items-center"
            >
              <span className="sm:hidden">Completed</span>
              <span className="hidden sm:inline">Completed Session</span>
            </Badge>
          </div>
        )}
      </div>

      {/* Session Header Card */}
      <header className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1 space-y-1">
            <SessionNameEditor
              groupId={groupId}
              sessionId={session.id}
              initialName={initialSessionName}
              canEdit={isOrganizer || isHost}
              headingTag="h1"
              className="font-display text-2xl sm:text-3xl font-black uppercase text-black"
              onRenamed={(newName) => setSessionName(newName)}
            />
            <p className="text-xs font-bold text-neutral-600">
              {groupName ?? "Group"}
              {sessionName ? (
                <>
                  {" · Started "}
                  <ClientDate date={session.startedAt} />
                </>
              ) : null}
            </p>
          </div>
          {(isOrganizer || isHost) && (
            <div className="shrink-0">
              <SessionOptionsMenu
                groupId={groupId}
                sessionId={session.id}
                sessionName={sessionName}
                sessionDate={session.startedAt}
                redirectTo={isFromProfile ? "/players" : `/g/${groupId}`}
                onRenamed={(newName) => setSessionName(newName)}
              />
            </div>
          )}
        </div>

        {/* Quick Stats & Summary - only rendered when session has ended */}
        {!isSessionActive && (
          <>
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-neutral-50 border-2 border-black rounded-2xl shadow-[2px_2px_0px_0px_#000]">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Total Games</span>
                <span className="font-display text-xl font-black text-black">{completedMatches.length}</span>
              </div>
              <div className="p-3 bg-neutral-50 border-2 border-black rounded-2xl shadow-[2px_2px_0px_0px_#000]">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Players</span>
                <span className="font-display text-xl font-black text-black">{openPlayPlayerStats.length}</span>
              </div>
            </div>

            {/* Personal Session View (when a player is signed in) */}
            {viewerSessionStats && (
              <div
                data-testid="personal-session-summary"
                className="p-4 rounded-2xl border-2 border-black bg-[#ccff00]/25 shadow-[2px_2px_0px_0px_#000] space-y-2"
              >
                <span className="text-xs font-black uppercase tracking-wider text-neutral-800 block">
                  Your Session
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <div className="p-2.5 bg-[#FFFDF7] border-2 border-black rounded-xl shadow-[1px_1px_0px_0px_#000]">
                    <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Games Won</span>
                    <span className="font-display text-lg font-black text-black">{viewerSessionStats.wins}</span>
                  </div>
                  <div className="p-2.5 bg-[#FFFDF7] border-2 border-black rounded-xl shadow-[1px_1px_0px_0px_#000]">
                    <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Games Lost</span>
                    <span className="font-display text-lg font-black text-black">{viewerSessionStats.losses}</span>
                  </div>
                  <div className="p-2.5 bg-[#FFFDF7] border-2 border-black rounded-xl shadow-[1px_1px_0px_0px_#000] col-span-2 sm:col-span-1">
                    <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Games Played</span>
                    <span className="font-display text-lg font-black text-black">{viewerSessionStats.gamesPlayed}</span>
                  </div>
                </div>
                <p className="text-xs font-bold text-neutral-700">
                  You won {viewerSessionStats.wins} {viewerSessionStats.wins === 1 ? "game" : "games"} and lost {viewerSessionStats.losses} {viewerSessionStats.losses === 1 ? "game" : "games"}.
                </p>
              </div>
            )}

            {/* Time / Duration info */}
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-bold text-neutral-600 pt-1 border-t-2 border-neutral-100">
              <ClientTime
                date={session.startedAt}
                prefix={<strong className="text-black">Started: </strong>}
              />
              {session.endedAt && (
                <ClientTime
                  date={session.endedAt}
                  prefix={<strong className="text-black">Ended: </strong>}
                />
              )}
              {durationFormatted && (
                <span>
                  <strong className="text-black">Duration:</strong> {durationFormatted}
                </span>
              )}
            </div>
          </>
        )}

        {error && (
          <div role="alert" className="p-3 bg-red-100 border-2 border-red-500 rounded-xl text-red-700 text-xs font-bold">
            {error}
          </div>
        )}
      </header>

      {!isSessionActive && (
        <div role={justEndedSession ? "status" : undefined} className="flex items-center justify-between gap-3 rounded-xl border-2 border-black bg-[#FFFDF7] px-4 py-2 text-sm font-bold">
          <span>Session complete</span>
          <SessionSignOff play={justEndedSession} />
        </div>
      )}

      {session.status === "completed" && (
        <SessionHighlights rounds={localStartedRounds} players={players} excludedMatchIds={deletedMatchIds} />
      )}

      {session.status === "completed" && openPlayPlayerStats.length > 0 && (
        <section className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_#000] space-y-4">
          <h2 className="font-display text-xl font-black uppercase tracking-wider text-black">
            Player Summary
          </h2>
          <div className="divide-y-2 divide-neutral-100">
            {openPlayPlayerStats.map((stat) => (
              <div key={stat.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="font-black text-black text-sm block">{stat.name}</span>
                  <span className="text-xs font-bold text-neutral-500">
                    {stat.gamesPlayed} game{stat.gamesPlayed !== 1 ? "s" : ""} played
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-black px-2 py-0.5 rounded-lg border-2 border-black bg-neutral-50 shadow-[1px_1px_0px_0px_#000]">
                    {stat.wins}W – {stat.losses}L
                  </span>
                  {stat.gamesPlayed > 0 && (
                    <span className="text-xs font-bold text-neutral-600">
                      ({stat.winRate}%)
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Prominent Join Open Play Banner for group members not checked in */}
      {isSessionActive && isMember && !isViewerCheckedIn && (
        <section className="bg-[#ccff00] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-xl sm:text-2xl font-black uppercase text-black tracking-tight">
              Join Open Play
            </h2>
            <p className="text-xs sm:text-sm font-bold text-neutral-800">
              Check in to this session to play matches, rotate with partners, and record scores.
            </p>
          </div>
          <button
            type="button"
            onClick={handleJoin}
            disabled={isJoining}
            data-testid="join-open-play-button"
            className="py-3 px-6 rounded-2xl bg-black hover:bg-neutral-800 text-white font-display text-xs sm:text-sm font-black uppercase tracking-wider border-2 border-black shadow-[3px_3px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-60 cursor-pointer shrink-0 transition-transform"
          >
            {isJoining ? "Joining..." : "Join Open Play"}
          </button>
        </section>
      )}

      {/* Attendance & Players Section (Prominent at top on desktop, taking up more space above games) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 items-start">
        {/* Add Players Section */}
          {(isSessionActive || canManage) && (
            <section
              data-testid="add-players-box"
          className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] space-y-4"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 flex items-center justify-center rounded-xl border-2 border-black bg-[#ccff00] shadow-[2px_2px_0px_0px_#000] shrink-0">
                <UserPlusIcon className="h-4 w-4 text-black" />
              </div>
              <h2 className="font-display text-xl font-black uppercase text-black">
                Add Players
              </h2>
            </div>

            {/* Mode Switch Tabs (matching roster style) */}
            <div
              className="flex items-center gap-1.5 p-1 bg-[#FFFDF7] border border-neutral-200 rounded-xl w-fit shrink-0"
              role="tablist"
              aria-label="Add player mode"
            >
              <button
                type="button"
                role="tab"
                id="tab-add-member"
                aria-selected={addPlayerTab === "member"}
                aria-controls="tabpanel-add-member"
                data-testid="tab-add-member"
                onClick={() => setAddPlayerTab("member")}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-black uppercase rounded-lg transition-all cursor-pointer ${
                  addPlayerTab === "member"
                    ? "bg-black text-white shadow-[1px_1px_0px_0px_rgba(0,0,0,0.4)]"
                    : "text-neutral-800 hover:bg-black/10"
                }`}
              >
                <UsersIcon className="h-3.5 w-3.5 shrink-0" />
                <span>Existing Member</span>
              </button>
              <button
                type="button"
                role="tab"
                id="tab-add-guest"
                aria-selected={addPlayerTab === "guest"}
                aria-controls="tabpanel-add-guest"
                data-testid="tab-add-guest"
                onClick={() => setAddPlayerTab("guest")}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-black uppercase rounded-lg transition-all cursor-pointer ${
                  addPlayerTab === "guest"
                    ? "bg-black text-white shadow-[1px_1px_0px_0px_rgba(0,0,0,0.4)]"
                    : "text-neutral-800 hover:bg-black/10"
                }`}
              >
                <UserPlusIcon className="h-3.5 w-3.5 shrink-0" />
                <span>Add Guest</span>
              </button>
            </div>
          </div>

          {/* Tab Panel: Add from Roster */}
          {addPlayerTab === "member" && (
            <div
              role="tabpanel"
              id="tabpanel-add-member"
              aria-labelledby="tab-add-member"
              className="pt-2 border-t-2 border-neutral-200 space-y-2"
            >
              <label className="block text-xs font-black uppercase tracking-wider text-black">
                Add Existing Group Member
              </label>
              {availableRosterPlayers.length > 0 ? (
                <FilterablePlayerSelect
                  ariaLabel="Add Existing Group Member"
                  placeholder={isAddingPlayer ? "Adding player..." : "Select player..."}
                  value=""
                  onChange={(val) => {
                    if (val) {
                      void handleSelectRosterPlayer(val);
                    }
                  }}
                  options={rosterPlayerOptions}
                  dataTestId="roster-player-select"
                  disabled={isAddingPlayer}
                />
              ) : (
                <p className="text-xs font-bold text-neutral-500 italic py-1">
                  All group members are currently checked in.
                </p>
              )}
            </div>
          )}

          {/* Tab Panel: Add Guest */}
          {addPlayerTab === "guest" && (
            <form
              role="tabpanel"
              id="tabpanel-add-guest"
              aria-labelledby="tab-add-guest"
              onSubmit={handleAddGuest}
              className="pt-2 border-t-2 border-neutral-200 space-y-3"
            >
              {!isGuestDescDismissed && (
                <div
                  data-testid="guest-description-banner"
                  className="flex items-center justify-between gap-2 p-2 bg-neutral-100/90 rounded-lg border border-neutral-300 text-neutral-700"
                >
                  <p className="text-[11px] font-bold text-neutral-600 leading-tight">
                    Adding a guest here will add them to your roster.
                  </p>
                  <button
                    type="button"
                    onClick={handleDismissGuestDesc}
                    aria-label="Dismiss guest description"
                    title="Dismiss"
                    data-testid="dismiss-guest-desc-button"
                    className="p-1 text-neutral-400 hover:text-black rounded hover:bg-neutral-200 transition-colors cursor-pointer shrink-0"
                  >
                    <XIcon className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  id="guest-name-input"
                  type="text"
                  aria-label="Guest player name"
                  placeholder="Guest player name"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="flex-1 min-w-0 bg-white border-2 border-black rounded-xl px-3.5 py-2 text-black font-bold placeholder-neutral-400 text-sm shadow-[2px_2px_0px_0px_#000] focus:shadow-[4px_4px_0px_0px_#000] focus:outline-none transition-shadow"
                />
                <div className="flex items-center gap-2 shrink-0">
                  <CustomDropdown
                    id="open-play-guest-gender"
                    ariaLabel="Guest Gender"
                    value={guestGender}
                    onChange={(val) => setGuestGender(val as "male" | "female")}
                    options={[
                      { value: "male", label: "Male" },
                      { value: "female", label: "Female" },
                    ]}
                    sizeVariant="sm"
                    className="flex-1 sm:flex-initial shrink-0"
                  />
                  <button
                    type="submit"
                    disabled={!guestName.trim() || isAddingGuest}
                    className="px-5 py-2 rounded-xl border-2 border-black bg-[#ccff00] text-black hover:bg-[#b8e600] text-xs font-black uppercase shadow-[2px_2px_0px_0px_#000] active:translate-x-[1px] active:translate-y-[1px] disabled:opacity-60 cursor-pointer shrink-0 transition-colors"
                  >
                    {isAddingGuest ? "Adding..." : "Add"}
                  </button>
                </div>
              </div>

              {/* Sliding Scale for Rating */}
              <div className="bg-white border-2 border-black rounded-xl p-3 shadow-[2px_2px_0px_0px_#000]">
                <RatingSlider
                  id="guest-rating-slider"
                  dataTestId="guest-rating-slider"
                  label="Guest Rating"
                  value={guestRating}
                  onChange={setGuestRating}
                  showDescription={true}
                />
              </div>
            </form>
          )}
        </section>
      )}

      {/* Checked-in Players Section */}
      <section
        data-testid="checked-in-players-box"
        className={`bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] space-y-4 ${
          !(isSessionActive || canManage) ? "lg:col-span-2" : ""
        }`}
      >
        {/* Header inside the box that toggles the drawer */}
        <button
          type="button"
          onClick={() => setIsPlayersDrawerOpen((prev) => !prev)}
          aria-expanded={isPlayersDrawerOpen}
          aria-controls="checked-in-players-drawer"
          aria-label={isPlayersDrawerOpen ? "Hide players checked in" : "Show players checked in"}
          data-testid="toggle-players-drawer-button"
          className="w-full flex items-center justify-between gap-2 text-left cursor-pointer select-none"
        >
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 flex items-center justify-center rounded-xl border-2 border-black bg-[#ccff00] shadow-[2px_2px_0px_0px_#000] shrink-0">
              <UsersIcon className="h-4 w-4 text-black" />
            </div>
            <h2 className="font-display text-xl font-black uppercase text-black">
              Checked-in Players ({checkedInPlayers.length})
            </h2>
          </div>

          <ChevronDownIcon
            className={`h-5 w-5 text-black transform transition-transform duration-200 shrink-0 ${
              isPlayersDrawerOpen ? "rotate-180" : ""
            }`}
          />
        </button>

        {/* Players Drawer Content */}
        {isPlayersDrawerOpen && (
          <div
            id="checked-in-players-drawer"
            data-testid="checked-in-players-drawer"
            className="space-y-2 pt-2 border-t-2 border-neutral-200"
          >
            {checkedInPlayers.length === 0 ? (
              <p className="text-xs font-bold text-neutral-500 italic py-1">
                No players checked in yet. Join or add players above!
              </p>
            ) : (
              <div className="flex flex-wrap gap-2" data-testid="open-play-attendees">
                {checkedInPlayers.map((p) => {
                  const isViewer = p.id === currentViewerPlayerId;
                  return (
                    <div
                      key={p.id}
                      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border-2 border-black text-xs font-bold shadow-[2px_2px_0px_0px_#000] ${
                        isViewer ? "bg-[#ccff00]" : "bg-[#FFFDF7]"
                      }`}
                    >
                      <span className="font-black text-black">{p.name}</span>
                      <span className="text-[10px] text-neutral-600 font-mono">
                        {formatDupr(p.rating)}
                      </span>
                      {isViewer && (
                        <span className="text-[9px] uppercase font-black bg-black text-white px-1.5 py-0.5 rounded-full">
                          You
                        </span>
                      )}
                      {isSessionActive && (isOrganizer || isViewer) && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemovePlayer(p.id);
                          }}
                          title="Leave / Remove from session"
                          className="ml-1 text-neutral-500 hover:text-black font-black text-sm cursor-pointer"
                        >
                          ×
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </section>
      </div>

      {/* Primary Games Section (Below Attendance & Players) */}
      <div className="space-y-6">
        {/* Submit Game Section */}
          {(isSessionActive || canManage) && (
            <section
              className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] space-y-4"
              data-testid="submit-game-card"
        >
          <div className="flex items-center justify-between gap-2">
            <h2 className="font-display text-lg sm:text-xl font-black uppercase text-black">
              {isSessionActive ? "Submit Game" : "Add Game"}
            </h2>

            {/* Match Type Switcher */}
            {isViewerCheckedIn && (
              <div className="flex border-2 border-black rounded-xl overflow-hidden shadow-[2px_2px_0px_0px_#000] shrink-0">
                <button
                  type="button"
                  onClick={() => setMatchType("doubles")}
                  className={`py-1 px-1.5 sm:px-3 text-[10px] sm:text-xs font-black uppercase whitespace-nowrap ${
                    matchType === "doubles" ? "bg-[#ccff00] text-black" : "bg-white text-neutral-600"
                  }`}
                >
                  Doubles (2v2)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMatchType("singles");
                    setT1p2("");
                    setT2p2("");
                  }}
                  className={`py-1 px-1.5 sm:px-3 text-[10px] sm:text-xs font-black uppercase border-l-2 border-black whitespace-nowrap ${
                    matchType === "singles" ? "bg-[#ccff00] text-black" : "bg-white text-neutral-600"
                  }`}
                >
                  Singles (1v1)
                </button>
              </div>
            )}
          </div>

          {!isViewerCheckedIn ? (
            <div className="p-4 sm:p-5 rounded-2xl border-2 border-black bg-neutral-50 text-center space-y-3 shadow-[2px_2px_0px_0px_#000]">
              <p className="text-xs sm:text-sm font-bold text-neutral-700">
                You must be checked in to this session to record games.
              </p>
              {isSessionActive && isMember && (
                <button
                  type="button"
                  onClick={handleJoin}
                  disabled={isJoining}
                  data-testid="join-open-play-submit-button"
                  className="py-2.5 px-5 rounded-xl bg-[#ccff00] hover:bg-[#b8eb00] text-black font-display text-xs font-black uppercase tracking-wider border-2 border-black shadow-[2px_2px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-60 cursor-pointer"
                >
                  {isJoining ? "Joining..." : "Join Open Play to Record Games"}
                </button>
              )}
            </div>
          ) : selectableGamePlayers.length < (matchType === "doubles" ? 4 : 2) ? (
            <p className="text-xs font-bold text-neutral-500 bg-neutral-100 p-3 rounded-xl border border-neutral-300">
              Need at least {matchType === "doubles" ? "4 players" : "2 players"} to record a {matchType} game. Add or join players above!
            </p>
          ) : (
            <form onSubmit={handleSubmitGame} className="space-y-4">
              {/* Quick Action Toolbar: Rotate Partners (doubles only), Swap Sides, Clear */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                {matchType === "doubles" && (
                  <button
                    type="button"
                    onClick={handleRotatePartners}
                    disabled={!canRotate}
                    data-testid="rotate-partners-button"
                    title="Split and switch partners between the 4 players"
                    className="inline-flex items-center gap-1 sm:gap-1.5 py-1.5 px-2 sm:px-3 rounded-xl border-2 border-black bg-white hover:bg-neutral-100 text-black text-[11px] sm:text-xs font-black shadow-[2px_2px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all whitespace-nowrap"
                  >
                    <RotateCwIcon className="h-3.5 w-3.5 shrink-0" />
                    <span>Rotate Partners</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleSwapSides}
                  disabled={!canSwapSides}
                  data-testid="swap-sides-button"
                  title={
                    matchType === "doubles"
                      ? "Swap sides between Team 1 and Team 2"
                      : "Swap sides between Player 1 and Player 2"
                  }
                  className="inline-flex items-center gap-1 sm:gap-1.5 py-1.5 px-2 sm:px-3 rounded-xl border-2 border-black bg-white hover:bg-neutral-100 text-black text-[11px] sm:text-xs font-black shadow-[2px_2px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all whitespace-nowrap"
                >
                  <ArrowLeftRightIcon className="h-3.5 w-3.5 shrink-0" />
                  <span>Swap Sides</span>
                </button>
                <button
                  type="button"
                  onClick={handleClearSlots}
                  data-testid="clear-slots-button"
                  title="Clear all player selections and scores"
                  className="inline-flex items-center gap-1 py-1.5 px-2 sm:px-2.5 rounded-xl border-2 border-black bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-black text-[11px] sm:text-xs font-bold shadow-[2px_2px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 cursor-pointer transition-all ml-auto whitespace-nowrap"
                >
                  <span>Clear</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Team 1 / Player 1 Card */}
                <div className="p-4 bg-[#ccff00]/20 border-2 border-black rounded-2xl space-y-3 shadow-[2px_2px_0px_0px_#000]">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-sm font-black uppercase text-black">
                      {matchType === "singles" ? "Player 1" : "Team 1"}
                    </h3>
                    <button
                      type="button"
                      onClick={() => handleSelectWinner(1)}
                      data-testid="team-1-winner-button"
                      aria-label={matchType === "singles" ? "Select Player 1 as Winner" : "Select Team 1 as Winner"}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 border-black text-[11px] sm:text-xs font-black uppercase transition-all cursor-pointer shadow-[2px_2px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 whitespace-nowrap shrink-0 ${
                        isT1Winner
                          ? "bg-black text-[#ccff00]"
                          : "bg-[#fde047] hover:bg-[#facc15] text-black"
                      }`}
                    >
                      <CrownIcon className={`h-3.5 w-3.5 shrink-0 ${isT1Winner ? "fill-current" : ""}`} />
                      <span>{isT1Winner ? "Winner" : "Select Winner"}</span>
                    </button>
                  </div>
                  <div className="space-y-2">
                    <FilterablePlayerSelect
                      ariaLabel={matchType === "singles" ? "Player 1" : "Team 1 Player 1"}
                      placeholder="Select Player 1..."
                      value={t1p1}
                      onChange={(val) => handleSelectGamePlayer("t1p1", val)}
                      options={getSlotOptions("t1p1")}
                      dataTestId="select-team-1-player-1"
                    />

                    {matchType === "doubles" && (
                      <FilterablePlayerSelect
                        ariaLabel="Team 1 Player 2"
                        placeholder="Select Player 2..."
                        value={t1p2}
                        onChange={(val) => handleSelectGamePlayer("t1p2", val)}
                        options={getSlotOptions("t1p2")}
                        dataTestId="select-team-1-player-2"
                      />
                    )}

                    <div className="pt-2">
                      <label className="block text-[11px] font-black uppercase text-black mb-1">
                        {matchType === "singles" ? "Player 1 Points" : "Team 1 Points"}
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        min="0"
                        placeholder="e.g. 11"
                        value={t1Score}
                        onChange={(e) => setT1Score(e.target.value)}
                        aria-label={matchType === "singles" ? "Player 1 Score" : "Team 1 Score"}
                        className="w-full p-2.5 rounded-xl border-2 border-black bg-white font-mono font-bold text-base text-center"
                      />
                    </div>
                  </div>
                </div>

                {/* Team 2 / Player 2 Card */}
                <div className="p-4 bg-[#fde047]/20 border-2 border-black rounded-2xl space-y-3 shadow-[2px_2px_0px_0px_#000]">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-sm font-black uppercase text-black">
                      {matchType === "singles" ? "Player 2" : "Team 2"}
                    </h3>
                    <button
                      type="button"
                      onClick={() => handleSelectWinner(2)}
                      data-testid="team-2-winner-button"
                      aria-label={matchType === "singles" ? "Select Player 2 as Winner" : "Select Team 2 as Winner"}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 border-black text-[11px] sm:text-xs font-black uppercase transition-all cursor-pointer shadow-[2px_2px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 whitespace-nowrap shrink-0 ${
                        isT2Winner
                          ? "bg-black text-[#ccff00]"
                          : "bg-[#fde047] hover:bg-[#facc15] text-black"
                      }`}
                    >
                      <CrownIcon className={`h-3.5 w-3.5 shrink-0 ${isT2Winner ? "fill-current" : ""}`} />
                      <span>{isT2Winner ? "Winner" : "Select Winner"}</span>
                    </button>
                  </div>
                  <div className="space-y-2">
                    <FilterablePlayerSelect
                      ariaLabel={matchType === "singles" ? "Player 2" : "Team 2 Player 1"}
                      placeholder={matchType === "singles" ? "Select Player 2..." : "Select Player 1..."}
                      value={t2p1}
                      onChange={(val) => handleSelectGamePlayer("t2p1", val)}
                      options={getSlotOptions("t2p1")}
                      dataTestId="select-team-2-player-1"
                    />

                    {matchType === "doubles" && (
                      <FilterablePlayerSelect
                        ariaLabel="Team 2 Player 2"
                        placeholder="Select Player 2..."
                        value={t2p2}
                        onChange={(val) => handleSelectGamePlayer("t2p2", val)}
                        options={getSlotOptions("t2p2")}
                        dataTestId="select-team-2-player-2"
                      />
                    )}

                    <div className="pt-2">
                      <label className="block text-[11px] font-black uppercase text-black mb-1">
                        {matchType === "singles" ? "Player 2 Points" : "Team 2 Points"}
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        min="0"
                        placeholder="e.g. 9"
                        value={t2Score}
                        onChange={(e) => setT2Score(e.target.value)}
                        aria-label={matchType === "singles" ? "Player 2 Score" : "Team 2 Score"}
                        className="w-full p-2.5 rounded-xl border-2 border-black bg-white font-mono font-bold text-base text-center"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmittingGame}
                data-testid="submit-game-button"
                className="w-full py-3.5 px-6 rounded-xl bg-black hover:bg-neutral-900 text-white font-display text-base font-black uppercase tracking-wider shadow-[4px_4px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-60 cursor-pointer transition-all"
              >
                {isSubmittingGame ? "Recording Game..." : isSessionActive ? "Record Game Result" : "Add Game Result"}
              </button>
            </form>
          )}
          {pickledGameId && allMatches.some(match => match.id === pickledGameId && isPickleScore(match.team1Score, match.team2Score)) && (
            <div className="pt-2">
              <PickleCelebration key={pickledGameId} />
            </div>
          )}
        </section>
      )}

      {/* Games Played Section */}
      <section className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] space-y-4">
        <h2 className="font-display text-xl font-black uppercase text-black">
          Games Played ({allMatches.length})
        </h2>

        {allMatches.length === 0 ? (
          <p className="text-xs font-bold text-neutral-500 italic py-2">
            No games submitted yet for this session. Record your first game above!
          </p>
        ) : (
          <div className="space-y-3" data-testid="open-play-matches-list">
            {allMatches.map((m, idx) => {
              const isT1Winner = (m.team1Score ?? 0) > (m.team2Score ?? 0);
              const isCompleted = m.status === "completed";
              const isCancelled = m.status === "cancelled";
              const isEditing = editingMatchId === m.id;

              if (isEditing) {
                return (
                  <form
                    key={m.id}
                    onSubmit={handleSaveEdit}
                    data-testid={`edit-game-form-${m.id}`}
                    className="p-4 bg-[#FFFDF7] border-2 border-black rounded-2xl space-y-4 shadow-[2px_2px_0px_0px_#000]"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-black uppercase text-black">
                          Edit Game {idx + 1}
                        </span>
                        {m.completedAt && (
                          <span className="text-[10px] font-bold text-neutral-500 flex items-center gap-1">
                            <span>•</span>
                            <ClientTime date={m.completedAt} />
                          </span>
                        )}
                      </div>
                      <div className="flex border-2 border-black rounded-xl overflow-hidden shadow-[1px_1px_0px_0px_#000] shrink-0">
                        <button
                          type="button"
                          onClick={() => setEditMatchType("doubles")}
                          className={`py-0.5 px-2 text-[10px] sm:text-[11px] font-black uppercase whitespace-nowrap ${
                            editMatchType === "doubles" ? "bg-[#ccff00] text-black" : "bg-white text-neutral-600"
                          }`}
                        >
                          Doubles
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEditMatchType("singles");
                            setEditT1p2("");
                            setEditT2p2("");
                          }}
                          className={`py-0.5 px-2 text-[10px] sm:text-[11px] font-black uppercase border-l-2 border-black whitespace-nowrap ${
                            editMatchType === "singles" ? "bg-[#ccff00] text-black" : "bg-white text-neutral-600"
                          }`}
                        >
                          Singles
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Team 1 / Player 1 */}
                      <div className="p-3 bg-[#ccff00]/20 border-2 border-black rounded-xl space-y-2">
                        <span className="text-[11px] font-black uppercase text-black block">
                          {editMatchType === "singles" ? "Player 1" : "Team 1"}
                        </span>
                        <FilterablePlayerSelect
                          ariaLabel={editMatchType === "singles" ? "Edit Player 1" : "Edit Team 1 Player 1"}
                          placeholder="Select Player 1..."
                          value={editT1p1}
                          onChange={(val) => handleSelectEditPlayer("t1p1", val)}
                          options={getEditSlotOptions("t1p1")}
                          sizeVariant="sm"
                          dataTestId={`select-edit-team-1-player-1-${m.id}`}
                        />
                        {editMatchType === "doubles" && (
                          <FilterablePlayerSelect
                            ariaLabel="Edit Team 1 Player 2"
                            placeholder="Select Player 2..."
                            value={editT1p2}
                            onChange={(val) => handleSelectEditPlayer("t1p2", val)}
                            options={getEditSlotOptions("t1p2")}
                            sizeVariant="sm"
                            dataTestId={`select-edit-team-1-player-2-${m.id}`}
                          />
                        )}
                        <div>
                          <label className="block text-[10px] font-black uppercase text-black mb-0.5">Score</label>
                          <input
                            type="number"
                            inputMode="numeric"
                            pattern="[0-9]*"
                            min="0"
                            aria-label={editMatchType === "singles" ? "Edit Player 1 Score" : "Edit Team 1 Score"}
                            value={editT1Score}
                            onChange={(e) => setEditT1Score(e.target.value)}
                            className="w-full p-1.5 rounded-lg border-2 border-black bg-white font-mono font-black text-center text-base"
                          />
                        </div>
                      </div>

                      {/* Team 2 / Player 2 */}
                      <div className="p-3 bg-[#fde047]/20 border-2 border-black rounded-xl space-y-2">
                        <span className="text-[11px] font-black uppercase text-black block">
                          {editMatchType === "singles" ? "Player 2" : "Team 2"}
                        </span>
                        <FilterablePlayerSelect
                          ariaLabel={editMatchType === "singles" ? "Edit Player 2" : "Edit Team 2 Player 1"}
                          placeholder={editMatchType === "singles" ? "Select Player 2..." : "Select Player 1..."}
                          value={editT2p1}
                          onChange={(val) => handleSelectEditPlayer("t2p1", val)}
                          options={getEditSlotOptions("t2p1")}
                          sizeVariant="sm"
                          dataTestId={`select-edit-team-2-player-1-${m.id}`}
                        />
                        {editMatchType === "doubles" && (
                          <FilterablePlayerSelect
                            ariaLabel="Edit Team 2 Player 2"
                            placeholder="Select Player 2..."
                            value={editT2p2}
                            onChange={(val) => handleSelectEditPlayer("t2p2", val)}
                            options={getEditSlotOptions("t2p2")}
                            sizeVariant="sm"
                            dataTestId={`select-edit-team-2-player-2-${m.id}`}
                          />
                        )}
                        <div>
                          <label className="block text-[10px] font-black uppercase text-black mb-0.5">Score</label>
                          <input
                            type="number"
                            inputMode="numeric"
                            pattern="[0-9]*"
                            min="0"
                            aria-label={editMatchType === "singles" ? "Edit Player 2 Score" : "Edit Team 2 Score"}
                            value={editT2Score}
                            onChange={(e) => setEditT2Score(e.target.value)}
                            className="w-full p-1.5 rounded-lg border-2 border-black bg-white font-mono font-black text-center text-base"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={handleCancelEdit}
                        disabled={isSavingEdit}
                        data-testid={`cancel-edit-game-button-${m.id}`}
                        className="py-1 px-3 rounded-xl border-2 border-black bg-white hover:bg-neutral-100 text-xs font-black uppercase tracking-wider cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSavingEdit}
                        data-testid={`save-edit-game-button-${m.id}`}
                        className="py-1 px-4 rounded-xl border-2 border-black bg-black text-white hover:bg-neutral-900 text-xs font-black uppercase tracking-wider shadow-[2px_2px_0px_0px_#000] disabled:opacity-60 cursor-pointer"
                      >
                        {isSavingEdit ? "Saving..." : "Save Changes"}
                      </button>
                    </div>
                  </form>
                );
              }

              return (
                <article
                  key={m.id}
                  className="p-3.5 bg-neutral-50 border-2 border-black rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-[2px_2px_0px_0px_#000]"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">
                        Game {idx + 1}
                      </span>
                      {isCompleted && m.completedAt && (
                        <span className="text-[10px] font-bold text-neutral-500 flex items-center gap-1">
                          <span>•</span>
                          <ClientTime date={m.completedAt} />
                        </span>
                      )}
                    </div>
                    <div className="text-sm font-bold flex flex-wrap items-center gap-1.5 text-black">
                      <span className={isCompleted && isT1Winner ? "font-black underline" : ""}>
                        {m.team1Names.join(" & ")}
                      </span>
                      <span className="text-xs font-normal text-neutral-500">vs</span>
                      <span className={isCompleted && !isT1Winner ? "font-black underline" : ""}>
                        {m.team2Names.join(" & ")}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Badge
                      variant={isCompleted ? "success" : isCancelled ? "muted" : "warning"}
                      className="font-mono text-sm px-3 py-1"
                    >
                      {isCompleted
                        ? `${m.team1Score} – ${m.team2Score}`
                        : isCancelled
                        ? "Deleted"
                        : "In Play"}
                    </Badge>

                    {canEditOrDelete && isCompleted && (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(m)}
                          data-testid={`edit-game-button-${m.id}`}
                          className="text-xs font-bold text-neutral-700 hover:text-black hover:underline cursor-pointer"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteMatch(m.id)}
                          data-testid={`delete-game-button-${m.id}`}
                          className="text-xs font-bold text-red-600 hover:underline cursor-pointer"
                        >
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
      </div>
    </div>
  );
}
