"use client";

import React, { useState, useEffect, useMemo, useTransition, useSyncExternalStore } from "react";
import { PartnerRequests } from "@/components/sessions/partner-requests";
import { StayTogetherEditor } from "@/components/attendance/stay-together-editor";
import { canonicalPairs } from "@/lib/matchmaking/stay-together";
import type { StayTogetherPair } from "@/lib/matchmaking/types";
import { useRouter } from "next/navigation";

import {
  addSessionGuestAction,
  changeAttendanceAction,
  completeRoundAction,
  endSessionAction,
  proposeRoundAction,
  reshuffleRoundAction,
  saveAndStartNextRoundAction,
  setMyAttendanceAction,
  startRoundAction,
  undoLatestRoundAction,
  updateCourtConfigAction,
  updateStayTogetherPairsAction,
} from "@/app/actions/sessions";
import { getCourtRebalanceChoices, type CourtChoice } from "@/lib/matchmaking/court-rebalance";
import { candidateKey } from "@/lib/matchmaking/generate-round";
import { proposeRoundFromSnapshot } from "@/lib/matchmaking/proposal";
import { cancelMatchAction, recordMultipleResultsAction, recordResultAction } from "@/app/actions/results";
import { isPickleScore } from "@/components/results/pickle-celebration";
import { RoundGenerationIndicator } from "@/components/rounds/round-generation-indicator";
import { CurrentRoundView } from "@/components/rounds/current-round";
import { ResultsEntryView, cancelMatchWarning, type MatchScoreEntry, type ScoreDrafts } from "@/components/results/results-entry";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Button, Badge, Modal, CustomDropdown, RatingSlider, Toast } from "@/components/ui";
import { ClientDate, ClientTime } from "@/components/ui/client-date-time";
import { BackButton } from "@/components/groups/back-button";
import { formatDupr, formatDuprDelta } from "@/lib/domain/rating-display";
import { ChevronDownIcon, GearIcon, PinIcon, SearchIcon, XIcon } from "@/components/ui/icons";
import {
  sortPlayersWithPinned,
  togglePinnedPlayer,
  usePinnedPlayerIds,
} from "@/lib/storage/pinned-players";
import type {
  AttendanceRecord,
  MatchPlayerRecord,
  PartnerRequestRecord,
  MatchRecord,
  PlayerRecord,
  RoundProposal,
  SessionRecord,
  StartedRoundRecord,
} from "@/lib/domain/types";
import { SessionSignOff } from "@/components/sessions/session-signoff";
import { markSessionEnded } from "@/lib/animations/session-signoff";
import { SessionNameEditor } from "@/components/sessions/session-name-editor";
import { SessionOptionsMenu } from "@/components/sessions/session-options-menu";
import { SessionHighlights } from "@/components/sessions/session-highlights";
import { AddPickupGameModal } from "@/components/sessions/add-pickup-game-modal";
import { clearLineupDraft, lineupDraftKey } from "@/lib/rounds/lineup-draft";
import {
  clearLineupChoice,
  defaultLineupSeed,
  parseLineupChoice,
  readLineupChoiceSnapshot,
  saveLineupChoice,
  subscribeLineupChoice,
} from "@/lib/rounds/lineup-seed";
import { createIdempotencyKey } from "@/lib/utils/idempotency";
import type { PairSynergiesMap } from "@/lib/synergy/lineup";
import { formatSessionDate } from "@/lib/utils/date";
import { useHydrated } from "@/lib/utils/hydration";
import { buildSessionLiveStamp } from "@/lib/sessions/live-stamp";
import { readScoreDrafts, scoreDraftsKey, writeScoreDrafts } from "@/lib/rounds/score-drafts";
import { buildPlayCounts } from "@/lib/sessions/play-count";
import { PlayCountPanel } from "@/components/sessions/play-count-panel";
import { useLiveSessionSync } from "@/lib/sessions/use-live-session-sync";

export type SessionSettingsTab = "attendance" | "court_config" | "partners" | "stay_together" | "preferences";

const CONFIRM_MATCHUPS_STORAGE_KEY = "pickleball_confirm_matchups";

function getConfirmMatchupsSnapshot(groupId: string): boolean {
  if (typeof window === "undefined") return false;
  try {
    const groupVal = window.localStorage.getItem(`${CONFIRM_MATCHUPS_STORAGE_KEY}_${groupId}`);
    if (groupVal !== null) return groupVal === "true";
    const globalVal = window.localStorage.getItem(CONFIRM_MATCHUPS_STORAGE_KEY);
    if (globalVal !== null) return globalVal === "true";
  } catch {
    // localStorage unavailable
  }
  return false;
}

function subscribeConfirmMatchups(groupId: string, callback: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = () => callback();
  const eventName = `pickleball_confirm_matchups_changed_${groupId}`;
  window.addEventListener("storage", handler);
  window.addEventListener(eventName, handler);
  return () => {
    window.removeEventListener("storage", handler);
    window.removeEventListener(eventName, handler);
  };
}

export interface SessionManagerClientProps {
  readonly groupId: string;
  readonly groupName?: string;
  readonly session: SessionRecord;
  readonly players: readonly PlayerRecord[];
  readonly attendance?: readonly AttendanceRecord[];
  readonly startedRounds: readonly StartedRoundRecord[];
  readonly initialProposal: RoundProposal | null;
  readonly partnerRequests?: readonly PartnerRequestRecord[];
  readonly initialProposalError?: string | null;
  readonly canManage?: boolean;
  readonly currentViewerPlayerId?: string | null;
  readonly pairSynergies?: PairSynergiesMap;
  readonly isOrganizer?: boolean;
  readonly isHost?: boolean;
  readonly isFromProfile?: boolean;
  readonly initialOpenSettingsModal?: boolean;
  readonly initialSettingsModalTab?: SessionSettingsTab;
  readonly initialAddGuestOpen?: boolean;
}

export function SessionManagerClient({
  groupId,
  groupName,
  session,
  players,
  attendance = [],
  startedRounds,
  initialProposal,
  partnerRequests = [],
  initialProposalError = null,
  canManage = true,
  currentViewerPlayerId = null,
  pairSynergies = {},
  isOrganizer = false,
  isHost = false,
  isFromProfile = false,
  initialOpenSettingsModal = false,
  initialSettingsModalTab,
  initialAddGuestOpen = false,
}: SessionManagerClientProps) {
  const router = useRouter();
  const isHydrated = useHydrated();

  const [prevPlayers, setPrevPlayers] = useState(players);
  const [sessionPlayers, setSessionPlayers] = useState(players);
  if (players !== prevPlayers) {
    setPrevPlayers(players);
    setSessionPlayers(players);
  }

  const [guestName, setGuestName] = useState("");
  const [guestGender, setGuestGender] = useState<"male" | "female">("male");
  const [guestRating, setGuestRating] = useState(3.5);
  const [isAddGuestOpen, setIsAddGuestOpen] = useState(initialAddGuestOpen);
  const [isAddingGuest, setIsAddingGuest] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const toastTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = (msg: string) => {
    if (toastTimeoutRef.current !== null) clearTimeout(toastTimeoutRef.current);
    setSuccessToast(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setSuccessToast(null);
      toastTimeoutRef.current = null;
    }, 3000);
  };

  useEffect(() => {
    return () => {
      if (toastTimeoutRef.current !== null) clearTimeout(toastTimeoutRef.current);
    };
  }, []);

  // Players watching a live session follow the organizer's round changes, scores,
  // and session end without reloading. Organizers already refresh after their own
  // actions, and polling under them could disturb score drafts mid-entry.
  const liveStamp = useMemo(() => buildSessionLiveStamp(session, startedRounds), [session, startedRounds]);
  useLiveSessionSync({
    enabled: !canManage && session.status === "active",
    groupId,
    sessionId: session.id,
    stamp: liveStamp,
  });

  const pinnedPlayerIds = usePinnedPlayerIds(groupId);
  const [attendanceSearchQuery, setAttendanceSearchQuery] = useState("");

  const sortedPlayers = useMemo(
    () =>
      sortPlayersWithPinned(
        sessionPlayers.filter((p) => p.active),
        pinnedPlayerIds,
      ),
    [sessionPlayers, pinnedPlayerIds],
  );

  const displayedAttendancePlayers = useMemo(() => {
    const q = attendanceSearchQuery.trim().toLowerCase();
    if (!q) return sortedPlayers;
    return sortedPlayers.filter((p) => p.name.toLowerCase().includes(q));
  }, [sortedPlayers, attendanceSearchQuery]);

  const [prevSession, setPrevSession] = useState(session);
  const [currentSession, setCurrentSession] = useState(session);
  const [sessionName, setSessionName] = useState(session.name ?? null);
  if (session !== prevSession) {
    setPrevSession(session);
    setCurrentSession(session);
    setSessionName(session.name ?? null);
  }

  const formattedDate = isHydrated ? formatSessionDate(session.startedAt) : "";
  const initialSessionName = sessionName || formattedDate;

  const [prevInitialProposal, setPrevInitialProposal] = useState(initialProposal);
  const [regeneratedProposal, setRegeneratedProposal] = useState<RoundProposal | null>(null);
  if (initialProposal !== prevInitialProposal) {
    setPrevInitialProposal(initialProposal);
    setRegeneratedProposal(null);
  }

  const [savingMatchIds, setSavingMatchIds] = useState<Set<string>>(() => new Set());
  const [prevAttendance, setPrevAttendance] = useState(attendance);
  const [currentAttendance, setCurrentAttendance] = useState(attendance);
  // Set when the server rejected a stale lineup; cleared once fresh attendance arrives.
  const [isAwaitingFreshLineup, setIsAwaitingFreshLineup] = useState(false);
  if (attendance !== prevAttendance) {
    setPrevAttendance(attendance);
    setCurrentAttendance(attendance);
    setIsAwaitingFreshLineup(false);
  }


  const [prevStartedRounds, setPrevStartedRounds] = useState(startedRounds);
  const [localStartedRounds, setLocalStartedRounds] = useState<readonly StartedRoundRecord[]>(startedRounds);
  if (startedRounds !== prevStartedRounds) {
    setPrevStartedRounds(startedRounds);
    setLocalStartedRounds(
      startedRounds.map((sr) => {
        const localSr = localStartedRounds.find((l) => l.round.id === sr.round.id);
        return {
          ...sr,
          matches: sr.matches.map((serverMatch) => {
            if (serverMatch.status !== "pending") return serverMatch;
            const localMatch =
              localSr?.matches.find((lm) => lm.id === serverMatch.id) ??
              localStartedRounds.flatMap((r) => r.matches).find((lm) => lm.id === serverMatch.id);
            if (localMatch && (localMatch.status !== "pending" || savingMatchIds.has(serverMatch.id))) {
              return localMatch;
            }
            return serverMatch;
          }),
        };
      })
    );
  }

  const [pickledMatchId, setPickledMatchId] = useState<string | null>(null);
  const [isActionPending, setIsPending] = useState(false);
  const [isGeneratingRound, startGeneratingRound] = useTransition();
  const [isCourtConfigPending, startCourtConfigTransition] = useTransition();
  const [isRequestPending, setRequestPending] = useState(false);
  const isPending = isActionPending || isGeneratingRound || isCourtConfigPending || isRequestPending || isAwaitingFreshLineup;
  const [error, setError] = useState<string | null>(null);
  const [scoreDrafts, setScoreDrafts] = useState<ScoreDrafts>({});
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [showInProgressModal, setShowInProgressModal] = useState(false);
  const [doNotAskAgain, setDoNotAskAgain] = useState(false);
  const [showSessionSettingsModal, setShowSessionSettingsModal] = useState(initialOpenSettingsModal);

  // Attendance rows stay in the section they were in when Settings opened, so a row
  // doesn't jump out from under the organizer's thumb as they mark arrivals and
  // departures. Sections regroup the next time Settings opens.
  const isPresentNow = (playerId: string) => {
    const rec = currentAttendance.find((a) => a.playerId === playerId);
    return rec ? rec.leftRound === null : false;
  };
  const [attendanceLayout, setAttendanceLayout] = useState<ReadonlyMap<string, boolean> | null>(null);
  const [layoutForOpenModal, setLayoutForOpenModal] = useState(false);
  if (showSessionSettingsModal !== layoutForOpenModal) {
    setLayoutForOpenModal(showSessionSettingsModal);
    setAttendanceLayout(
      showSessionSettingsModal ? new Map(sessionPlayers.map((p) => [p.id, isPresentNow(p.id)])) : null,
    );
  }
  const isInPresentSection = (playerId: string) => attendanceLayout?.get(playerId) ?? isPresentNow(playerId);
  const presentAttendancePlayers = displayedAttendancePlayers.filter((p) => isInPresentSection(p.id));
  const notPresentAttendancePlayers = displayedAttendancePlayers.filter((p) => !isInPresentSection(p.id));
  const [showAddPickupModal, setShowAddPickupModal] = useState(false);
  const [modalTab, setModalTab] = useState<SessionSettingsTab>(
    initialSettingsModalTab === "stay_together"
      ? "partners"
      : (initialSettingsModalTab ?? "attendance")
  );
  const [courtConfigCourts, setCourtConfigCourts] = useState<number>(session.courtCount);
  const [courtConfigPlayerCounts, setCourtConfigPlayerCounts] = useState<(2 | 3 | 4)[]>(
    () =>
      session.courtPlayerCounts && session.courtPlayerCounts.length === session.courtCount
        ? [...session.courtPlayerCounts]
        : Array.from({ length: session.courtCount }, () => 4 as const)
  );
  const [editingHistoricalMatchId, setEditingHistoricalMatchId] = useState<string | null>(null);
  const [matchPendingCancel, setMatchPendingCancel] = useState<MatchScoreEntry | null>(null);
  const [isMyAttendancePending, setIsMyAttendancePending] = useState(false);
  // Only an actual end-session request says "Ending…"; other actions just disable the button.
  const [isEnding, setIsEnding] = useState(false);
  const [justEndedSession, setJustEndedSession] = useState(false);
  const [myAttendanceError, setMyAttendanceError] = useState<string | null>(null);
  const [historicalScores, setHistoricalScores] = useState<{ team1: string; team2: string }>({ team1: "", team2: "" });
  const confirmMatchups = useSyncExternalStore(
    (cb) => subscribeConfirmMatchups(groupId, cb),
    () => getConfirmMatchupsSnapshot(groupId),
    () => false
  );

  const handleToggleConfirmMatchups = (enabled: boolean) => {
    try {
      window.localStorage.setItem(`${CONFIRM_MATCHUPS_STORAGE_KEY}_${groupId}`, String(enabled));
      window.localStorage.setItem(CONFIRM_MATCHUPS_STORAGE_KEY, String(enabled));
      window.dispatchEvent(new Event(`pickleball_confirm_matchups_changed_${groupId}`));
    } catch {
      // localStorage unavailable
    }
  };

  const handlePickupGameAdded = (match: MatchRecord, matchPlayers: readonly MatchPlayerRecord[]) => {
    let hadNoRound = false;
    setLocalStartedRounds((prev) => {
      const target = prev.find((sr) => sr.round.id === match.roundId);
      if (!target) {
        hadNoRound = true;
        const newRoundNumber = prev.length + 1;
        const completedDate =
          match.completedAt instanceof Date
            ? match.completedAt
            : match.completedAt
              ? new Date(match.completedAt)
              : new Date();
        const newRoundRecord: StartedRoundRecord = {
          round: {
            id: match.roundId,
            sessionId: currentSession.id,
            roundNumber: newRoundNumber,
            status: "completed",
            seed: 0,
            scoreBreakdown: {
              playingTime: 0,
              consecutiveSit: 0,
              partnerRepeat: 0,
              skillBalance: 0,
              opponentRepeat: 0,
              tieBreak: 0,
              total: 0,
            },
            createdAt: completedDate,
            startedAt: completedDate,
            completedAt: completedDate,
            version: 1,
          },
          matches: [match],
          matchPlayers: [...matchPlayers],
          sits: [],
        };
        return [...prev, newRoundRecord];
      }
      return prev.map((sr) => {
        if (sr.round.id !== match.roundId) return sr;
        return {
          ...sr,
          matches: [...sr.matches.filter((m) => m.id !== match.id), match],
          matchPlayers: [
            ...(sr.matchPlayers ?? []).filter((mp) => mp.matchId !== match.id),
            ...matchPlayers,
          ],
        };
      });
    });
    if (hadNoRound) {
      setCurrentSession((prev) => ({
        ...prev,
        currentRoundNumber: Math.max(prev.currentRoundNumber, 1),
        version: prev.version + 1,
      }));
      if (canManage) {
        handleRegenerate();
      }
    }
    router.refresh();
  };

  const openSessionSettingsModal = (tab: SessionSettingsTab = "attendance") => {
    setModalTab(tab === "stay_together" ? "partners" : tab);
    setCourtConfigCourts(currentSession.courtCount);
    setCourtConfigPlayerCounts(
      currentSession.courtPlayerCounts && currentSession.courtPlayerCounts.length === currentSession.courtCount
        ? [...currentSession.courtPlayerCounts]
        : Array.from({ length: currentSession.courtCount }, () => 4 as const)
    );
    setShowSessionSettingsModal(true);
  };

  const presentAttendance = currentAttendance.filter((a) => a.leftRound === null);
  const presentCount = presentAttendance.length;

  const saveCourtConfig = (targetCourts: number, targetPlayerCounts: (2 | 3 | 4)[]) => {
    const counts = targetPlayerCounts.slice(0, targetCourts);
    const capacity = counts.reduce((sum, s) => sum + s, 0);
    setCourtConfigCourts(targetCourts);
    setCourtConfigPlayerCounts(targetPlayerCounts);

    if (capacity > presentCount || targetCourts < 1) {
      return;
    }

    startCourtConfigTransition(async () => {
      setIsPending(true);
      setError(null);
      try {
        const res = await updateCourtConfigAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          courtCount: targetCourts,
          courtPlayerCounts: counts,
          idempotencyKey: createIdempotencyKey("court_cfg"),
        });
        if (res.ok) {
          setCurrentSession(res.data.session);
          clearLineupDraft(lineupDraftKey(currentSession.id));
          if (res.data.proposal) {
            setRegeneratedProposal(res.data.proposal);
          } else {
            setRegeneratedProposal(null);
          }
          showToast("Court configuration updated successfully.");
        } else {
          setError(res.error);
        }
      } catch {
        setError("Failed to update court configuration.");
      } finally {
        setIsPending(false);
      }
    });
  };

  const decreaseCourts = () => {
    if (courtConfigCourts > 1) {
      const nextCourts = courtConfigCourts - 1;
      const nextCounts = courtConfigPlayerCounts.slice(0, nextCourts);
      saveCourtConfig(nextCourts, nextCounts);
    }
  };

  const increaseCourts = () => {
    const maxCourts = Math.min(32, Math.max(1, Math.floor(presentCount / 2)));
    if (courtConfigCourts < maxCourts) {
      const nextCourtIndex = courtConfigCourts;
      const currentCapacity = courtConfigPlayerCounts.slice(0, nextCourtIndex).reduce((sum, s) => sum + s, 0);
      const remainingPlayers = presentCount - currentCapacity;
      const nextSize: 2 | 3 | 4 = remainingPlayers >= 4 ? 4 : remainingPlayers >= 3 ? 3 : 2;
      const nextCourts = courtConfigCourts + 1;
      const nextCounts = [...courtConfigPlayerCounts.slice(0, nextCourtIndex), nextSize];
      saveCourtConfig(nextCourts, nextCounts);
    }
  };

  const handleCourtSizeChange = (index: number, size: 2 | 3 | 4) => {
    const next = [...courtConfigPlayerCounts];
    next[index] = size;
    saveCourtConfig(courtConfigCourts, next);
  };

  const configCapacity = courtConfigPlayerCounts.slice(0, courtConfigCourts).reduce((sum, s) => sum + s, 0);
  const configSitting = Math.max(0, presentCount - configCapacity);
  const isOverCapacity = configCapacity > presentCount;

  const [showAttendanceRebalancePrompt, setShowAttendanceRebalancePrompt] = useState(false);

  const baseCourtCount = Math.max(1, currentSession.courtCount);
  const rebalanceChoices = useMemo(() => {
    return getCourtRebalanceChoices(presentCount, baseCourtCount, 6);
  }, [presentCount, baseCourtCount]);

  const currentCourts = courtConfigPlayerCounts.slice(0, courtConfigCourts);
  const isChoiceCurrent = (choice: CourtChoice) =>
    choice.courtCount === courtConfigCourts &&
    choice.courts.length === currentCourts.length &&
    choice.courts.every((s, i) => s === currentCourts[i]);

  const shouldShowRebalancePrompt =
    (isOverCapacity || showAttendanceRebalancePrompt) &&
    rebalanceChoices.length > 0 &&
    (!rebalanceChoices.every((c) => isChoiceCurrent(c)) || isOverCapacity);

  const handleApplyCourtChoice = (choice: CourtChoice) => {
    startCourtConfigTransition(async () => {
      setIsPending(true);
      setError(null);
      try {
        const res = await updateCourtConfigAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          courtCount: choice.courtCount,
          courtPlayerCounts: choice.courts,
          idempotencyKey: createIdempotencyKey("court_rebal"),
        });
        if (res.ok) {
          setCurrentSession(res.data.session);
          setCourtConfigCourts(choice.courtCount);
          setCourtConfigPlayerCounts(choice.courts);
          clearLineupDraft(lineupDraftKey(currentSession.id));
          if (res.data.proposal) {
            setRegeneratedProposal(res.data.proposal);
          } else {
            setRegeneratedProposal(null);
          }
          setShowAttendanceRebalancePrompt(false);
          showToast("Court configuration updated successfully.");
        } else {
          setError(res.error);
        }
      } catch {
        setError("Failed to update court configuration.");
      } finally {
        setIsPending(false);
      }
    });
  };

  const handleSaveCourtConfig = () => {
    // The action result and its revalidated server tree can commit separately.
    // Keep Start disabled until both have settled so the editor cannot remount
    // underneath an already-open confirmation dialog.
    startCourtConfigTransition(async () => {
      setIsPending(true);
      setError(null);
      try {
        const res = await updateCourtConfigAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          courtCount: courtConfigCourts,
          courtPlayerCounts: courtConfigPlayerCounts.slice(0, courtConfigCourts),
          idempotencyKey: createIdempotencyKey("court_cfg"),
        });
        if (res.ok) {
          setCurrentSession(res.data.session);
          clearLineupDraft(lineupDraftKey(currentSession.id));
          if (res.data.proposal) {
            setRegeneratedProposal(res.data.proposal);
          } else {
            setRegeneratedProposal(null);
          }
          showToast("Court configuration updated successfully.");
        } else {
          setError(res.error);
        }
      } catch {
        setError("Failed to update court configuration.");
      } finally {
        setIsPending(false);
      }
    });
  };


  useEffect(() => {
    const handlePageShow = (event: PageTransitionEvent) => {
      if (event.persisted) {
        router.refresh();
      }
    };
    window.addEventListener("pageshow", handlePageShow);
    return () => window.removeEventListener("pageshow", handlePageShow);
  }, [router]);

  const { playerNames, playerAccounts } = useMemo(() => {
    const names: Record<string, string> = {};
    const accounts: Record<string, string | null> = {};
    for (const p of sessionPlayers) {
      names[p.id] = p.name;
      accounts[p.id] = p.accountId ?? null;
    }
    return { playerNames: names, playerAccounts: accounts };
  }, [sessionPlayers]);

  const latestStarted = localStartedRounds.at(-1);
  const isRoundInProgress = latestStarted && latestStarted.round.status === "started";

  // Typed-but-unsaved scores survive a reload of this tab (a phone locking courtside).
  const scoreDraftStorageKey = canManage && isRoundInProgress && latestStarted ? scoreDraftsKey(latestStarted.round.id) : null;
  const [restoredScoreDraftsFor, setRestoredScoreDraftsFor] = useState<string | null>(null);
  if (isHydrated && scoreDraftStorageKey && restoredScoreDraftsFor !== scoreDraftStorageKey && latestStarted) {
    setRestoredScoreDraftsFor(scoreDraftStorageKey);
    const pendingIds = new Set(latestStarted.matches.filter((m) => m.status === "pending").map((m) => m.id));
    const restored = readScoreDrafts(scoreDraftStorageKey, pendingIds);
    if (restored) setScoreDrafts((prev) => ({ ...restored, ...prev }));
  }
  useEffect(() => {
    if (scoreDraftStorageKey && restoredScoreDraftsFor === scoreDraftStorageKey) {
      writeScoreDrafts(scoreDraftStorageKey, scoreDrafts);
    }
  }, [scoreDraftStorageKey, restoredScoreDraftsFor, scoreDrafts]);

  // The next round's lineup. Its default seed is fixed per session and round, so
  // reloads and other organizer devices agree. A Reshuffle or variety change made
  // on this device is remembered until that round starts.
  const proposalRoundNumber = (latestStarted?.round.roundNumber ?? 0) + (isRoundInProgress ? 0 : 1);
  const storedLineupChoiceRaw = useSyncExternalStore(
    subscribeLineupChoice,
    () => readLineupChoiceSnapshot(session.id),
    () => "",
  );
  const storedLineupChoice = parseLineupChoice(storedLineupChoiceRaw, proposalRoundNumber, currentSession.version);
  const storedChoiceProposal = useMemo(() => {
    if (!storedLineupChoice || isRoundInProgress || !canManage) return null;
    try {
      return proposeRoundFromSnapshot(
        { session: currentSession, players: sessionPlayers, attendance: currentAttendance, rounds: localStartedRounds },
        storedLineupChoice.seed,
        storedLineupChoice.temperature,
      );
    } catch {
      return null;
    }
    // storedLineupChoice is re-parsed every render; its raw string is the stable dependency.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storedLineupChoiceRaw, proposalRoundNumber, isRoundInProgress, canManage, currentSession, sessionPlayers, currentAttendance, localStartedRounds]);
  const activeProposal = regeneratedProposal ?? storedChoiceProposal ?? initialProposal;

  const [varietyOverride, setMatchmakingVariety] = useState<number | null>(null);
  const matchmakingVariety = varietyOverride ?? storedLineupChoice?.temperature ?? 0;

  const preGeneratedProposal = useMemo(() => {
    if (!latestStarted || latestStarted.round.status !== "started") return null;
    try {
      return proposeRoundFromSnapshot(
        {
          session: currentSession,
          players: sessionPlayers,
          attendance: currentAttendance,
          rounds: localStartedRounds,
        },
        defaultLineupSeed(currentSession.id, latestStarted.round.roundNumber + 1),
        matchmakingVariety,
      );
    } catch {
      return null;
    }
  }, [currentSession, sessionPlayers, currentAttendance, localStartedRounds, latestStarted, matchmakingVariety]);

  const applyPartnerSession = async (updated: SessionRecord) => {
    setCurrentSession(updated);
    clearLineupDraft(lineupDraftKey(updated.id));
    clearLineupChoice(updated.id);
    setRegeneratedProposal(null);
    if (canManage && updated.status === "active" && !isRoundInProgress) {
      const generated = await proposeRoundAction({
        groupId,
        sessionId: updated.id,
        sessionVersion: updated.version,
        seed: defaultLineupSeed(updated.id, proposalRoundNumber),
        temperature: matchmakingVariety,
      });
      if (generated.ok) setRegeneratedProposal(generated.data);
      else setError(generated.error);
    }
    router.refresh();
  };

  const handleSavePairs = async (pairs: readonly StayTogetherPair[]) => {
    if (isPending) return;
    setIsPending(true);
    setError(null);
    try {
      const saved = await updateStayTogetherPairsAction({ groupId, sessionId: currentSession.id, sessionVersion: currentSession.version, pairs });
      if (!saved.ok) { setError(saved.error); return; }
      await applyPartnerSession(saved.data);
    } catch {
      setError("Unable to save Stay Together pairs. Refresh and try again.");
    } finally {
      setIsPending(false);
    }
  };

  // Actions
  const handleRegenerate = (variety = matchmakingVariety) => {
    if (isPending) return;
    setError(null);
    startGeneratingRound(async () => {
      try {
        let nextSeed = Math.floor(Math.random() * 0xffff_ffff);
        if (activeProposal && nextSeed === activeProposal.seed) {
          nextSeed = (nextSeed + 1) % 0xffff_ffff;
        }
        let res = await proposeRoundAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          seed: nextSeed,
          temperature: variety,
        });
        if (res.ok) {
          const currentKey = activeProposal ? candidateKey(activeProposal) : "";
          if (currentKey && candidateKey(res.data) === currentKey) {
            for (let attempt = 0; attempt < 3; attempt++) {
              const retrySeed = Math.floor(Math.random() * 0xffff_ffff);
              const retryRes = await proposeRoundAction({
                groupId,
                sessionId: currentSession.id,
                sessionVersion: currentSession.version,
                seed: retrySeed,
                temperature: variety,
              });
              if (retryRes.ok && candidateKey(retryRes.data) !== currentKey) {
                res = retryRes;
                break;
              }
            }
          }

          if (currentKey && candidateKey(res.data) === currentKey) {
            setError("No alternative lineup was found. The current lineup remains the fairest available matchup.");
            return;
          }

          clearLineupDraft(lineupDraftKey(currentSession.id));
          saveLineupChoice(currentSession.id, {
            roundNumber: proposalRoundNumber,
            sessionVersion: currentSession.version,
            seed: res.data.seed,
            temperature: variety,
          });
          setRegeneratedProposal(res.data);
        } else {
          setError(res.error);
        }
      } catch {
        setError("Failed to reshuffle matchups.");
      }
    });
  };

  const handleChangeVariety = (newVariety: number) => {
    setMatchmakingVariety(newVariety);
    handleRegenerate(newVariety);
  };

  const handleReshuffleInProgressRound = () => {
    if (!latestStarted || isPending) return;
    if (
      !confirm(
        `Are you sure you want to reshuffle Round ${latestStarted.round.roundNumber} matchups? Any entered match scores for this round will be reset.`
      )
    ) {
      return;
    }
    setError(null);
    startGeneratingRound(async () => {
      try {
        const res = await reshuffleRoundAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          roundId: latestStarted.round.id,
          roundVersion: latestStarted.round.version,
          idempotencyKey: createIdempotencyKey("reshuffle"),
          temperature: matchmakingVariety,
        });
        if (res.ok) {
          clearLineupDraft(lineupDraftKey(currentSession.id));
          saveLineupChoice(currentSession.id, {
            roundNumber: latestStarted.round.roundNumber,
            sessionVersion: currentSession.version + 1,
            seed: res.data.seed,
            temperature: matchmakingVariety,
          });
          startGeneratingRound(() => {
            setRegeneratedProposal(res.data);
            setLocalStartedRounds((prev) => prev.filter((r) => r.round.id !== latestStarted.round.id));
            setCurrentSession((prev) => ({
              ...prev,
              currentRoundNumber: Math.max(0, prev.currentRoundNumber - 1),
              version: prev.version + 1,
            }));
            setScoreDrafts({});
            // The revalidating action already returns the fresh server tree.
          });
        } else {
          setError(res.error);
        }
      } catch {
        setError("Failed to reshuffle matchups.");
      }
    });
  };

  // A lineup can go stale when a player leaves from their phone or another organizer
  // changes attendance. The server names who changed; refreshing pulls in the current
  // attendance so the next tap uses an up-to-date lineup.
  const reportStartError = (message: string) => {
    if (!/out of date/i.test(message)) {
      setError(message);
      return;
    }
    setError(`${message.replace(/ Refresh the lineup before starting\.$/, "")} The lineup has been updated, so check it and try again.`);
    // Hold the start buttons until the refreshed attendance lands, so a quick retry
    // can't resend the same stale lineup. The timeout is a safety net.
    setIsAwaitingFreshLineup(true);
    router.refresh();
    setTimeout(() => setIsAwaitingFreshLineup(false), 8_000);
  };

  const handleStartRound = (customProposal?: {
    courts: readonly { courtNumber: number; team1: readonly string[]; team2: readonly string[] }[];
    sitting: readonly string[];
  }) => {
    if (!activeProposal || isPending) return;
    setError(null);
    const proposalToUse = customProposal ?? activeProposal;
    startGeneratingRound(async () => {
      try {
        const res = await startRoundAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          seed: activeProposal.seed,
          idempotencyKey: createIdempotencyKey("start_rd"),
          manualCourts: proposalToUse.courts.map((c) => ({
            courtNumber: c.courtNumber,
            team1: [...c.team1],
            team2: [...c.team2],
          })),
          manualSitting: [...proposalToUse.sitting],
        });
        if (res.ok) {
          clearLineupDraft(lineupDraftKey(currentSession.id));
          clearLineupChoice(currentSession.id);
          startGeneratingRound(() => {
            setRegeneratedProposal(null);
            setCurrentSession((prev) => ({
              ...prev,
              currentRoundNumber: res.data.roundNumber,
              version: prev.version + 1,
            }));
            // The revalidating action already returns the fresh server tree.
          });
        } else {
          reportStartError(res.error);
        }
      } catch {
        setError("Failed to start round.");
      }
    });
  };

  const handleSaveAllScores = async () => {
    if (!latestStarted) return;
    const entriesToSave: { matchId: string; team1Score: number; team2Score: number; version: number }[] = [];
    for (const match of scoreEntries) {
      const draft = scoreDrafts[match.id];
      if (draft && draft.team1 !== "" && draft.team2 !== "") {
        const t1 = parseInt(draft.team1, 10);
        const t2 = parseInt(draft.team2, 10);
        if (!isNaN(t1) && !isNaN(t2) && t1 !== t2 && t1 >= 0 && t2 >= 0) {
          entriesToSave.push({ matchId: match.id, team1Score: t1, team2Score: t2, version: match.version });
        }
      }
    }
    if (entriesToSave.length === 0) return;

    const matchIds = new Set(entriesToSave.map((e) => e.matchId));
    setSavingMatchIds((prev) => new Set([...prev, ...matchIds]));
    setError(null);

    try {
      const res = await recordMultipleResultsAction({
        groupId,
        sessionId: currentSession.id,
        results: entriesToSave.map((e) => ({
          matchId: e.matchId,
          team1Score: e.team1Score,
          team2Score: e.team2Score,
          matchVersion: e.version,
        })),
        idempotencyKey: createIdempotencyKey("save_all"),
      });
      if (res.ok) {
        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.map((m) => {
              const saved = entriesToSave.find((e) => e.matchId === m.id);
              return saved
                ? {
                    ...m,
                    status: "completed" as const,
                    team1Score: saved.team1Score,
                    team2Score: saved.team2Score,
                    completedAt: m.completedAt ?? new Date(),
                    version: m.version + 1,
                  }
                : m;
            }),
          }))
        );
        setScoreDrafts((prev) => {
          const next = { ...prev };
          for (const entry of entriesToSave) {
            delete next[entry.matchId];
          }
          return next;
        });
        const pickle = entriesToSave.find((e) => isPickleScore(e.team1Score, e.team2Score));
        setPickledMatchId(pickle ? pickle.matchId : null);
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to save match results.");
    } finally {
      setSavingMatchIds((prev) => {
        const next = new Set(prev);
        for (const entry of entriesToSave) {
          next.delete(entry.matchId);
        }
        return next;
      });
    }
  };

  const handleSaveAndStartNextRound = async () => {
    if (!latestStarted || isPending) return;
    const entriesToSave: { matchId: string; team1Score: number; team2Score: number; version: number }[] = [];
    for (const match of scoreEntries) {
      const draft = scoreDrafts[match.id];
      if (draft && draft.team1 !== "" && draft.team2 !== "") {
        const t1 = parseInt(draft.team1, 10);
        const t2 = parseInt(draft.team2, 10);
        if (!isNaN(t1) && !isNaN(t2) && t1 !== t2 && t1 >= 0 && t2 >= 0) {
          entriesToSave.push({ matchId: match.id, team1Score: t1, team2Score: t2, version: match.version });
        }
      }
    }
    setError(null);
    const proposalToUse = preGeneratedProposal;
    const previousRounds = localStartedRounds;
    const previousSession = currentSession;
    const previousDrafts = scoreDrafts;

    if (confirmMatchups) {
      // Optimistically advance to the proposed round screen (CurrentRoundView for matchup review and manual edit)
      setLocalStartedRounds((prev) =>
        prev.map((sr) =>
          sr.round.id === latestStarted.round.id
            ? {
                ...sr,
                round: {
                  ...sr.round,
                  status: "completed" as const,
                  completedAt: latestStarted.round.startedAt,
                  version: sr.round.version + 1,
                },
                matches: sr.matches.map((m) => {
                  const saved = entriesToSave.find((e) => e.matchId === m.id);
                  return saved
                    ? {
                        ...m,
                        status: "completed" as const,
                        team1Score: saved.team1Score,
                        team2Score: saved.team2Score,
                        version: m.version + 1,
                      }
                    : m;
                }),
              }
            : sr
        )
      );
      if (proposalToUse) {
        setRegeneratedProposal(proposalToUse);
      }
      setScoreDrafts({});

      startGeneratingRound(async () => {
        try {
          if (entriesToSave.length > 0) {
            await recordMultipleResultsAction({
              groupId,
              sessionId: currentSession.id,
              results: entriesToSave.map((e) => ({
                matchId: e.matchId,
                team1Score: e.team1Score,
                team2Score: e.team2Score,
                matchVersion: e.version,
              })),
              idempotencyKey: createIdempotencyKey("save_results"),
            });
          }
          const res = await completeRoundAction({
            groupId,
            sessionId: currentSession.id,
            sessionVersion: currentSession.version,
            roundId: latestStarted.round.id,
            roundVersion: latestStarted.round.version,
            idempotencyKey: createIdempotencyKey("complete_rd"),
          });
          if (res.ok) {
            if (!proposalToUse) {
              const generated = await proposeRoundAction({
                groupId,
                sessionId: currentSession.id,
                sessionVersion: currentSession.version,
                seed: defaultLineupSeed(currentSession.id, latestStarted.round.roundNumber + 1),
                temperature: matchmakingVariety,
              });
              if (generated.ok) {
                setRegeneratedProposal(generated.data);
              }
            }
          } else {
            setLocalStartedRounds(previousRounds);
            setCurrentSession(previousSession);
            setScoreDrafts(previousDrafts);
            reportStartError(res.error);
          }
        } catch {
          setLocalStartedRounds(previousRounds);
          setCurrentSession(previousSession);
          setScoreDrafts(previousDrafts);
          setError("Failed to advance to next round.");
        }
      });
      return;
    }

    // Optimistically advance UI immediately on click
    if (proposalToUse) {
      const nextRoundNumber = latestStarted.round.roundNumber + 1;
      const roundSeed = proposalToUse.seed;
      const tempRoundId = `temp_round_${currentSession.id}_${nextRoundNumber}_${roundSeed}`;
      const optimisticMatches: MatchRecord[] = proposalToUse.courts.map((court, i) => ({
        id: `temp_match_${currentSession.id}_${nextRoundNumber}_${i}`,
        roundId: tempRoundId,
        courtNumber: court.courtNumber,
        rated: court.team1.length === 2 && court.team2.length === 2,
        status: "pending",
        team1Score: null,
        team2Score: null,
        completedAt: null,
        version: 1,
      }));
      const optimisticMatchPlayers: MatchPlayerRecord[] = proposalToUse.courts.flatMap((court, i) => {
        const matchId = `temp_match_${currentSession.id}_${nextRoundNumber}_${i}`;
        return [
          ...court.team1.map((pId) => ({ matchId, playerId: pId, team: 1 as const, ratingBefore: null, ratingAfter: null })),
          ...court.team2.map((pId) => ({ matchId, playerId: pId, team: 2 as const, ratingBefore: null, ratingAfter: null })),
        ];
      });
      const optimisticStartedRound: StartedRoundRecord = {
        round: {
          id: tempRoundId,
          sessionId: currentSession.id,
          roundNumber: nextRoundNumber,
          status: "started",
          seed: proposalToUse.seed,
          scoreBreakdown: proposalToUse.scoreBreakdown,
          createdAt: latestStarted.round.createdAt,
          startedAt: latestStarted.round.createdAt,
          completedAt: null,
          version: 1,
        },
        matches: optimisticMatches,
        matchPlayers: optimisticMatchPlayers,
        sits: proposalToUse.sitting.map((pId) => ({ roundId: tempRoundId, playerId: pId })),
      };

      setLocalStartedRounds((prev) => [
        ...prev.map((sr) =>
          sr.round.id === latestStarted.round.id
            ? {
                ...sr,
                round: { ...sr.round, status: "completed" as const, completedAt: latestStarted.round.startedAt, version: sr.round.version + 1 },
                matches: sr.matches.map((m) => {
                  const saved = entriesToSave.find((e) => e.matchId === m.id);
                  return saved
                    ? { ...m, status: "completed" as const, team1Score: saved.team1Score, team2Score: saved.team2Score, version: m.version + 1 }
                    : m;
                }),
              }
            : sr
        ),
        optimisticStartedRound,
      ]);
      setCurrentSession((prev) => ({
        ...prev,
        currentRoundNumber: nextRoundNumber,
        version: prev.version + 1,
      }));
      setScoreDrafts({});
    }

    startGeneratingRound(async () => {
      try {
        const res = await saveAndStartNextRoundAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          roundId: latestStarted.round.id,
          roundVersion: latestStarted.round.version,
          results: entriesToSave.map((e) => ({
            matchId: e.matchId,
            team1Score: e.team1Score,
            team2Score: e.team2Score,
            matchVersion: e.version,
          })),
          idempotencyKey: createIdempotencyKey("save_and_start"),
          manualCourts: proposalToUse?.courts.map((c) => ({
            courtNumber: c.courtNumber,
            team1: [...c.team1],
            team2: [...c.team2],
          })),
          manualSitting: proposalToUse?.sitting ? [...proposalToUse.sitting] : undefined,
          seed: proposalToUse?.seed,
        });

        if (res.ok) {
          clearLineupDraft(lineupDraftKey(currentSession.id));
          setLocalStartedRounds((prev) => [
            ...prev.filter((sr) => sr.round.id !== latestStarted.round.id && !sr.round.id.startsWith("temp_")),
            {
              ...latestStarted,
              round: res.data.completedRound,
              matches: latestStarted.matches.map((m) => {
                const saved = entriesToSave.find((e) => e.matchId === m.id);
                return saved
                  ? { ...m, status: "completed" as const, team1Score: saved.team1Score, team2Score: saved.team2Score, version: m.version + 1 }
                  : m;
              }),
            },
            res.data.startedRound,
          ]);
          setCurrentSession((prev) => ({
            ...prev,
            currentRoundNumber: res.data.startedRound.round.roundNumber,
            version: prev.version + 1,
          }));
        } else {
          setLocalStartedRounds(previousRounds);
          setCurrentSession(previousSession);
          setScoreDrafts(previousDrafts);
          reportStartError(res.error);
        }
      } catch {
        setLocalStartedRounds(previousRounds);
        setCurrentSession(previousSession);
        setScoreDrafts(previousDrafts);
        setError("Failed to advance to next round.");
      }
    });
  };


  const handleSaveResult = async (matchId: string, team1Score: number, team2Score: number) => {
    if (!latestStarted) return;
    const match = latestStarted.matches.find((m) => m.id === matchId);
    if (!match) return;

    setSavingMatchIds((prev) => new Set([...prev, matchId]));
    setError(null);
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next[matchId];
      return next;
    });

    try {
      const res = await recordResultAction({
        groupId,
        sessionId: currentSession.id,
        matchId,
        team1Score,
        team2Score,
        matchVersion: match.version,
        idempotencyKey: createIdempotencyKey(`res_${matchId}`),
      });
      if (res.ok) {
        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.map((m) =>
              m.id === matchId
                ? {
                    ...m,
                    status: "completed" as const,
                    team1Score,
                    team2Score,
                    completedAt: res.data?.completedAt ?? m.completedAt ?? new Date(),
                    version: m.version + 1,
                  }
                : m
            ),
          }))
        );
        setScoreDrafts((prev) => {
          const next = { ...prev };
          delete next[matchId];
          return next;
        });
        setPickledMatchId(isPickleScore(team1Score, team2Score) ? matchId : null);
      } else {
        setFieldErrors((prev) => ({
          ...prev,
          [matchId]: res.error,
        }));
      }
    } catch {
      setFieldErrors((prev) => ({
        ...prev,
        [matchId]: "Failed to save match result.",
      }));
    } finally {
      setSavingMatchIds((prev) => {
        const next = new Set(prev);
        next.delete(matchId);
        return next;
      });
    }
  };

  const handleCancelMatch = async (matchId: string) => {
    let matchToCancel: MatchRecord | undefined;
    for (const sr of localStartedRounds) {
      const found = sr.matches.find((m) => m.id === matchId);
      if (found) {
        matchToCancel = found;
        break;
      }
    }
    if (!matchToCancel) return;

    // Optimistically mark as cancelled immediately
    const previousRounds = localStartedRounds;
    setLocalStartedRounds((prev) =>
      prev.map((sr) => ({
        ...sr,
        matches: sr.matches.map((m) =>
          m.id === matchId ? { ...m, status: "cancelled" as const, version: m.version + 1 } : m
        ),
      }))
    );
    setScoreDrafts((prev) => {
      const next = { ...prev };
      delete next[matchId];
      return next;
    });

    setSavingMatchIds((prev) => new Set([...prev, matchId]));
    try {
      const res = await cancelMatchAction({
        groupId,
        sessionId: currentSession.id,
        matchId,
        matchVersion: matchToCancel.version,
        idempotencyKey: createIdempotencyKey(`cancel_${matchId}`),
      });
      if (!res.ok) {
        setLocalStartedRounds(previousRounds);
        setError(res.error);
      }
    } catch {
      setLocalStartedRounds(previousRounds);
      setError("Failed to cancel match.");
    } finally {
      setSavingMatchIds((prev) => {
        const next = new Set(prev);
        next.delete(matchId);
        return next;
      });
    }
  };

  const handleNextRound = () => {
    if (!latestStarted || hasUnsavedScores || isPending) return;
    setError(null);
    const proposalToUse = preGeneratedProposal;
    const previousRounds = localStartedRounds;
    if (proposalToUse) {
      setRegeneratedProposal(proposalToUse);
    }
    setLocalStartedRounds((prev) =>
      prev.map((sr) =>
        sr.round.id === latestStarted.round.id
          ? {
              ...sr,
              round: {
                ...sr.round,
                status: "completed" as const,
                completedAt: latestStarted.round.startedAt,
                version: sr.round.version + 1,
              },
            }
          : sr
      )
    );
    startGeneratingRound(async () => {
      try {
        const res = await completeRoundAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          roundId: latestStarted.round.id,
          roundVersion: latestStarted.round.version,
          idempotencyKey: createIdempotencyKey("next_rd"),
        });
        if (res.ok) {
          if (!proposalToUse) {
            setRegeneratedProposal(null);
          }
        } else {
          setLocalStartedRounds(previousRounds);
          setError(res.error);
        }
      } catch {
        setLocalStartedRounds(previousRounds);
        setError("Failed to advance to next round.");
      }
    });
  };

  const handleUndo = () => {
    if (!latestStarted || isPending) return;
    if (!confirm("Are you sure you want to undo the latest round? This will revert results and ratings.")) {
      return;
    }
    setError(null);
    startGeneratingRound(async () => {
      try {
        const res = await undoLatestRoundAction({
          groupId,
          sessionId: currentSession.id,
          sessionVersion: currentSession.version,
          roundId: latestStarted.round.id,
          roundVersion: latestStarted.round.version,
          idempotencyKey: createIdempotencyKey("undo"),
        });
        if (res.ok) {
          startGeneratingRound(() => {
            setRegeneratedProposal(null);
            setLocalStartedRounds((prev) => prev.filter((r) => r.round.id !== latestStarted.round.id));
            setCurrentSession((prev) => ({
              ...prev,
              currentRoundNumber: Math.max(0, prev.currentRoundNumber - 1),
              version: prev.version + 1,
            }));
            // The revalidating action already returns the fresh server tree.
          });
        } else {
          setError(res.error);
        }
      } catch {
        setError("Failed to undo round.");
      }
    });
  };

  const inProgressMatches = localStartedRounds
    .filter((sr) => sr.round.status === "started")
    .flatMap((sr) =>
      sr.matches.filter(
        (m) => m.status === "pending" && !savingMatchIds.has(m.id)
      )
    );

  const getMatchTeams = (match: MatchRecord) => {
    const sr = localStartedRounds.find((r) => r.matches.some((m) => m.id === match.id));
    if (!sr) return { team1: "Team 1", team2: "Team 2" };
    const t1 = (sr.matchPlayers ?? [])
      .filter((mp) => mp.matchId === match.id && mp.team === 1)
      .map((mp) => playerNames[mp.playerId] ?? mp.playerId);
    const t2 = (sr.matchPlayers ?? [])
      .filter((mp) => mp.matchId === match.id && mp.team === 2)
      .map((mp) => playerNames[mp.playerId] ?? mp.playerId);
    return {
      team1: t1.length > 0 ? t1.join(" & ") : "Team 1",
      team2: t2.length > 0 ? t2.join(" & ") : "Team 2",
    };
  };

  const executeEndSession = async () => {
    setIsPending(true);
    setIsEnding(true);
    setError(null);
    try {
      const res = await endSessionAction({
        groupId,
        sessionId: currentSession.id,
        sessionVersion: currentSession.version,
        idempotencyKey: createIdempotencyKey("end"),
      });
      if (res.ok) {
        markSessionEnded(groupId, currentSession.id);
        setCurrentSession((prev) => ({ ...prev, status: "completed", endedAt: new Date() }));
        setScoreDrafts({});
        setJustEndedSession(true);
        router.refresh();
        return;
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to end session.");
    } finally {
      setIsPending(false);
      setIsEnding(false);
    }
  };

  const handleEndSession = async () => {
    if (inProgressMatches.length > 0) {
      const skipWarning =
        typeof window !== "undefined" &&
        window.localStorage.getItem("pickleball_skip_end_session_in_progress_warning") === "true";

      if (!skipWarning) {
        setShowInProgressModal(true);
        return;
      }
    }

    if (!confirm("End this session? Match history and ratings will be finalized.")) {
      return;
    }
    await executeEndSession();
  };

  const handleConfirmEndSessionWithProgress = async () => {
    if (doNotAskAgain && typeof window !== "undefined") {
      try {
        window.localStorage.setItem("pickleball_skip_end_session_in_progress_warning", "true");
      } catch {
        // ignore storage errors
      }
    }
    setShowInProgressModal(false);
    setScoreDrafts({});
    await executeEndSession();
  };

  const viewerAttendance = currentViewerPlayerId
    ? currentAttendance.find((record) => record.playerId === currentViewerPlayerId) ?? null
    : null;

  /** A player saying they're leaving after this round, or staying after all. */
  const handleSetMyAttendance = async (present: boolean) => {
    if (!currentViewerPlayerId || isMyAttendancePending) return;
    setIsMyAttendancePending(true);
    setMyAttendanceError(null);
    try {
      const res = await setMyAttendanceAction({ groupId, sessionId: currentSession.id, present });
      if (!res.ok) {
        setMyAttendanceError(res.error);
        return;
      }
      setCurrentAttendance((prev) =>
        prev.map((record) => (record.playerId === currentViewerPlayerId ? { ...record, leftRound: res.data.leftRound } : record)),
      );
      router.refresh();
    } catch {
      setMyAttendanceError("Couldn't update your attendance. Please try again.");
    } finally {
      setIsMyAttendancePending(false);
    }
  };

  const handleToggleAttendance = async (playerId: string, currentlyPresent: boolean) => {
    setIsPending(true);
    setError(null);
    try {
      const res = await changeAttendanceAction({
        groupId,
        sessionId: currentSession.id,
        playerId,
        present: !currentlyPresent,
        sessionVersion: currentSession.version,
        idempotencyKey: createIdempotencyKey(`att_${playerId}`),
      });
      if (res.ok) {
        setShowAttendanceRebalancePrompt(true);
        setCurrentAttendance((prev) => {
          const exists = prev.find((a) => a.playerId === playerId);
          if (!exists) {
            return [
              ...prev,
              {
                sessionId: currentSession.id,
                playerId,
                joinedRound: currentSession.currentRoundNumber + 1,
                leftRound: !currentlyPresent ? null : currentSession.currentRoundNumber + 1,
              },
            ];
          }
          return prev.map((a) =>
            a.playerId === playerId
              ? {
                  ...a,
                  leftRound: !currentlyPresent ? null : currentSession.currentRoundNumber + 1,
                }
              : a,
          );
        });
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to update attendance.");
    } finally {
      setIsPending(false);
    }
  };

  const handleAddMidSessionGuest = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = guestName.trim();
    if (!trimmed || isAddingGuest) return;

    setIsAddingGuest(true);
    setError(null);
    try {
      const res = await addSessionGuestAction({
        groupId,
        sessionId: currentSession.id,
        guestName: trimmed,
        gender: guestGender,
        initialRating: guestRating,
      });

      if (res.ok) {
        setShowAttendanceRebalancePrompt(true);
        const newPlayer = res.data;
        setSessionPlayers((prev) => [...prev, newPlayer]);
        setCurrentAttendance((prev) => [
          ...prev,
          {
            sessionId: currentSession.id,
            playerId: newPlayer.id,
            joinedRound: currentSession.currentRoundNumber + 1,
            leftRound: null,
          },
        ]);
        setGuestName("");
        setGuestGender("male");
        setGuestRating(3.5);
        showToast(`Added ${newPlayer.name} to session!`);
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to add guest player.");
    } finally {
      setIsAddingGuest(false);
    }
  };

  const handleHistoricalSaveResult = async (matchId: string, matchVersion: number) => {
    const t1 = parseInt(historicalScores.team1, 10);
    const t2 = parseInt(historicalScores.team2, 10);
    if (isNaN(t1) || isNaN(t2)) return;

    setIsPending(true);
    setError(null);
    try {
      const res = await recordResultAction({
        groupId,
        sessionId: currentSession.id,
        matchId,
        team1Score: t1,
        team2Score: t2,
        matchVersion,
        idempotencyKey: createIdempotencyKey(`hist_${matchId}`),
      });
      if (res.ok) {
        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.map((m) =>
              m.id === matchId
                ? {
                    ...m,
                    team1Score: t1,
                    team2Score: t2,
                    status: "completed" as const,
                    completedAt: res.data?.completedAt ?? m.completedAt ?? new Date(),
                    version: m.version + 1,
                  }
                : m
            ),
          }))
        );
        setEditingHistoricalMatchId(null);
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to update historical score.");
    } finally {
      setIsPending(false);
    }
  };

  const handleHistoricalCancelMatch = async (matchId: string, matchVersion: number) => {
    setIsPending(true);
    setError(null);
    try {
      const res = await cancelMatchAction({
        groupId,
        sessionId: currentSession.id,
        matchId,
        matchVersion,
        idempotencyKey: createIdempotencyKey(`hist_cancel_${matchId}`),
      });
      if (res.ok) {
        setLocalStartedRounds((prev) =>
          prev.map((sr) => ({
            ...sr,
            matches: sr.matches.map((m) =>
              m.id === matchId ? { ...m, status: "cancelled" as const, version: m.version + 1 } : m
            ),
          }))
        );
        setEditingHistoricalMatchId(null);
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to cancel historical match.");
    } finally {
      setIsPending(false);
    }
  };

  // Convert started round matches to MatchScoreEntry
  const scoreEntries: MatchScoreEntry[] = latestStarted
    ? latestStarted.matches.map((match) => {
        const team1Ids = (latestStarted.matchPlayers ?? [])
          .filter((mp) => mp.matchId === match.id && mp.team === 1)
          .map((mp) => mp.playerId);
        const team2Ids = (latestStarted.matchPlayers ?? [])
          .filter((mp) => mp.matchId === match.id && mp.team === 2)
          .map((mp) => mp.playerId);
        const team1Players = team1Ids.map((id) => playerNames[id] ?? id);
        const team2Players = team2Ids.map((id) => playerNames[id] ?? id);

        return {
          id: match.id,
          courtNumber: match.courtNumber,
          team1Names: team1Players.length > 0 ? team1Players : ["Player 1"],
          team2Names: team2Players.length > 0 ? team2Players : ["Player 2"],
          team1PlayerIds: team1Ids,
          team2PlayerIds: team2Ids,
          team1Score: match.team1Score,
          team2Score: match.team2Score,
          status: match.status,
          version: match.version,
          startedAt: latestStarted.round.startedAt,
          completedAt: match.completedAt,
        };
      })
    : [];

  const hasUnsavedScores = Boolean(isRoundInProgress) && scoreEntries.some((match) => {
    const draft = scoreDrafts[match.id];
    if (!draft || match.status === "cancelled") return false;
    const team1 = draft.team1.trim() === "" ? null : Number(draft.team1);
    const team2 = draft.team2.trim() === "" ? null : Number(draft.team2);
    return team1 !== match.team1Score || team2 !== match.team2Score;
  });

  const handleScoreChange = (matchId: string, team: "team1" | "team2", value: string) => {
    const match = scoreEntries.find((entry) => entry.id === matchId);
    if (!match) return;
    setScoreDrafts((previous) => ({
      ...previous,
      [matchId]: {
        ...(previous[matchId] ?? {
          team1: match.team1Score !== null ? String(match.team1Score) : "",
          team2: match.team2Score !== null ? String(match.team2Score) : "",
        }),
        [team]: value,
      },
    }));
  };

  const isCompletedSession = currentSession.status === "completed";
  const allSessionRounds = localStartedRounds;
  const totalSessionMatches = allSessionRounds.reduce((acc, r) => acc + r.matches.length, 0);

  // Calculate participating player statistics for the session
  const attendeePlayerIds = new Set<string>();
  for (const att of currentAttendance) {
    const player = sessionPlayers.find((p) => p.id === att.playerId);
    if (player && !player.active) continue;
    attendeePlayerIds.add(att.playerId);
  }
  for (const sr of allSessionRounds) {
    for (const mp of sr.matchPlayers ?? []) {
      attendeePlayerIds.add(mp.playerId);
    }
    for (const sit of sr.sits ?? []) {
      attendeePlayerIds.add(sit.playerId);
    }
  }

  const sessionPlayerStats = Array.from(attendeePlayerIds)
    .map((pId) => {
      const player = sessionPlayers.find((p) => p.id === pId);
      let gamesPlayed = 0;
      let wins = 0;
      let losses = 0;

      for (const sr of allSessionRounds) {
        for (const m of sr.matches) {
          if (m.status !== "completed" || m.team1Score === null || m.team2Score === null) continue;
          const mp = (sr.matchPlayers ?? []).find((entry) => entry.matchId === m.id && entry.playerId === pId);
          if (!mp) continue;
          gamesPlayed += 1;
          if (
            (mp.team === 1 && m.team1Score > m.team2Score) ||
            (mp.team === 2 && m.team2Score > m.team1Score)
          ) {
            wins += 1;
          } else if (
            (mp.team === 1 && m.team1Score < m.team2Score) ||
            (mp.team === 2 && m.team2Score < m.team1Score)
          ) {
            losses += 1;
          }
        }
      }

      const winRate = gamesPlayed > 0 ? Math.round((wins / gamesPlayed) * 100) : 0;

      return {
        id: pId,
        name: player?.name ?? playerNames[pId] ?? pId,
        gamesPlayed,
        wins,
        losses,
        winRate,
      };
    })
    .sort((a, b) => b.wins - a.wins || b.winRate - a.winRate || a.name.localeCompare(b.name));

  const viewerSessionStats = currentViewerPlayerId
    ? sessionPlayerStats.find((stat) => stat.id === currentViewerPlayerId) ?? {
        id: currentViewerPlayerId,
        name: sessionPlayers.find((p) => p.id === currentViewerPlayerId)?.name ?? playerNames[currentViewerPlayerId] ?? "You",
        gamesPlayed: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
      }
    : null;

  // The viewer's rating before their first rated game and after their last one this session.
  const viewerRatingChange = (() => {
    if (!currentViewerPlayerId) return null;
    const rated = [...localStartedRounds]
      .sort((a, b) => a.round.roundNumber - b.round.roundNumber)
      .flatMap((sr) => sr.matchPlayers)
      .filter((mp) => mp.playerId === currentViewerPlayerId && mp.ratingBefore !== null && mp.ratingAfter !== null);
    if (rated.length === 0) return null;
    return { before: rated[0]!.ratingBefore!, after: rated.at(-1)!.ratingAfter! };
  })();

  let durationFormatted: string | null = null;
  if (session.endedAt && session.startedAt) {
    const startMs = new Date(session.startedAt).getTime();
    const endMs = new Date(session.endedAt).getTime();
    const diffMinutes = Math.max(1, Math.round((endMs - startMs) / (1000 * 60)));
    const hours = Math.floor(diffMinutes / 60);
    const mins = diffMinutes % 60;
    if (hours > 0) {
      durationFormatted = `${hours}h ${mins}m`;
    } else {
      durationFormatted = `${mins}m`;
    }
  }

  const pastRounds = localStartedRounds.filter((r) => r.round.status === "completed");
  const canEditSessionName = Boolean(canManage || isOrganizer || isHost);

  return (
    <div className="space-y-6 text-black">
      {/* Toast Notification */}
      {successToast && (
        <Toast
          role="status"
          onDismiss={() => {
            if (toastTimeoutRef.current !== null) clearTimeout(toastTimeoutRef.current);
            setSuccessToast(null);
          }}
        >
          {successToast}
        </Toast>
      )}

      <ConfirmDialog
        isOpen={matchPendingCancel !== null}
        onClose={() => setMatchPendingCancel(null)}
        onConfirm={() => {
          const matchId = matchPendingCancel?.id;
          setMatchPendingCancel(null);
          if (matchId) void handleCancelMatch(matchId);
        }}
        title={matchPendingCancel ? `Cancel the Court ${matchPendingCancel.courtNumber} game?` : "Cancel this game?"}
        description={matchPendingCancel ? cancelMatchWarning(matchPendingCancel) : ""}
        confirmText="Cancel match"
        cancelText="Keep match"
        confirmDataTestId="confirm-cancel-match"
      />

      {/* Top Header Controls */}
      <div className="flex items-center justify-between gap-1.5 sm:gap-2 flex-nowrap">
        <BackButton
          href={isFromProfile ? "/players" : `/g/${groupId}`}
          label={
            <>
              <span className="sm:hidden">← Back</span>
              <span className="hidden sm:inline">{isFromProfile ? "← Back to Profile" : "← Back to Group"}</span>
            </>
          }
          ariaLabel={isFromProfile ? "Go back to profile" : "Go back"}
          className="relative before:absolute before:inset-x-0 before:-inset-y-2 before:content-[''] inline-flex items-center shrink-0 h-7 sm:h-9 px-2 sm:px-3 rounded-lg sm:rounded-xl bg-white border-2 border-black font-black uppercase text-[10px] sm:text-xs text-black shadow-[1px_1px_0px_0px_#000] sm:shadow-[2px_2px_0px_0px_#000] hover:bg-neutral-50 active:translate-x-0.5 active:translate-y-0.5 transition-transform cursor-pointer"
        />
        {isCompletedSession ? (
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <Badge
              variant="muted"
              data-testid="completed-session-badge"
              className="shrink-0 h-7 sm:h-9 px-2 sm:px-2.5 text-[10px] sm:text-xs font-black uppercase flex items-center"
            >
              <span className="sm:hidden">Completed</span>
              <span className="hidden sm:inline">Completed Session</span>
            </Badge>
            <button
              type="button"
              onClick={() => openSessionSettingsModal("attendance")}
              aria-label="Session Settings"
              className="relative before:absolute before:inset-x-0 before:-inset-y-2 before:content-[''] inline-flex items-center gap-1 sm:gap-1.5 shrink-0 h-7 sm:h-9 px-2 sm:px-2.5 rounded-lg sm:rounded-xl bg-white border-2 border-black font-black uppercase text-[10px] sm:text-xs text-black shadow-[1px_1px_0px_0px_#000] sm:shadow-[2px_2px_0px_0px_#000] hover:bg-neutral-50 active:translate-x-0.5 active:translate-y-0.5 cursor-pointer"
            >
              <GearIcon className="h-3 w-3 sm:h-3.5 sm:w-3.5 shrink-0" />
              <span>
                <span className="sm:hidden">Settings</span>
                <span className="hidden sm:inline">Session Settings</span>
              </span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={() => openSessionSettingsModal("attendance")}
              aria-label="Session Settings"
              className="relative before:absolute before:inset-x-0 before:-inset-y-2 before:content-[''] inline-flex items-center gap-1 sm:gap-1.5 shrink-0 h-7 sm:h-9 px-2 sm:px-2.5 rounded-lg sm:rounded-xl bg-white border-2 border-black font-black uppercase text-[10px] sm:text-xs text-black shadow-[1px_1px_0px_0px_#000] sm:shadow-[2px_2px_0px_0px_#000] hover:bg-neutral-50 active:translate-x-0.5 active:translate-y-0.5 cursor-pointer"
            >
              <GearIcon className="h-3 w-3 sm:h-3.5 sm:w-3.5 shrink-0" />
              <span>
                <span className="sm:hidden">Settings</span>
                <span className="hidden sm:inline">Session Settings</span>
              </span>
            </button>
            {canManage && (
              <button
                type="button"
                onClick={handleEndSession}
                disabled={isPending}
                aria-label="End Session"
                data-testid="end-session-button"
                className="relative before:absolute before:inset-x-0 before:-inset-y-2 before:content-[''] inline-flex items-center shrink-0 h-7 sm:h-9 px-2 sm:px-2.5 rounded-lg sm:rounded-xl bg-[#ff6b6b] border-2 border-black font-black uppercase text-[10px] sm:text-xs text-black shadow-[1px_1px_0px_0px_#000] sm:shadow-[2px_2px_0px_0px_#000] hover:bg-[#ff5252] active:translate-x-0.5 active:translate-y-0.5 cursor-pointer disabled:opacity-60"
              >
                {isEnding ? "Ending..." : (
                  <>
                    <span className="sm:hidden">End</span>
                    <span className="hidden sm:inline">End Session</span>
                  </>
                )}
              </button>
            )}
          </div>
        )}
      </div>

      {/* Active Session Header Card */}
      {!isCompletedSession && (
        <header className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000]">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1 space-y-1">
              <SessionNameEditor
                groupId={groupId}
                sessionId={session.id}
                initialName={initialSessionName}
                canEdit={canEditSessionName}
                headingTag="h2"
                className="font-display text-2xl sm:text-3xl font-black uppercase text-black"
                onRenamed={(newName) => setSessionName(newName)}
              />
              <p className="text-xs font-bold text-neutral-600">
                {groupName ?? "Group"}
                {sessionName ? (
                  <>
                    {" · Started "}
                    <ClientDate date={session.startedAt} />
                  </>
                ) : null}
              </p>
            </div>
            {canManage && (
              <div className="shrink-0">
                <SessionOptionsMenu
                  groupId={groupId}
                  sessionId={session.id}
                  sessionName={sessionName}
                  sessionDate={session.startedAt}
                  redirectTo={isFromProfile ? "/players" : `/g/${groupId}`}
                  onRenamed={(newName) => setSessionName(newName)}
                  onUndoLatestRound={latestStarted ? handleUndo : undefined}
                  latestRoundNumber={latestStarted?.round.roundNumber}
                />
              </div>
            )}
          </div>
        </header>
      )}

      {!activeProposal && initialProposalError && !error && !isOverCapacity && (
        <p role="alert" className="rounded-xl border-2 border-black bg-amber-50 p-4 font-bold">{initialProposalError}</p>
      )}
      {isOverCapacity && canManage && rebalanceChoices.length > 0 && (
        <div
          data-testid="main-guided-court-choice-card"
          className="rounded-2xl border-2 border-black bg-amber-50 p-4 sm:p-5 shadow-[4px_4px_0px_0px_#000] space-y-3.5"
        >
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg">⚠️</span>
              <h4 className="font-display text-sm sm:text-base font-black uppercase tracking-wider text-black">
                Courts Need Adjustment ({presentCount} Present Players)
              </h4>
            </div>
            <p className="text-xs sm:text-sm font-bold text-amber-950 mt-1">
              Your court configuration ({configCapacity} spots) exceeds the {presentCount} currently present players. Pick a setup to continue:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {rebalanceChoices.map((choice) => (
              <button
                key={choice.id}
                type="button"
                onClick={() => handleApplyCourtChoice(choice)}
                disabled={isPending || isCourtConfigPending}
                data-testid={`main-guided-choice-${choice.id}`}
                className="text-left p-3.5 rounded-xl border-2 border-black bg-white hover:bg-[#ccff00]/20 hover:border-black transition-all flex flex-col justify-between gap-2.5 cursor-pointer shadow-[3px_3px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5"
              >
                <div>
                  <div className="flex items-center justify-between gap-1.5 mb-1.5">
                    <span className="font-display text-sm font-black uppercase text-black">
                      {choice.title}
                    </span>
                    <span
                      className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border border-black ${
                        choice.sitting === 0
                          ? "bg-[#ccff00] text-black"
                          : "bg-amber-100 text-amber-950"
                      }`}
                    >
                      {choice.badge}
                    </span>
                  </div>
                  <p className="text-xs font-bold text-neutral-800">{choice.summary}</p>
                </div>
                <div className="flex items-center justify-between text-xs font-bold text-neutral-600 pt-2 border-t border-neutral-200">
                  <span>{choice.details}</span>
                  <span className="font-black text-black">Apply &amp; Generate →</span>
                </div>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={() => {
                setModalTab("court_config");
                setShowSessionSettingsModal(true);
              }}
              className="text-xs font-black uppercase text-neutral-800 hover:text-black underline cursor-pointer"
            >
              Customize court sizes manually →
            </button>
          </div>
        </div>
      )}
      {activeProposal?.sitting.length === 1 && (currentSession.stayTogetherPairs ?? []).some(pair => pair.includes(activeProposal.sitting[0]) && pair.every(id => currentAttendance.some(a => a.playerId === id && a.leftRound === null))) && <p role="status" className="rounded-xl border-2 border-black bg-amber-50 p-3 text-sm font-bold">{playerNames[activeProposal.sitting[0]]} is sitting this round to rotate playing time. Their Stay Together pairing is saved for later rounds.</p>}
      {error && (
        <div role="alert" className="p-4 rounded-xl bg-[#ff6b6b] border-2 border-black shadow-[3px_3px_0px_0px_#000] text-black font-black text-sm">
          {error}
        </div>
      )}

      {/* Main Mode: Completed Session Full View OR Active Round Flow */}
      {isCompletedSession ? (
        <div className="space-y-6" data-testid="completed-session-full-view">
          <div role={justEndedSession ? "status" : undefined} className="flex items-center justify-between gap-3 rounded-xl border-2 border-black bg-[#FFFDF7] px-4 py-2 text-sm font-bold">
            <span>Session complete</span>
            <SessionSignOff play={justEndedSession} groupId={groupId} sessionId={currentSession.id} />
          </div>
          {/* Completed Session Overview Card */}
          <section className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_#000] space-y-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                {groupName && (
                  <span className="text-xs font-black uppercase tracking-wider text-neutral-500 block mb-1">
                    {groupName}
                  </span>
                )}
                <SessionNameEditor
                  groupId={groupId}
                  sessionId={session.id}
                  initialName={initialSessionName}
                  canEdit={canEditSessionName}
                  headingTag="h1"
                  className="font-display text-2xl font-black uppercase text-black"
                  onRenamed={(newName) => setSessionName(newName)}
                />
                {sessionName && (
                  <p className="text-sm font-bold text-neutral-600 mt-1">
                    <ClientDate
                      date={session.startedAt}
                      options={{
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      }}
                    />
                  </p>
                )}
              </div>
              {canManage && (
                <div className="shrink-0">
                  <SessionOptionsMenu
                    groupId={groupId}
                    sessionId={session.id}
                    sessionName={sessionName}
                    sessionDate={session.startedAt}
                    redirectTo={isFromProfile ? "/players" : `/g/${groupId}`}
                    onRenamed={(newName) => setSessionName(newName)}
                  />
                </div>
              )}
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-neutral-50 border-2 border-black rounded-2xl shadow-[2px_2px_0px_0px_#000]">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Courts</span>
                <span className="font-display text-xl font-black text-black">{session.courtCount}</span>
              </div>
              <div className="p-3 bg-neutral-50 border-2 border-black rounded-2xl shadow-[2px_2px_0px_0px_#000]">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Rounds</span>
                <span className="font-display text-xl font-black text-black">{allSessionRounds.length}</span>
              </div>
              <div className="p-3 bg-neutral-50 border-2 border-black rounded-2xl shadow-[2px_2px_0px_0px_#000]">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Total Games</span>
                <span className="font-display text-xl font-black text-black">{totalSessionMatches}</span>
              </div>
              <div className="p-3 bg-neutral-50 border-2 border-black rounded-2xl shadow-[2px_2px_0px_0px_#000]">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Players</span>
                <span className="font-display text-xl font-black text-black">{sessionPlayerStats.length}</span>
              </div>
            </div>

            {/* Personal Session View (when a player is signed in) */}
            {viewerSessionStats && (
              <div
                data-testid="personal-session-summary"
                className="p-4 rounded-2xl border-2 border-black bg-[#ccff00]/25 shadow-[2px_2px_0px_0px_#000] space-y-2"
              >
                <span className="text-xs font-black uppercase tracking-wider text-neutral-800 block">
                  Your Session
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <div className="p-2.5 bg-white border-2 border-black rounded-xl shadow-[1px_1px_0px_0px_#000]">
                    <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Games Won</span>
                    <span className="font-display text-lg font-black text-black">{viewerSessionStats.wins}</span>
                  </div>
                  <div className="p-2.5 bg-white border-2 border-black rounded-xl shadow-[1px_1px_0px_0px_#000]">
                    <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Games Lost</span>
                    <span className="font-display text-lg font-black text-black">{viewerSessionStats.losses}</span>
                  </div>
                  <div className="p-2.5 bg-white border-2 border-black rounded-xl shadow-[1px_1px_0px_0px_#000] col-span-2 sm:col-span-1">
                    <span className="text-[10px] font-black uppercase tracking-wider text-neutral-500 block">Games Played</span>
                    <span className="font-display text-lg font-black text-black">{viewerSessionStats.gamesPlayed}</span>
                  </div>
                </div>
                <p className="text-xs font-bold text-neutral-700">
                  You won {viewerSessionStats.wins} {viewerSessionStats.wins === 1 ? "game" : "games"} and lost {viewerSessionStats.losses} {viewerSessionStats.losses === 1 ? "game" : "games"}.
                </p>
                <p data-testid="personal-rating-change" className="text-sm font-black text-black">
                  {viewerRatingChange
                    ? `Rating ${formatDupr(viewerRatingChange.before)} → ${formatDupr(viewerRatingChange.after)} (${formatDuprDelta(viewerRatingChange.after - viewerRatingChange.before)})`
                    : "No rated doubles games this session, so your rating didn't change."}
                </p>
              </div>
            )}

            {/* Time / Duration info */}
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-bold text-neutral-600 pt-1 border-t-2 border-neutral-100">
              <ClientTime
                date={session.startedAt}
                prefix={<strong className="text-black">Started: </strong>}
              />
              {session.endedAt && (
                <ClientTime
                  date={session.endedAt}
                  prefix={<strong className="text-black">Ended: </strong>}
                />
              )}
              {durationFormatted && (
                <span>
                  <strong className="text-black">Duration:</strong> {durationFormatted}
                </span>
              )}
            </div>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
            {/* Sidebar Column (Right on desktop, first in mobile flow: Highlights & Standings) */}
            <div className="lg:col-span-5 xl:col-span-4 space-y-6 order-1 lg:order-2">
              <SessionHighlights rounds={localStartedRounds} players={sessionPlayers} />

              {/* Session Player Leaderboard / Roster */}
              {sessionPlayerStats.length > 0 && (
                <section className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_#000] space-y-4">
                  <h2 className="font-display text-xl font-black uppercase tracking-wider text-black">
                    Player Summary
                  </h2>
                  <div className="divide-y-2 divide-neutral-100">
                    {sessionPlayerStats.map((stat) => (
                      <div key={stat.id} className="py-2.5 flex items-center justify-between">
                        <div>
                          <span className="font-black text-black text-sm block">{stat.name}</span>
                          <span className="text-xs font-bold text-neutral-500">
                            {stat.gamesPlayed} game{stat.gamesPlayed !== 1 ? "s" : ""} played
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-black px-2 py-0.5 rounded-lg border-2 border-black bg-neutral-50 shadow-[1px_1px_0px_0px_#000]">
                            {stat.wins}W – {stat.losses}L
                          </span>
                          {stat.gamesPlayed > 0 && (
                            <span className="text-xs font-bold text-neutral-600">
                              ({stat.winRate}%)
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </div>

            {/* Primary Column (Left on desktop: All Rounds & Matchups) */}
            <div className="lg:col-span-7 xl:col-span-8 space-y-6 order-2 lg:order-1">
              {/* Categorized Rounds & Games */}
              <section className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_#000] space-y-5">
                <h2 className="font-display text-xl font-black uppercase tracking-wider text-black">
                  All Rounds & Matchups
                </h2>
            {allSessionRounds.length === 0 ? (
              <p className="text-sm font-bold text-neutral-600">No rounds played in this session.</p>
            ) : (
              <div className="space-y-4">
                {allSessionRounds.map((sr) => (
                  <div key={sr.round.id} className="border-2 border-black rounded-2xl p-4 bg-neutral-50 shadow-[3px_3px_0px_0px_#000] space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-display text-base font-black text-black">
                        Round {sr.round.roundNumber}
                      </span>
                      <Badge variant={sr.round.status === "completed" ? "muted" : "warning"}>
                        {sr.round.status === "completed" ? "Completed" : "In Progress"}
                      </Badge>
                    </div>

                    {(sr.sits ?? []).length > 0 && (
                      <p className="text-xs font-bold text-neutral-600">
                        Sitting out: {(sr.sits ?? []).map((s) => playerNames[s.playerId] ?? s.playerId).join(", ")}
                      </p>
                    )}

                    <div className="space-y-2">
                      {sr.matches.map((m) => {
                        const t1 = (sr.matchPlayers ?? [])
                          .filter((mp) => mp.matchId === m.id && mp.team === 1)
                          .map((mp) => playerNames[mp.playerId] ?? mp.playerId);
                        const t2 = (sr.matchPlayers ?? [])
                          .filter((mp) => mp.matchId === m.id && mp.team === 2)
                          .map((mp) => playerNames[mp.playerId] ?? mp.playerId);
                        const isEditing = editingHistoricalMatchId === m.id;
                        const isT1Winner =
                          m.team1Score !== null &&
                          m.team2Score !== null &&
                          m.team1Score > m.team2Score;
                        const isT2Winner =
                          m.team1Score !== null &&
                          m.team2Score !== null &&
                          m.team2Score > m.team1Score;

                        return (
                          <div
                            key={m.id}
                            className="p-3.5 rounded-xl bg-white border-2 border-black shadow-[2px_2px_0px_0px_#000] text-xs space-y-2"
                            data-testid={`completed-match-${m.id}`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1.5">
                                <span className="font-black text-black">Court {m.courtNumber}</span>
                                {m.courtNumber > session.courtCount && (
                                  <Badge variant="muted" className="text-[10px] py-0 px-1.5">
                                    Pickup
                                  </Badge>
                                )}
                              </div>
                              <span className="font-display text-sm font-black text-black">
                                {m.status === "cancelled"
                                  ? "Cancelled"
                                  : m.status === "completed"
                                  ? `${m.team1Score ?? 0} – ${m.team2Score ?? 0}`
                                  : "In Play"}
                              </span>
                            </div>

                            <div className="space-y-1 pt-1">
                              <div className="flex items-center justify-between">
                                <span className={`font-bold ${isT1Winner ? "font-black text-black" : "text-neutral-800"}`}>
                                  {t1.join(" & ") || "Team 1"}
                                </span>
                                <span
                                  className={`font-mono text-xs px-2 py-0.5 rounded border-2 border-black font-black ${
                                    isT1Winner ? "bg-[#ccff00] text-black shadow-[1px_1px_0px_0px_#000]" : "bg-neutral-100 text-neutral-800"
                                  }`}
                                >
                                  {m.team1Score ?? 0}
                                </span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className={`font-bold ${isT2Winner ? "font-black text-black" : "text-neutral-800"}`}>
                                  {t2.join(" & ") || "Team 2"}
                                </span>
                                <span
                                  className={`font-mono text-xs px-2 py-0.5 rounded border-2 border-black font-black ${
                                    isT2Winner ? "bg-[#ccff00] text-black shadow-[1px_1px_0px_0px_#000]" : "bg-neutral-100 text-neutral-800"
                                  }`}
                                >
                                  {m.team2Score ?? 0}
                                </span>
                              </div>
                            </div>

                            {m.status === "completed" && (sr.round.startedAt || m.completedAt || sr.round.completedAt) && (
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-bold text-neutral-500 pt-1 border-t border-neutral-100">
                                {sr.round.startedAt && (
                                  <ClientTime
                                    date={sr.round.startedAt}
                                    prefix={<span className="text-neutral-700 font-black">Started: </span>}
                                  />
                                )}
                                {(m.completedAt ?? sr.round.completedAt) && (
                                  <ClientTime
                                    date={m.completedAt ?? sr.round.completedAt!}
                                    prefix={<span className="text-neutral-700 font-black">Finished: </span>}
                                  />
                                )}
                              </div>
                            )}

                            {isEditing ? (
                              <div className="pt-2 border-t-2 border-neutral-100 flex flex-wrap items-center gap-2">
                                <input
                                  type="number"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  min={0}
                                  value={historicalScores.team1}
                                  onChange={(e) => setHistoricalScores((prev) => ({ ...prev, team1: e.target.value }))}
                                  placeholder="T1"
                                  className="w-16 bg-white border-2 border-black rounded-lg px-2 py-1 text-black font-black text-center text-base shadow-[1px_1px_0px_0px_#000]"
                                />
                                <span className="font-black text-black">–</span>
                                <input
                                  type="number"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  min={0}
                                  value={historicalScores.team2}
                                  onChange={(e) => setHistoricalScores((prev) => ({ ...prev, team2: e.target.value }))}
                                  placeholder="T2"
                                  className="w-16 bg-white border-2 border-black rounded-lg px-2 py-1 text-black font-black text-center text-base shadow-[1px_1px_0px_0px_#000]"
                                />
                                <Button
                                  type="button"
                                  size="sm"
                                  variant="primary"
                                  onClick={() => handleHistoricalSaveResult(m.id, m.version)}
                                  disabled={isPending}
                                  className="font-display text-xs uppercase"
                                >
                                  Save Score
                                </Button>
                                {m.status !== "cancelled" && (
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleHistoricalCancelMatch(m.id, m.version)}
                                    disabled={isPending}
                                    className="font-display text-xs uppercase"
                                  >
                                    Cancel Match
                                  </Button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => setEditingHistoricalMatchId(null)}
                                  className="text-xs font-black uppercase text-neutral-500 hover:text-black underline ml-auto cursor-pointer"
                                >
                                  Close
                                </button>
                              </div>
                            ) : canManage ? (
                              <div className="flex justify-end pt-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingHistoricalMatchId(m.id);
                                    setHistoricalScores({
                                      team1: m.team1Score !== null ? String(m.team1Score) : "",
                                      team2: m.team2Score !== null ? String(m.team2Score) : "",
                                    });
                                  }}
                                  className="text-xs font-black uppercase text-black hover:underline cursor-pointer"
                                >
                                  Edit Result
                                </button>
                              </div>
                            ) : null}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Main Mode: Round In Progress (Score Entry) OR Proposed Round */}
          {isRoundInProgress ? (
            <ResultsEntryView
              pickledMatchId={pickledMatchId}
              roundId={latestStarted.round.id}
              roundNumber={latestStarted.round.roundNumber}
              courtCount={currentSession.courtCount}
              sittingNames={latestStarted?.sits.map((s) => playerNames[s.playerId] ?? s.playerId) ?? []}
              sittingPlayerIds={latestStarted?.sits.map((s) => s.playerId) ?? []}
              viewerPlayerId={currentViewerPlayerId}
              matches={scoreEntries}
              fieldErrors={fieldErrors}
              isPending={isPending}
              savingMatchIds={savingMatchIds}
              onSubmitResult={canManage ? handleSaveResult : undefined}
              onCancelMatch={canManage ? (matchId) => setMatchPendingCancel(scoreEntries.find((m) => m.id === matchId) ?? null) : undefined}
              onNextRound={canManage ? handleNextRound : undefined}
              onReshuffleRound={canManage ? handleReshuffleInProgressRound : undefined}
              isGeneratingRound={isGeneratingRound}
              canManage={canManage}
              scoreDrafts={scoreDrafts}
              onScoreChange={handleScoreChange}
              hasUnsavedScores={hasUnsavedScores}
              onAddGame={canManage ? () => setShowAddPickupModal(true) : undefined}
              onSaveAllScores={canManage ? handleSaveAllScores : undefined}
              onSaveAndStartNextRound={canManage ? handleSaveAndStartNextRound : undefined}
              upcomingProposal={canManage && isHydrated ? preGeneratedProposal : null}
              playerNames={playerNames}
              confirmMatchups={confirmMatchups}
            />
          ) : activeProposal ? (
            <CurrentRoundView
              draftKey={lineupDraftKey(session.id)}
              draftContext={`${currentSession.version}:${(latestStarted?.round.roundNumber ?? 0) + 1}:${JSON.stringify(canonicalPairs(currentSession.stayTogetherPairs ?? []))}`}
              round={{
                id: `proposal_${activeProposal.seed}`,
                roundNumber: (latestStarted?.round.roundNumber ?? 0) + 1,
                status: "proposed",
                seed: activeProposal.seed,
              }}
              courts={activeProposal.courts.map((c) => ({
                courtNumber: c.courtNumber,
                team1: c.team1,
                team2: c.team2,
              }))}
              sittingPlayerIds={activeProposal.sitting}
              playerNames={playerNames}
              playerAccounts={playerAccounts}
              isPending={isPending}
              currentViewerPlayerId={currentViewerPlayerId}
              pairSynergies={pairSynergies}
              isOrganizer={isOrganizer}
              isGeneratingRound={isGeneratingRound}
              canRegenerate={Boolean(canManage)}
              onRegenerate={canManage ? () => handleRegenerate() : undefined}
              onStartRound={canManage ? handleStartRound : undefined}
              canManage={canManage}
              matchmakingVariety={matchmakingVariety}
              onChangeMatchmakingVariety={handleChangeVariety}
              onAddGame={canManage ? () => setShowAddPickupModal(true) : undefined}
              confirmMatchups={confirmMatchups}
            />
          ) : (
            <div className="text-center p-8 bg-white rounded-2xl border-[3px] border-black shadow-[6px_6px_0px_0px_#000] space-y-4">
              <p className="font-display text-xl font-black uppercase text-black">
                {canManage ? "Ready for the next round?" : "Waiting for Next Round"}
              </p>
              {canManage ? (
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <Button type="button" variant="primary" onClick={() => handleRegenerate()} disabled={isPending} className="font-display text-lg uppercase tracking-wider">
                    {isGeneratingRound ? <RoundGenerationIndicator /> : `Generate Round ${(latestStarted?.round.roundNumber ?? 0) + 1}`}
                  </Button>
                  <Button type="button" variant="secondary" onClick={() => setShowAddPickupModal(true)} disabled={isPending} className="font-display text-lg uppercase tracking-wider whitespace-nowrap shrink-0">
                    + Add Game
                  </Button>
                </div>
              ) : (
                <p className="text-sm font-bold text-neutral-600">
                  The organizer has not started the next round yet.
                </p>
              )}
            </div>
          )}

          {/* A player's own way to head home early without leaving the group */}
          {!canManage && viewerAttendance && currentSession.status === "active" && (
            <section
              data-testid="my-attendance"
              className="space-y-3 rounded-2xl border-2 border-black bg-white p-4 shadow-[2px_2px_0px_0px_#000]"
            >
              <p className="text-sm font-bold text-black">
                {viewerAttendance.leftRound === null
                  ? "Heading home early? Let the organizer know and you won't be put in another round."
                  : `You're out from Round ${viewerAttendance.leftRound}. You won't be put in another round.`}
              </p>
              <button
                type="button"
                onClick={() => void handleSetMyAttendance(viewerAttendance.leftRound !== null)}
                disabled={isMyAttendancePending}
                data-testid={viewerAttendance.leftRound === null ? "leave-after-game-button" : "stay-in-session-button"}
                className="inline-flex min-h-11 shrink-0 items-center rounded-xl border-2 border-black bg-[#FFFDF7] px-3 text-xs font-black uppercase text-black shadow-[2px_2px_0px_0px_#000] hover:bg-[#ccff00] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-60 cursor-pointer"
              >
                {isMyAttendancePending
                  ? "Saving…"
                  : viewerAttendance.leftRound === null
                    ? "I'm leaving after this round"
                    : "I'm staying"}
              </button>
              {myAttendanceError && (
                <p role="alert" className="w-full text-xs font-black text-black">{myAttendanceError}</p>
              )}
            </section>
          )}

          {/* Running fairness tally, collapsed by default */}
          {currentSession.status === "active" && localStartedRounds.length > 0 && (
            <PlayCountPanel
              rows={buildPlayCounts(localStartedRounds, currentAttendance)}
              playerNames={playerNames}
              viewerPlayerId={currentViewerPlayerId}
            />
          )}

          {/* Past Rounds Accordion / List */}
          {pastRounds.length > 0 && (
            <section className="bg-[#FFFDF7] border-[3px] border-black rounded-2xl p-5 space-y-4 shadow-[6px_6px_0px_0px_#000] -mt-2">
              <h3 className="font-display text-xl font-black uppercase tracking-wider text-black">
                Past Rounds
              </h3>
              <div className="space-y-4">
                {pastRounds.map((past) => (
                  <div key={past.round.id} className="border-2 border-black rounded-xl p-4 bg-neutral-50 shadow-[3px_3px_0px_0px_#000] space-y-2">
                    <div className="flex items-center justify-between text-xs font-black uppercase">
                      <span className="font-display text-base text-black">Round {past.round.roundNumber}</span>
                      <Badge variant="muted">Completed</Badge>
                    </div>
                    <div className="space-y-2 pt-1">
                      {past.matches.map((m) => {
                        const t1 = (past.matchPlayers ?? [])
                          .filter((mp) => mp.matchId === m.id && mp.team === 1)
                          .map((mp) => playerNames[mp.playerId] ?? mp.playerId);
                        const t2 = (past.matchPlayers ?? [])
                          .filter((mp) => mp.matchId === m.id && mp.team === 2)
                          .map((mp) => playerNames[mp.playerId] ?? mp.playerId);
                        const isEditing = editingHistoricalMatchId === m.id;

                        return (
                          <div key={m.id} className="p-3 rounded-lg bg-[#FFFDF7] border-2 border-black shadow-[2px_2px_0px_0px_#000] text-xs space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-black text-black">Court {m.courtNumber}</span>
                              <span className="font-display text-sm font-black text-black">
                                {m.status === "cancelled" ? "Cancelled" : `${m.team1Score ?? 0} – ${m.team2Score ?? 0}`}
                              </span>
                            </div>
                            <div className="font-bold text-neutral-800">
                              {t1.join(" & ")} vs {t2.join(" & ")}
                            </div>

                            {m.status === "completed" && (past.round.startedAt || m.completedAt || past.round.completedAt) && (
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-bold text-neutral-500 pt-1 border-t border-neutral-100">
                                {past.round.startedAt && (
                                  <ClientTime
                                    date={past.round.startedAt}
                                    prefix={<span className="text-neutral-700 font-black">Started: </span>}
                                  />
                                )}
                                {(m.completedAt ?? past.round.completedAt) && (
                                  <ClientTime
                                    date={m.completedAt ?? past.round.completedAt!}
                                    prefix={<span className="text-neutral-700 font-black">Finished: </span>}
                                  />
                                )}
                              </div>
                            )}

                            {isEditing ? (
                              <div className="pt-2 border-t-2 border-neutral-100 flex flex-wrap items-center gap-2">
                                <input
                                  type="number"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  min={0}
                                  value={historicalScores.team1}
                                  onChange={(e) => setHistoricalScores((prev) => ({ ...prev, team1: e.target.value }))}
                                  placeholder="T1"
                                  className="w-16 bg-white border-2 border-black rounded-lg px-2 py-1 text-black font-black text-center text-base shadow-[1px_1px_0px_0px_#000]"
                                />
                                <span className="font-black text-black">–</span>
                                <input
                                  type="number"
                                  inputMode="numeric"
                                  pattern="[0-9]*"
                                  min={0}
                                  value={historicalScores.team2}
                                  onChange={(e) => setHistoricalScores((prev) => ({ ...prev, team2: e.target.value }))}
                                  placeholder="T2"
                                  className="w-16 bg-white border-2 border-black rounded-lg px-2 py-1 text-black font-black text-center text-base shadow-[1px_1px_0px_0px_#000]"
                                />
                                <Button
                                  type="button"
                                  size="sm"
                                  variant="primary"
                                  onClick={() => handleHistoricalSaveResult(m.id, m.version)}
                                  disabled={isPending}
                                  className="font-display text-xs uppercase"
                                >
                                  Save Score
                                </Button>
                                {m.status !== "cancelled" && (
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleHistoricalCancelMatch(m.id, m.version)}
                                    disabled={isPending}
                                    className="font-display text-xs uppercase"
                                  >
                                    Cancel Match
                                  </Button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => setEditingHistoricalMatchId(null)}
                                  className="text-xs font-black uppercase text-neutral-500 hover:text-black underline ml-auto cursor-pointer"
                                >
                                  Close
                                </button>
                              </div>
                            ) : canManage ? (
                              <div className="flex justify-end pt-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingHistoricalMatchId(m.id);
                                    setHistoricalScores({
                                       team1: m.team1Score !== null ? String(m.team1Score) : "",
                                      team2: m.team2Score !== null ? String(m.team2Score) : "",
                                    });
                                  }}
                                  className="text-xs font-black uppercase text-black hover:underline cursor-pointer"
                                >
                                  Edit Result
                                </button>
                              </div>
                            ) : null}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}

      {/* Session Settings Modal */}
      {showSessionSettingsModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#FFFDF7] border-[3px] border-black rounded-3xl max-w-lg w-full shadow-[8px_8px_0px_0px_#000] max-h-[85vh] flex flex-col overflow-hidden text-black">
            {/* Modal Header & Tabs (Static to box) */}
            <div className="p-6 pb-3 border-b-2 border-neutral-200 shrink-0 space-y-4 bg-[#FFFDF7]">
              <div className="flex items-center justify-between pb-2 border-b-2 border-neutral-100">
                <h3 className="font-display text-2xl font-black uppercase tracking-tight text-black flex items-center gap-2">
                  <GearIcon className="h-6 w-6 text-black shrink-0" />
                  <span>Session Settings</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setShowSessionSettingsModal(false)}
                  className="inline-flex items-center gap-1 text-neutral-600 hover:text-black hover:bg-neutral-100 active:bg-neutral-200 font-black text-sm px-2.5 py-1 -mr-1.5 rounded-xl transition-colors cursor-pointer"
                >
                  <XIcon className="h-4 w-4" />
                  <span>Close</span>
                </button>
              </div>

              {/* Modal Tabs */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Session settings modal tabs">
                <button
                  type="button"
                  role="tab"
                  id="tab-attendance"
                  aria-controls="tabpanel-attendance"
                  aria-selected={modalTab === "attendance"}
                  onClick={() => setModalTab("attendance")}
                  className={`px-3 py-1.5 rounded-xl border-2 font-display text-xs font-black uppercase tracking-wider transition-all cursor-pointer shrink-0 ${
                    modalTab === "attendance"
                      ? "bg-[#ccff00] border-black text-black shadow-[2px_2px_0px_0px_#000]"
                      : "bg-white border-neutral-300 text-neutral-700 hover:border-black"
                  }`}
                >
                  Attendance
                </button>
                {canManage && (
                  <button
                    type="button"
                    role="tab"
                    id="tab-court-config"
                    aria-controls="tabpanel-court-config"
                    aria-selected={modalTab === "court_config"}
                    onClick={() => setModalTab("court_config")}
                    className={`px-3 py-1.5 rounded-xl border-2 font-display text-xs font-black uppercase tracking-wider transition-all cursor-pointer shrink-0 ${
                      modalTab === "court_config"
                        ? "bg-[#ccff00] border-black text-black shadow-[2px_2px_0px_0px_#000]"
                        : "bg-white border-neutral-300 text-neutral-700 hover:border-black"
                    }`}
                  >
                    Court Configuration
                  </button>
                )}
                <button
                  type="button"
                  role="tab"
                  id="tab-partners"
                  aria-controls="tabpanel-partners"
                  aria-selected={modalTab === "partners" || modalTab === "stay_together"}
                  onClick={() => setModalTab("partners")}
                  className={`px-3 py-1.5 rounded-xl border-2 font-display text-xs font-black uppercase tracking-wider transition-all cursor-pointer shrink-0 ${
                    modalTab === "partners" || modalTab === "stay_together"
                      ? "bg-[#ccff00] border-black text-black shadow-[2px_2px_0px_0px_#000]"
                      : "bg-white border-neutral-300 text-neutral-700 hover:border-black"
                  }`}
                >
                  Partners
                </button>
              </div>
            </div>

            {/* Scrollable Tab Content */}
            <div className="p-6 pt-4 flex-1 overflow-y-auto space-y-4">
              {modalTab === "attendance" && (
              <div
                role="tabpanel"
                id="tabpanel-attendance"
                aria-labelledby="tab-attendance"
                className="space-y-4"
              >
                <p className="text-xs font-bold text-neutral-600">
                  {canManage
                    ? "Manage player arrivals or early departures mid-session."
                    : "Session player attendance roster."}
                </p>

                {canManage && (
                  <div className="bg-neutral-50 rounded-xl border-2 border-black shadow-[3px_3px_0px_0px_#000] overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setIsAddGuestOpen((prev) => !prev)}
                      aria-expanded={isAddGuestOpen}
                      aria-controls="session-add-guest-form"
                      data-testid="toggle-session-add-guest"
                      className="w-full flex items-center justify-between text-left cursor-pointer p-3.5 group hover:bg-neutral-100 transition-colors"
                    >
                      <span className="block text-xs font-black uppercase tracking-wider text-black">
                        Add Guest Player
                      </span>
                      <ChevronDownIcon
                        className={`h-4 w-4 text-black transform transition-transform duration-200 shrink-0 ${
                          isAddGuestOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {isAddGuestOpen && (
                      <form
                        id="session-add-guest-form"
                        onSubmit={handleAddMidSessionGuest}
                        className="p-3.5 pt-0 space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row gap-2">
                          <input
                            id="session-guest-name"
                            type="text"
                            aria-label="Guest player name"
                            placeholder="Guest player name"
                            value={guestName}
                            onChange={(e) => setGuestName(e.target.value)}
                            className="flex-1 min-w-0 bg-white border-2 border-black rounded-xl px-3.5 py-2 text-black font-bold placeholder-neutral-400 text-base shadow-[2px_2px_0px_0px_#000] focus:shadow-[4px_4px_0px_0px_#000] focus:outline-none transition-shadow"
                          />
                          <div className="flex items-center gap-2 shrink-0">
                            <CustomDropdown
                              id="session-guest-gender"
                              ariaLabel="Guest Gender"
                              value={guestGender}
                              onChange={(val) => setGuestGender(val as "male" | "female")}
                              options={[
                                { value: "male", label: "Male" },
                                { value: "female", label: "Female" },
                              ]}
                              sizeVariant="sm"
                              className="flex-1 sm:flex-initial shrink-0"
                            />
                            <button
                              type="submit"
                              disabled={!guestName.trim() || isAddingGuest}
                              className="px-5 py-2 rounded-xl border-2 border-black bg-[#ccff00] text-black hover:bg-[#b8e600] text-xs font-black uppercase shadow-[2px_2px_0px_0px_#000] active:translate-x-[1px] active:translate-y-[1px] disabled:opacity-60 cursor-pointer shrink-0 transition-colors"
                            >
                              {isAddingGuest ? "Adding..." : "Add"}
                            </button>
                          </div>
                        </div>
                        <div className="bg-white border-2 border-black rounded-xl p-3 shadow-[2px_2px_0px_0px_#000]">
                          <RatingSlider
                            id="session-guest-rating"
                            dataTestId="session-guest-rating"
                            label="Guest Rating"
                            value={guestRating}
                            onChange={setGuestRating}
                            showDescription={true}
                          />
                        </div>
                      </form>
                    )}
                  </div>
                )}

                {sortedPlayers.length > 5 && (
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                      <SearchIcon className="w-4 h-4" />
                    </span>
                    <input
                      type="text"
                      value={attendanceSearchQuery}
                      onChange={(e) => setAttendanceSearchQuery(e.target.value)}
                      placeholder="Search attendance by name..."
                      aria-label="Search attendance"
                      data-testid="session-attendance-search"
                      className="w-full pl-9 pr-8 py-2 bg-neutral-50 border-2 border-black rounded-xl text-base font-bold text-black placeholder-neutral-400 shadow-[2px_2px_0px_0px_#000] focus:bg-white focus:outline-none focus:shadow-[4px_4px_0px_0px_#000] transition-shadow"
                    />
                    {attendanceSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setAttendanceSearchQuery("")}
                        aria-label="Clear attendance search"
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs font-black text-neutral-500 hover:text-black cursor-pointer"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                )}

                {displayedAttendancePlayers.length === 0 ? (
                  <div className="p-6 text-center rounded-xl border-2 border-dashed border-neutral-300">
                    <p className="text-sm font-bold text-neutral-500">
                      No players match &ldquo;{attendanceSearchQuery}&rdquo;
                    </p>
                    <button
                      type="button"
                      onClick={() => setAttendanceSearchQuery("")}
                      className="mt-2 text-xs font-black uppercase text-black underline cursor-pointer"
                    >
                      Clear search
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {shouldShowRebalancePrompt && canManage && (
                      <div
                        data-testid="guided-court-choice-card"
                        className="p-3 bg-neutral-100 rounded-xl border-2 border-black space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black uppercase text-neutral-700 block">
                            Quick Presets ({presentCount} Present):
                          </span>
                          {!isOverCapacity && (
                            <button
                              type="button"
                              onClick={() => setShowAttendanceRebalancePrompt(false)}
                              className="text-neutral-400 hover:text-black font-black text-xs p-1 cursor-pointer"
                              aria-label="Dismiss court recommendation"
                            >
                              ✕
                            </button>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {rebalanceChoices.map((choice) => {
                            const isCurrent = isChoiceCurrent(choice);
                            return (
                              <button
                                key={choice.id}
                                type="button"
                                onClick={() => handleApplyCourtChoice(choice)}
                                disabled={isPending || isCourtConfigPending || isCurrent}
                                data-testid={`guided-choice-${choice.id}`}
                                className={`px-3 py-2 rounded-lg border-2 border-black text-left cursor-pointer transition-all ${
                                  isCurrent
                                    ? "bg-[#ccff00] text-black shadow-[2px_2px_0px_0px_#000]"
                                    : "bg-white text-neutral-800 hover:bg-neutral-50 shadow-[1px_1px_0px_0px_#000]"
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-display text-xs font-black uppercase">{choice.title}</span>
                                  <span className="text-[10px] font-black">{choice.badge}</span>
                                </div>
                                <span className="text-[11px] font-bold text-neutral-600 block">{choice.summary}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                    {/* Present Section */}
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between pb-1.5 border-b-2 border-black">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-[#ccff00] border border-black shadow-[1px_1px_0px_0px_#000]" />
                          <h4 className="font-display text-xs font-black uppercase tracking-wider text-black">
                            Present ({displayedAttendancePlayers.filter((p) => isPresentNow(p.id)).length})
                          </h4>
                        </div>
                        <span className="text-[11px] font-bold text-neutral-500">
                          Active in matchmaking
                        </span>
                      </div>

                      {presentAttendancePlayers.length === 0 ? (
                        <p className="text-xs font-bold text-neutral-400 italic py-2">
                          No players currently marked present.
                        </p>
                      ) : (
                        <div className="space-y-2" data-testid="attendance-present-list">
                          {presentAttendancePlayers.map((p) => {
                            const rec = currentAttendance.find((a) => a.playerId === p.id);
                            const isPresent = rec ? rec.leftRound === null : false;
                            const isPinned = pinnedPlayerIds.has(p.id);
                            return (
                              <div
                                key={p.id}
                                data-testid={`attendance-row-${p.name}`}
                                className="flex items-center justify-between p-3 bg-[#FFFDF7] rounded-xl border-2 border-black shadow-[3px_3px_0px_0px_#000]"
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  {canManage && (
                                    <button
                                      type="button"
                                      onClick={() => togglePinnedPlayer(groupId, p.id)}
                                      aria-label={isPinned ? `Unpin ${p.name}` : `Pin ${p.name} to top`}
                                      title={isPinned ? "Unpin player" : "Pin player to top"}
                                      data-testid={`pin-player-${p.name}`}
                                      className={`p-1.5 rounded-lg border-2 border-black transition-all cursor-pointer shadow-[1px_1px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 shrink-0 ${
                                        isPinned
                                          ? "bg-black text-[#ccff00] hover:bg-neutral-800"
                                          : "bg-white text-neutral-400 hover:text-black hover:bg-neutral-100"
                                      }`}
                                    >
                                      <PinIcon className="w-3.5 h-3.5" filled={isPinned} />
                                    </button>
                                  )}
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-black text-black text-sm block truncate">{p.name}</span>
                                    </div>
                                    <span className="text-xs font-bold text-neutral-500">Rating: {formatDupr(p.rating)}</span>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  {canManage ? (
                                    <div
                                      role="group"
                                      aria-label={`Attendance for ${p.name}`}
                                      data-testid={`attendance-toggle-${p.name}`}
                                      className="inline-flex items-center rounded-xl border-2 border-black bg-neutral-100 p-0.5 shadow-[2px_2px_0px_0px_#000]"
                                    >
                                      <button
                                        type="button"
                                        onClick={() => {
                                          if (!isPresent) void handleToggleAttendance(p.id, false);
                                        }}
                                        disabled={isPending}
                                        aria-pressed={isPresent}
                                        title="Mark Present"
                                        data-testid={`attendance-present-${p.name}`}
                                        className={`rounded-lg px-2.5 py-1 text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                                          isPresent
                                            ? "bg-[#ccff00] text-black border-2 border-black shadow-[1px_1px_0px_0px_#000]"
                                            : "border-2 border-transparent text-neutral-500 hover:text-black hover:bg-black/5"
                                        } disabled:opacity-60 disabled:cursor-not-allowed`}
                                      >
                                        Present
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          if (isPresent) void handleToggleAttendance(p.id, true);
                                        }}
                                        disabled={isPending}
                                        aria-pressed={!isPresent}
                                        title="Mark as not playing"
                                        data-testid={`attendance-left-${p.name}`}
                                        className={`rounded-lg px-2.5 py-1 text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                                          !isPresent
                                            ? "bg-neutral-300 text-black border-2 border-black shadow-[1px_1px_0px_0px_#000]"
                                            : "border-2 border-transparent text-neutral-500 hover:text-black hover:bg-black/5"
                                        } disabled:opacity-60 disabled:cursor-not-allowed`}
                                      >
                                        {rec ? "Left" : "Not here"}
                                      </button>
                                    </div>
                                  ) : (
                                    <Badge variant={isPresent ? "success" : "muted"}>
                                      {isPresent ? "Present" : rec ? "Left" : "Not here"}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {/* Not Present / Left Section */}
                    <div className="space-y-2.5 pt-2">
                      <div className="flex items-center justify-between pb-1.5 border-b-2 border-neutral-300">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-neutral-300 border border-black shadow-[1px_1px_0px_0px_#000]" />
                          <h4 className="font-display text-xs font-black uppercase tracking-wider text-neutral-700">
                            Not here / Left ({displayedAttendancePlayers.filter((p) => !isPresentNow(p.id)).length})
                          </h4>
                        </div>
                        <span className="text-[11px] font-bold text-neutral-500">
                          Sitting out
                        </span>
                      </div>

                      {notPresentAttendancePlayers.length === 0 ? (
                        <p className="text-xs font-bold text-neutral-400 italic py-2">
                          All players are currently present.
                        </p>
                      ) : (
                        <div className="space-y-2" data-testid="attendance-not-present-list">
                          {notPresentAttendancePlayers.map((p) => {
                            const rec = currentAttendance.find((a) => a.playerId === p.id);
                            const isPresent = rec ? rec.leftRound === null : false;
                            const isPinned = pinnedPlayerIds.has(p.id);
                            return (
                              <div
                                key={p.id}
                                data-testid={`attendance-row-${p.name}`}
                                className="flex items-center justify-between p-3 bg-neutral-50/80 rounded-xl border-2 border-neutral-300 hover:border-black transition-colors"
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  {canManage && (
                                    <button
                                      type="button"
                                      onClick={() => togglePinnedPlayer(groupId, p.id)}
                                      aria-label={isPinned ? `Unpin ${p.name}` : `Pin ${p.name} to top`}
                                      title={isPinned ? "Unpin player" : "Pin player to top"}
                                      data-testid={`pin-player-${p.name}`}
                                      className={`p-1.5 rounded-lg border-2 border-black transition-all cursor-pointer shadow-[1px_1px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 shrink-0 ${
                                        isPinned
                                          ? "bg-black text-[#ccff00] hover:bg-neutral-800"
                                          : "bg-white text-neutral-400 hover:text-black hover:bg-neutral-100"
                                      }`}
                                    >
                                      <PinIcon className="w-3.5 h-3.5" filled={isPinned} />
                                    </button>
                                  )}
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-black text-neutral-700 text-sm block truncate">{p.name}</span>
                                    </div>
                                    <span className="text-xs font-bold text-neutral-400">Rating: {formatDupr(p.rating)}</span>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  {canManage ? (
                                    <div
                                      role="group"
                                      aria-label={`Attendance for ${p.name}`}
                                      data-testid={`attendance-toggle-${p.name}`}
                                      className="inline-flex items-center rounded-xl border-2 border-black bg-neutral-100 p-0.5 shadow-[2px_2px_0px_0px_#000]"
                                    >
                                      <button
                                        type="button"
                                        onClick={() => {
                                          if (!isPresent) void handleToggleAttendance(p.id, false);
                                        }}
                                        disabled={isPending}
                                        aria-pressed={isPresent}
                                        title="Mark Present"
                                        data-testid={`attendance-present-${p.name}`}
                                        className={`rounded-lg px-2.5 py-1 text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                                          isPresent
                                            ? "bg-[#ccff00] text-black border-2 border-black shadow-[1px_1px_0px_0px_#000]"
                                            : "border-2 border-transparent text-neutral-500 hover:text-black hover:bg-black/5"
                                        } disabled:opacity-60 disabled:cursor-not-allowed`}
                                      >
                                        Present
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          if (isPresent) void handleToggleAttendance(p.id, true);
                                        }}
                                        disabled={isPending}
                                        aria-pressed={!isPresent}
                                        title="Mark as not playing"
                                        data-testid={`attendance-left-${p.name}`}
                                        className={`rounded-lg px-2.5 py-1 text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                                          !isPresent
                                            ? "bg-neutral-300 text-black border-2 border-black shadow-[1px_1px_0px_0px_#000]"
                                            : "border-2 border-transparent text-neutral-500 hover:text-black hover:bg-black/5"
                                        } disabled:opacity-60 disabled:cursor-not-allowed`}
                                      >
                                        {rec ? "Left" : "Not here"}
                                      </button>
                                    </div>
                                  ) : (
                                    <Badge variant={isPresent ? "success" : "muted"}>
                                      {isPresent ? "Present" : rec ? "Left" : "Not here"}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {modalTab === "court_config" && canManage && (
              <div
                role="tabpanel"
                id="tabpanel-court-config"
                aria-labelledby="tab-court-config"
                className="space-y-4"
              >
                <p className="text-xs font-bold text-neutral-600">
                  Choose each court&apos;s size. 3-player courts play 2v1 and keep scores without affecting ratings; a 2-player court also keeps scores without affecting ratings.
                </p>

                <div className="flex items-center gap-4">
                  <button
                    type="button"
                    aria-label="Decrease courts"
                    disabled={courtConfigCourts <= 1 || isPending}
                    onClick={decreaseCourts}
                    className="w-12 h-12 rounded-xl bg-white hover:bg-neutral-100 active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-40 disabled:cursor-not-allowed text-2xl font-black text-black flex items-center justify-center border-2 border-black shadow-[3px_3px_0px_0px_#000] cursor-pointer"
                  >
                    -
                  </button>
                  <div className="text-center px-4">
                    <span
                      aria-label="Court count"
                      className="font-display text-4xl font-black text-black"
                    >
                      {courtConfigCourts}
                    </span>
                    <span className="block text-xs uppercase font-black tracking-wider text-neutral-500 mt-0.5">
                      {courtConfigCourts === 1 ? "Court" : "Courts"}
                    </span>
                  </div>
                  <button
                    type="button"
                    aria-label="Increase courts"
                    disabled={courtConfigCourts >= Math.min(32, Math.max(1, Math.floor(presentCount / 2))) || isPending}
                    onClick={increaseCourts}
                    className="w-12 h-12 rounded-xl bg-white hover:bg-neutral-100 active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-40 disabled:cursor-not-allowed text-2xl font-black text-black flex items-center justify-center border-2 border-black shadow-[3px_3px_0px_0px_#000] cursor-pointer"
                  >
                    +
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {courtConfigPlayerCounts.slice(0, courtConfigCourts).map((size, index) => (
                    <div key={index} className="flex items-center justify-between gap-1.5 rounded-xl border-2 border-black p-2 sm:p-2.5 font-bold bg-[#FFFDF7] shadow-[2px_2px_0px_0px_#000]">
                      <span className="text-xs font-black uppercase tracking-wide text-neutral-900 shrink-0">Court {index + 1}</span>
                      <CustomDropdown
                        ariaLabel={`Players on court ${index + 1}`}
                        value={String(size)}
                        onChange={(val) =>
                          handleCourtSizeChange(index, Number(val) as 2 | 3 | 4)
                        }
                        disabled={isPending}
                        align="right"
                        options={[
                          { value: "4", label: "4 players · 2v2" },
                          { value: "3", label: "3 players · 2v1" },
                          { value: "2", label: "2 players · 1v1" },
                        ]}
                        sizeVariant="xs"
                        className="min-w-0 flex-1 max-w-[155px]"
                        buttonClassName="w-full justify-between rounded-lg shadow-[1px_1px_0px_0px_#000] py-1 px-1.5 text-xs"
                      />
                    </div>
                  ))}
                </div>

                {rebalanceChoices.length > 0 && (
                  <div className="p-3 bg-neutral-100 rounded-xl border-2 border-black space-y-2">
                    <span className="text-xs font-black uppercase text-neutral-700 block">
                      Quick Presets ({presentCount} Present):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {rebalanceChoices.map((choice) => (
                        <button
                          key={choice.id}
                          type="button"
                          disabled={isPending || isCourtConfigPending}
                          onClick={() => handleApplyCourtChoice(choice)}
                          data-testid={`preset-choice-${choice.id}`}
                          className={`px-3 py-2 rounded-lg border-2 border-black text-left cursor-pointer transition-all ${
                            isChoiceCurrent(choice)
                              ? "bg-[#ccff00] text-black shadow-[2px_2px_0px_0px_#000]"
                              : "bg-white text-neutral-800 hover:bg-neutral-50 shadow-[1px_1px_0px_0px_#000]"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-display text-xs font-black uppercase">{choice.title}</span>
                            <span className="text-[10px] font-black">{choice.badge}</span>
                          </div>
                          <span className="text-[11px] font-bold text-neutral-600 block">{choice.summary}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {isOverCapacity && (
                  <p className="rounded-lg border border-rose-800 bg-rose-100 px-3 py-2 text-sm font-bold text-rose-950">
                    Total players on courts ({configCapacity}) exceeds present players ({presentCount}). Adjust court sizes or court count.
                  </p>
                )}

                {configSitting > 0 && !isOverCapacity && (
                  <p className="rounded-lg border border-amber-800 bg-amber-100 px-3 py-2 text-sm font-bold text-amber-950">
                    {configSitting} {configSitting === 1 ? "player" : "players"} will sit out each round.
                  </p>
                )}

                <div className="p-4 bg-neutral-50 rounded-2xl border-2 border-black shadow-[2px_2px_0px_0px_#000] space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <label
                        htmlFor="matchup-confirmation-toggle"
                        className="font-display text-sm font-black uppercase text-black block cursor-pointer"
                      >
                        Matchup Confirmation
                      </label>
                      <p className="text-xs font-bold text-neutral-600">
                        Require confirmation before starting rounds. When disabled, hitting Start immediately locks in lineups without extra confirmation prompts.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
                      <input
                        id="matchup-confirmation-toggle"
                        type="checkbox"
                        checked={confirmMatchups}
                        onChange={(e) => handleToggleConfirmMatchups(e.target.checked)}
                        data-testid="confirm-matchups-toggle"
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-black after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black" />
                    </label>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <p className="text-[11px] font-bold text-neutral-500 text-center">
                    Changes save automatically.
                  </p>
                  <Button
                    type="button"
                    onClick={handleSaveCourtConfig}
                    disabled={isPending || isOverCapacity || courtConfigCourts < 1}
                    className="w-full font-display text-sm uppercase"
                  >
                    {isPending ? "Saving..." : "Save Court Configuration"}
                  </Button>
                </div>
              </div>
            )}

            {modalTab === "preferences" && canManage && (
              <div
                role="tabpanel"
                id="tabpanel-preferences"
                aria-labelledby="tab-preferences"
                className="space-y-4"
              >
                <div className="p-4 bg-neutral-50 rounded-2xl border-2 border-black shadow-[2px_2px_0px_0px_#000] space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <label
                        htmlFor="matchup-confirmation-toggle-pref"
                        className="font-display text-sm font-black uppercase text-black block cursor-pointer"
                      >
                        Matchup Confirmation
                      </label>
                      <p className="text-xs font-bold text-neutral-600">
                        Require confirmation before starting rounds. When disabled, hitting Start immediately locks in lineups without extra confirmation prompts.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
                      <input
                        id="matchup-confirmation-toggle-pref"
                        type="checkbox"
                        checked={confirmMatchups}
                        onChange={(e) => handleToggleConfirmMatchups(e.target.checked)}
                        data-testid="confirm-matchups-toggle-pref"
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-black after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black" />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {(modalTab === "partners" || modalTab === "stay_together") && (
              <div
                role="tabpanel"
                id="tabpanel-partners"
                aria-labelledby="tab-partners"
                className="space-y-4"
              >
                {Boolean(currentSession.status === "active" || (currentSession.stayTogetherPairs?.length ?? 0) > 0) && (
                  <StayTogetherEditor
                    players={sessionPlayers}
                    pairs={currentSession.stayTogetherPairs ?? []}
                    eligibleIds={currentAttendance.filter(a => a.leftRound === null && sessionPlayers.some(p => p.id === a.playerId && p.active)).map(a => a.playerId)}
                    onChange={canManage && currentSession.status === "active" ? handleSavePairs : undefined}
                    disabled={isPending}
                    pending={isActionPending}
                  />
                )}
                <PartnerRequests
                  groupId={groupId}
                  session={currentSession}
                  players={sessionPlayers}
                  presentPlayerIds={currentAttendance.filter(a => a.leftRound === null && a.joinedRound <= currentSession.currentRoundNumber + 1 && sessionPlayers.some(p => p.id === a.playerId && p.active)).map(a => a.playerId)}
                  currentViewerPlayerId={currentViewerPlayerId}
                  canManage={canManage}
                  initialRequests={partnerRequests}
                  disabled={isPending}
                  onBusyChange={setRequestPending}
                  onSessionUpdated={applyPartnerSession}
                />
              </div>
            )}
            </div>
          </div>
        </div>
      )}

      {showInProgressModal && (
        <Modal
          isOpen={showInProgressModal}
          onClose={() => !isPending && setShowInProgressModal(false)}
          size="md"
          role="alertdialog"
          showCloseButton={false}
          closeOnBackdropClick={!isPending}
          closeOnEscape={!isPending}
        >
          <div className="space-y-4 text-black" data-testid="in-progress-warning-modal">
            <h3 className="font-display text-xl font-black uppercase tracking-tight text-black">
              End Session?
            </h3>
            <p className="text-sm font-bold text-neutral-800">
              You have these games in progress:
            </p>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1" data-testid="in-progress-match-list">
              {inProgressMatches.map((match) => {
                const { team1, team2 } = getMatchTeams(match);
                return (
                  <div
                    key={match.id}
                    className="p-3 bg-neutral-50 border-2 border-black rounded-xl text-xs flex items-center justify-between shadow-[2px_2px_0px_0px_#000]"
                  >
                    <div>
                      <span className="font-black text-black block">Court {match.courtNumber}</span>
                      <span className="font-bold text-neutral-700">{team1} vs {team2}</span>
                    </div>
                    <Badge variant="warning">In Play</Badge>
                  </div>
                );
              })}
            </div>
            <p className="text-sm font-bold text-neutral-800">
              Are you sure you want to end it?
            </p>
            <label className="flex items-center gap-2 pt-1 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={doNotAskAgain}
                onChange={(e) => setDoNotAskAgain(e.target.checked)}
                data-testid="do-not-ask-again-checkbox"
                className="w-4 h-4 rounded border-2 border-black accent-black cursor-pointer"
              />
              <span className="text-xs font-bold text-neutral-700">
                Do not ask me again
              </span>
            </label>
            <div className="flex gap-3 justify-end pt-3 border-t-2 border-neutral-100">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowInProgressModal(false)}
                disabled={isPending}
                data-testid="cancel-end-session-button"
                className="font-display uppercase tracking-wider text-xs"
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="danger"
                onClick={handleConfirmEndSessionWithProgress}
                disabled={isPending}
                data-testid="confirm-end-session-button"
                className="font-display uppercase tracking-wider text-xs bg-[#ff6b6b] hover:bg-[#ff5252] text-black"
              >
                {isEnding ? "Ending..." : "End Session"}
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {canManage && (
        <AddPickupGameModal
          isOpen={showAddPickupModal}
          onClose={() => setShowAddPickupModal(false)}
          groupId={groupId}
          sessionId={currentSession.id}
          players={sessionPlayers}
          attendance={currentAttendance}
          activeRound={latestStarted}
          activeProposal={activeProposal}
          courtCount={currentSession.courtCount}
          onSuccess={handlePickupGameAdded}
        />
      )}
    </div>
  );
}
