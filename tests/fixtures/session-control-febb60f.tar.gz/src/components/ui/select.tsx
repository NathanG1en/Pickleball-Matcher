import React from "react";

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  sizeVariant?: "sm" | "md";
  hasError?: boolean;
}

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(
  ({ className = "", sizeVariant = "md", hasError, disabled, children, ...props }, ref) => {
    const base =
      "w-full rounded-xl border-2 font-bold text-black focus:outline-none transition-shadow disabled:opacity-50 disabled:cursor-not-allowed";

    const sizeClasses = {
      sm: "pl-3 pr-8 py-2 text-base shadow-[2px_2px_0px_0px_#000] focus:shadow-[4px_4px_0px_0px_#000]",
      md: "pl-4 pr-10 py-3 text-base shadow-[3px_3px_0px_0px_#000] focus:shadow-[5px_5px_0px_0px_#000]",
    };

    const stateClasses = hasError
      ? "border-red-600 bg-red-50 text-black focus:border-red-600"
      : "border-black bg-white";

    return (
      <select
        ref={ref}
        disabled={disabled}
        aria-invalid={hasError ? "true" : props["aria-invalid"]}
        className={`${base} ${sizeClasses[sizeVariant]} ${stateClasses} ${className}`}
        {...props}
      >
        {children}
      </select>
    );
  }
);

Select.displayName = "Select";

