"use client";

import React, { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { CustomDropdown } from "@/components/ui/custom-dropdown";
import {
  TOURNAMENT_DIVISIONS,
  TOURNAMENT_DIVISION_DESCRIPTIONS,
  TOURNAMENT_DIVISION_LABELS,
  type PlayerRecord,
  type TournamentDivision,
} from "@/lib/domain/types";
import { createTournamentAction } from "@/app/actions/tournaments";
import { createPlayerAction } from "@/app/actions/players";
import { MIN_DIVISION_ENTRANTS, createParticipantsForDivision } from "@/lib/tournament/bracket";
import { formatDupr } from "@/lib/domain/rating-display";
import { createIdempotencyKey } from "@/lib/utils/idempotency";
import { RatingSlider } from "@/components/ui/rating-slider";

interface TournamentCreationFormProps {
  readonly groupId: string;
  readonly groupName: string;
  readonly initialPlayers: readonly PlayerRecord[];
}

export function TournamentCreationForm({
  groupId,
  groupName,
  initialPlayers,
}: TournamentCreationFormProps) {
  const router = useRouter();
  const [players, setPlayers] = useState<readonly PlayerRecord[]>(initialPlayers);
  const sortedPlayers = useMemo(
    () =>
      [...players].sort((a, b) =>
        a.name.localeCompare(b.name, undefined, { sensitivity: "base" }),
      ),
    [players],
  );
  const [name, setName] = useState<string>(`${groupName} Championship`);
  // Nothing is pre-selected: the organizer picks the brackets they actually want to run.
  const [selectedDivisions, setSelectedDivisions] = useState<Set<TournamentDivision>>(() => new Set());
  const [selectedPlayerIds, setSelectedPlayerIds] = useState<Set<string>>(
    new Set(initialPlayers.map((p) => p.id)),
  );
  const [guestName, setGuestName] = useState<string>("");
  const [guestGender, setGuestGender] = useState<"male" | "female">("male");
  const [guestRating, setGuestRating] = useState<number>(3.5);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getEntrantCount = (division: TournamentDivision) => {
    const selected = players.filter((p) => selectedPlayerIds.has(p.id));
    return createParticipantsForDivision(division, selected).length;
  };

  // Division selection handlers
  const toggleDivision = (division: TournamentDivision) => {
    setSelectedDivisions((prev) => {
      const next = new Set(prev);
      if (next.has(division)) next.delete(division);
      else next.add(division);
      return next;
    });
  };

  const selectAllDivisions = () => {
    setSelectedDivisions(new Set(TOURNAMENT_DIVISIONS.filter((division) => getEntrantCount(division) >= MIN_DIVISION_ENTRANTS)));
  };

  const clearAllDivisions = () => {
    setSelectedDivisions(new Set());
  };

  // Player selection handlers
  const togglePlayer = (id: string) => {
    setSelectedPlayerIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAllPlayers = () => {
    setSelectedPlayerIds(new Set(players.map((p) => p.id)));
  };

  const clearAllPlayers = () => {
    setSelectedPlayerIds(new Set());
  };

  const handleAddGuest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) return;
    const ratingToAdd = guestRating;
    const genderToAdd = guestGender;

    try {
      const res = await createPlayerAction({
        groupId,
        name: guestName.trim(),
        gender: genderToAdd,
        initialRating: ratingToAdd,
        idempotencyKey: createIdempotencyKey("guest"),
      });

      if (res.ok) {
        const newPlayer: PlayerRecord = {
          ...res.data,
          gender: genderToAdd,
        };
        setPlayers((prev) => [...prev, newPlayer]);
        setSelectedPlayerIds((prev) => new Set([...prev, newPlayer.id]));
        setGuestName("");
        setGuestGender("male");
        setGuestRating(3.5);
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to add player.");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError("Please enter a tournament name.");
      return;
    }

    if (selectedDivisions.size === 0) {
      setError("Please select at least one division.");
      return;
    }

    if (selectedPlayerIds.size < 2) {
      setError("Please select at least 2 players.");
      return;
    }

    const shortDivision = Array.from(selectedDivisions).find((division) => getEntrantCount(division) < MIN_DIVISION_ENTRANTS);
    if (shortDivision) {
      setError(`${TOURNAMENT_DIVISION_LABELS[shortDivision]} needs at least ${MIN_DIVISION_ENTRANTS} eligible entrants. Set player genders on the roster or remove that division.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const playerGenders: Record<string, "male" | "female" | null> = {};
      for (const p of players) {
        playerGenders[p.id] = p.gender ?? null;
      }

      const result = await createTournamentAction({
        groupId,
        name: name.trim(),
        divisions: Array.from(selectedDivisions),
        playerIds: Array.from(selectedPlayerIds),
        playerGenders,
      });

      if (!result.ok) {
        setError(result.error);
        setIsSubmitting(false);
        return;
      }

      router.replace(`/g/${groupId}/tournaments/${result.data.id}`);
    } catch {
      setError("An unexpected error occurred while creating the tournament.");
      setIsSubmitting(false);
    }
  };


  const divisionsCount = selectedDivisions.size;
  const playersCount = selectedPlayerIds.size;

  return (
    <form onSubmit={handleSubmit} className="tournament-creation-form space-y-6 pb-28 text-black">
      {error && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border-2 border-rose-800 text-rose-200 text-sm font-bold shadow-[3px_3px_0px_0px_#000]">
          {error}
        </div>
      )}

      {/* Tournament Details Card */}
      <section className="bg-[#FFFDF7] border-[3px] border-black rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000]">
        <h2 className="font-display text-2xl font-black uppercase text-black mb-1">
          Tournament Details
        </h2>
        <p className="text-sm font-bold text-neutral-600 mb-4">
          Choose a name for this tournament event.
        </p>

        <div>
          <label htmlFor="tournament-name" className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">
            Tournament Name
          </label>
          <input
            id="tournament-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Summer Smash Championship"
            className="w-full bg-white border-2 border-black rounded-xl px-4 py-2.5 text-black font-black text-base shadow-[2px_2px_0px_0px_#000] focus:shadow-[4px_4px_0px_0px_#000] focus:outline-none transition-shadow"
            required
          />
        </div>
      </section>

      {/* Division Selection Card */}
      <section className="bg-[#FFFDF7] border-[3px] border-black rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000]">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-display text-2xl font-black uppercase text-black">Select Divisions</h2>
            <p className="text-sm font-black text-black mt-1">
              <span className="bg-[#ccff00] px-2.5 py-0.5 border border-black rounded-md shadow-[1px_1px_0px_0px_#000]">
                {divisionsCount} division{divisionsCount === 1 ? "" : "s"} selected
              </span>
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={selectAllDivisions}
              className="text-xs font-black uppercase text-black hover:underline p-1 cursor-pointer"
            >
              Select All
            </button>
            <span className="text-black font-bold">|</span>
            <button
              type="button"
              onClick={clearAllDivisions}
              className="text-xs font-black uppercase text-neutral-500 hover:text-black hover:underline p-1 cursor-pointer"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Divisions Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {TOURNAMENT_DIVISIONS.map((division) => {
            const isSelected = selectedDivisions.has(division);
            const entrantCount = getEntrantCount(division);
            const isShort = entrantCount < MIN_DIVISION_ENTRANTS;
            return (
              <label
                key={division}
                htmlFor={`division-check-${division}`}
                className={`flex items-start gap-3 p-3.5 rounded-xl border-2 transition-all select-none ${
                  isSelected
                    ? "bg-[#ccff00] border-black text-black shadow-[3px_3px_0px_0px_#000] cursor-pointer"
                    : isShort
                      ? "bg-neutral-100 border-dashed border-neutral-400 text-neutral-700 cursor-not-allowed"
                      : "bg-[#FFFDF7] border-neutral-300 text-neutral-700 hover:border-black cursor-pointer"
                }`}
              >
                <input
                  id={`division-check-${division}`}
                  type="checkbox"
                  checked={isSelected}
                  disabled={isShort && !isSelected}
                  aria-describedby={isShort ? `division-short-${division}` : undefined}
                  onChange={() => toggleDivision(division)}
                  className="w-5 h-5 rounded border-2 border-black accent-black cursor-pointer mt-0.5"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-black text-base block">{TOURNAMENT_DIVISION_LABELS[division]}</span>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded border border-black/40 bg-white/80 shrink-0">
                      {entrantCount} {entrantCount === 1 ? "entrant" : "entrants"}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-neutral-600 block mt-0.5">
                    {TOURNAMENT_DIVISION_DESCRIPTIONS[division]}
                  </span>
                  {isShort && (
                    <span id={`division-short-${division}`} className="text-xs font-black text-black block mt-1">
                      Needs {MIN_DIVISION_ENTRANTS}+ eligible players
                    </span>
                  )}
                </div>
              </label>
            );
          })}
        </div>
      </section>

      {/* Players Selection Card */}
      <section className="bg-[#FFFDF7] border-[3px] border-black rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000]">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-display text-2xl font-black uppercase text-black">Who is Playing Today?</h2>
            <p className="text-sm font-black text-black mt-1">
              <span className="bg-[#ccff00] px-2.5 py-0.5 border border-black rounded-md shadow-[1px_1px_0px_0px_#000]">
                {playersCount} players selected
              </span>
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={selectAllPlayers}
              className="text-xs font-black uppercase text-black hover:underline p-1 cursor-pointer"
            >
              Select All
            </button>
            <span className="text-black font-bold">|</span>
            <button
              type="button"
              onClick={clearAllPlayers}
              className="text-xs font-black uppercase text-neutral-500 hover:text-black hover:underline p-1 cursor-pointer"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Player Roster Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {sortedPlayers.map((player) => {
            const isSelected = selectedPlayerIds.has(player.id);
            const genderLabel =
              player.gender === "male"
                ? "Male"
                : player.gender === "female"
                  ? "Female"
                  : "No Gender";
            return (
              <label
                key={player.id}
                htmlFor={`player-check-${player.id}`}
                className={`flex items-center gap-3 p-3.5 rounded-xl border-2 transition-all cursor-pointer select-none ${
                  isSelected
                    ? "bg-[#ccff00] border-black text-black shadow-[3px_3px_0px_0px_#000]"
                    : "bg-[#FFFDF7] border-neutral-300 text-neutral-700 hover:border-black"
                }`}
              >
                <input
                  id={`player-check-${player.id}`}
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => togglePlayer(player.id)}
                  className="w-5 h-5 rounded border-2 border-black accent-black cursor-pointer shrink-0"
                />
                <span className="font-black text-base flex-1 min-w-0 truncate text-inherit">
                  {player.name}
                </span>
                <div className="flex flex-col items-end justify-center shrink-0 text-right">
                  <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded border border-black/30 bg-white/80 shrink-0 text-black leading-none mb-1">
                    {genderLabel}
                  </span>
                  <span
                    className={`text-xs font-black leading-tight ${
                      isSelected ? "text-black" : "text-neutral-800"
                    }`}
                  >
                    {formatDupr(player.rating)}
                  </span>
                </div>
              </label>
            );
          })}
        </div>

        {/* Add Guest / Quick Player Form */}
        <div className="mt-4 pt-4 border-t-2 border-neutral-100 space-y-3">
          <label className="block text-xs font-black uppercase tracking-wider text-black">
            Add Guest Player
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              placeholder="Guest player name"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              className="flex-1 min-w-0 bg-white border-2 border-black rounded-xl px-3.5 py-2 text-black font-bold placeholder-neutral-400 text-sm shadow-[2px_2px_0px_0px_#000] focus:shadow-[4px_4px_0px_0px_#000] focus:outline-none transition-shadow"
            />
            <div className="flex items-center gap-2 shrink-0">
              <CustomDropdown
                id="tournament-guest-gender"
                ariaLabel="Guest Gender"
                value={guestGender}
                onChange={(val) => setGuestGender(val as "male" | "female")}
                options={[
                  { value: "male", label: "Male" },
                  { value: "female", label: "Female" },
                ]}
                sizeVariant="sm"
                className="flex-1 sm:flex-initial shrink-0"
              />
              <button
                type="button"
                onClick={handleAddGuest}
                disabled={!guestName.trim()}
                className="px-5 py-2 rounded-xl border-2 border-black bg-[#ccff00] text-black hover:bg-[#b8e600] text-xs font-black uppercase shadow-[2px_2px_0px_0px_#000] active:translate-x-[1px] active:translate-y-[1px] disabled:opacity-60 cursor-pointer shrink-0 transition-colors"
              >
                Add
              </button>
            </div>
          </div>
          <div className="bg-white border-2 border-black rounded-xl p-3 shadow-[2px_2px_0px_0px_#000]">
            <RatingSlider
              id="tournament-guest-rating"
              dataTestId="tournament-guest-rating"
              label="Guest Rating"
              value={guestRating}
              onChange={setGuestRating}
              showDescription={true}
            />
          </div>
        </div>
      </section>

      {/* Sticky Mobile Action Bar */}
      <div className="mobile-action-bar sticky bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-md border-t-[3px] border-black z-40 shadow-[0px_-4px_0px_0px_rgba(0,0,0,0.06)]">
        <div className="max-w-xl mx-auto flex items-center justify-between gap-4">
          <div className="text-left">
            <p className="text-xs uppercase font-black tracking-wider text-neutral-500">Ready</p>
            <p className="font-display text-base font-black uppercase text-black tracking-tight">
              {divisionsCount} division{divisionsCount === 1 ? "" : "s"} · {playersCount} players
            </p>
          </div>
          <Button
            type="submit"
            variant="primary"
            size="lg"
            disabled={divisionsCount === 0 || playersCount < 2 || isSubmitting}
            className="flex-1 max-w-xs font-display text-lg tracking-wide uppercase"
          >
            {isSubmitting ? "Generating..." : "Create Tournament →"}
          </Button>
        </div>
      </div>
    </form>
  );
}

