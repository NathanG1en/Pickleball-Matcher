"use client";

import { useState, useSyncExternalStore } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { playerSignupAction } from "@/app/actions/player-account";
import {
  duprToElo,
} from "@/lib/domain/rating-display";
import {
  Alert,
  Button,
  CustomDropdown,
  FormField,
  Input,
  RatingSlider,
  VisibilityToggle,
} from "@/components/ui";
import { GoogleAuthButton } from "@/components/players/google-auth-button";

const emptySubscribe = () => () => {};

export function PlayerSignupForm({ initialNext }: { initialNext?: string } = {}) {
  const router = useRouter();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [password, setPassword] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [signupRating, setSignupRating] = useState(3.5);
  const [customRating, setCustomRating] = useState(false);
  const [customDuprInput, setCustomDuprInput] = useState("3.5");
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});
  const [pending, setPending] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setPending(true);
    setError(null);
    setFieldErrors({});

    const duprValue = customRating ? Number(customDuprInput) : signupRating;
    if (customRating && (!customDuprInput.trim() || !Number.isFinite(duprValue) || duprValue < 2 || duprValue > 8)) {
      setFieldErrors({ initialRating: ["Enter a rating between 2.0 and 8.0."] });
      setPending(false);
      return;
    }
    const initialRatingElo = duprToElo(duprValue);
    const skillLevel: "beginner" | "intermediate" | "advanced" =
      duprValue < 3.0 ? "beginner" : duprValue < 4.0 ? "intermediate" : "advanced";

    setSignupRating(3.5);

    const result = await playerSignupAction({
      username,
      name,
      email: email.trim() || undefined,
      gender,
      password,
      skillLevel,
      customRating: true,
      initialRating: initialRatingElo,
    });
    if (result.ok) {
      router.push(initialNext ?? getReturnPath() ?? "/players/groups");
      router.refresh();
      return;
    }
    setError(result.error);
    setFieldErrors(result.fieldErrors ?? {});
    setPending(false);
  };

  return (
    <div className="space-y-4">
      <GoogleAuthButton label="Sign up with Google" next={initialNext ?? getReturnPath()} />

      <div className="flex items-center gap-3">
        <div className="h-0.5 flex-1 bg-black/15" />
        <span className="text-xs font-black uppercase tracking-wider text-neutral-500">or register with username</span>
        <div className="h-0.5 flex-1 bg-black/15" />
      </div>

      <form onSubmit={submit} noValidate className="space-y-4 text-left" data-hydrated={mounted ? "true" : undefined}>
      {error && Object.values(fieldErrors).every((messages) => messages.length === 0) && error !== "Please check your player details and try again." && (
        <Alert variant="danger-soft" size="md">
          {error}
        </Alert>
      )}

      <FormField
        id="player-username"
        label="Username"
        error={fieldErrors.username?.[0]}
      >
        <Input
          id="player-username"
          required
          minLength={3}
          maxLength={24}
          pattern="[A-Za-z0-9_]+"
          autoComplete="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          placeholder="Letters, numbers, underscores"
          hasError={Boolean(fieldErrors.username?.length)}
          aria-describedby={fieldErrors.username?.length ? "player-username-error" : undefined}
        />
      </FormField>

      <FormField
        id="player-name"
        label="Display name"
        error={fieldErrors.name?.[0]}
      >
        <Input
          id="player-name"
          required
          maxLength={80}
          autoComplete="name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Name shown to your groups"
          hasError={Boolean(fieldErrors.name?.length)}
          aria-describedby={fieldErrors.name?.length ? "player-name-error" : undefined}
        />
      </FormField>

      <FormField
        id="player-email"
        label="Recovery Email"
        hint="Used to reset your password if you ever forget it."
        error={fieldErrors.email?.[0]}
      >
        <Input
          id="player-email"
          type="email"
          maxLength={254}
          autoComplete="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="you@example.com (recommended)"
          hasError={Boolean(fieldErrors.email?.length)}
          aria-describedby={fieldErrors.email?.length ? "player-email-error" : "player-email-hint"}
        />
      </FormField>

      <FormField
        id="player-gender"
        label="Gender"
        error={fieldErrors.gender?.[0]}
      >
        <CustomDropdown
          id="player-gender"
          name="gender"
          required
          ariaLabel="Gender"
          value={gender}
          onChange={(val) => setGender(val as "male" | "female")}
          hasError={Boolean(fieldErrors.gender?.length)}
          options={[
            { value: "male", label: "Male" },
            { value: "female", label: "Female" },
          ]}
          sizeVariant="md"
          className="w-full"
          buttonClassName="w-full justify-between"
        />
      </FormField>

      <FormField
        id="player-password"
        label="Password"
        hint="At least 10 characters."
        error={fieldErrors.password?.[0]}
      >
        <div className="relative">
          <Input
            id="player-password"
            required
            minLength={10}
            maxLength={72}
            type={passwordVisible ? "text" : "password"}
            autoComplete="new-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            hasError={Boolean(fieldErrors.password?.length)}
            aria-describedby={fieldErrors.password?.length ? "player-password-error" : "player-password-hint"}
            className="pr-14"
          />
          <VisibilityToggle
            visible={passwordVisible}
            onToggle={() => setPasswordVisible((visible) => !visible)}
            label="password"
          />
        </div>
      </FormField>

      <div className="space-y-2">
        <RatingSlider
          id="player-skill"
          label="Starting skill level"
          value={signupRating}
          onChange={(val) => {
            setSignupRating(val);
            if (!customRating) setCustomDuprInput(String(val));
          }}
          disabled={customRating}
          dataTestId="player-skill-slider"
          showDescription={!customRating}
        />
        {fieldErrors.skillLevel?.[0] && (
          <p id="player-skill-error" className="text-xs font-bold text-red-600">
            {fieldErrors.skillLevel[0]}
          </p>
        )}
      </div>

      <label className="flex items-center gap-2 text-sm font-bold text-black">
        <input
          type="checkbox"
          checked={customRating}
          onChange={(event) => {
            setCustomRating(event.target.checked);
            if (!event.target.checked) setCustomDuprInput(String(signupRating));
          }}
          className="h-4 w-4 accent-black"
        />
        Enter custom rating (e.g. 5.0+ or specific rating)
      </label>

      {customRating && (
        <FormField
          id="custom-rating"
          label="Custom rating (2.0 – 8.0)"
          error={fieldErrors.initialRating?.[0]}
        >
          <Input
            id="custom-rating"
            type="number"
            required
            min={2.0}
            max={8.0}
            step={0.001}
            value={customDuprInput}
            onChange={(event) => setCustomDuprInput(event.target.value)}
            hasError={Boolean(fieldErrors.initialRating?.length)}
            aria-describedby={fieldErrors.initialRating?.length ? "custom-rating-error" : undefined}
          />
        </FormField>
      )}

      <Button
        type="submit"
        variant="primary"
        size="lg"
        disabled={pending}
        className="w-full font-display text-lg uppercase"
      >
        {pending ? "Creating account…" : "Sign Up"}
      </Button>

      <p className="text-center text-sm font-bold text-neutral-700">
        Already have an account?{" "}
        <Link
          href="/player-login"
          onClick={(event) => {
            const next = getReturnPath();
            if (next) {
              event.preventDefault();
              router.push(`/player-login?next=${encodeURIComponent(next)}`);
            }
          }}
          className="underline"
        >
          Sign in
        </Link>
      </p>
    </form>
    </div>
  );
}

function getReturnPath(): string | null {
  if (typeof window === "undefined") return null;
  const requested = new URLSearchParams(window.location.search).get("next");
  if (!requested) return null;
  if (requested.startsWith("/") && !requested.startsWith("//") && !requested.includes("\\")) {
    return requested;
  }
  return null;
}
