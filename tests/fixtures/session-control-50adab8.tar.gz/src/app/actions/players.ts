"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { z } from "zod";

import {
  getActionRepository,
  getActiveOrganizerSession,
  getActivePlayerAccountId,
  requireOrganizer,
} from "@/app/actions/action-context";
import type { ActionResult } from "@/app/actions/auth";
import type { PlayerRecord } from "@/lib/domain/types";
import { replayRatings } from "@/lib/domain/rating-replay";
import { resolveProfileVisibility, type SanitizedProfileView } from "@/lib/privacy/profile-visibility";
import {
  createPlayerSchema,
  deletePlayerSchema,
  linkGuestPlayerSchema,
  mergeGuestPlayersSchema,
  updatePlayerSchema,
} from "@/lib/validation/group";

export interface SearchPlayerResult extends SanitizedProfileView {
  readonly alreadyInGroup: boolean;
}

const searchPlayersSchema = z.object({
  query: z.string().trim().min(2, "Search query must be at least 2 characters"),
  groupId: z.string(),
});

const updatePrivacySchema = z.union([
  z.boolean().transform((isPublic) => ({ isPublic })),
  z.object({
    isPublic: z.boolean(),
  }),
]);

const addPlayerByAccountSchema = z.object({
  groupId: z.string(),
  accountId: z.string(),
});

export async function createPlayerAction(input: unknown): Promise<ActionResult<PlayerRecord>> {
  const parsed = createPlayerSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid player data",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    await requireOrganizer(parsed.data.groupId);
    const repository = getActionRepository();
    const newPlayer: PlayerRecord = {
      id: `p_${randomUUID().slice(0, 10)}`,
      groupId: parsed.data.groupId,
      name: parsed.data.name,
      gender: parsed.data.gender ?? null,
      initialRating: parsed.data.initialRating,
      rating: parsed.data.initialRating,
      ratedGamesPlayed: 0,
      active: true,
    };
    await repository.createPlayer(newPlayer);
    revalidatePath(`/g/${parsed.data.groupId}`);
    revalidatePath(`/g/${parsed.data.groupId}/players`);
    revalidatePath("/players");
    return { ok: true, data: newPlayer };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to create player";
    return { ok: false, error: message };
  }
}

export async function updatePlayerAction(input: unknown): Promise<ActionResult> {
  const parsed = updatePlayerSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid player update data",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    await requireOrganizer(parsed.data.groupId);
    const repository = getActionRepository();
    const players = await repository.listPlayers(parsed.data.groupId, { includeInactive: true });
    const target = players.find((p) => p.id === parsed.data.playerId);
    if (!target) {
      return { ok: false, error: "Player not found in group" };
    }
    if (parsed.data.name !== undefined && target.accountId) {
      return { ok: false, error: "Cannot edit the name of a registered player account" };
    }
    if (parsed.data.gender !== undefined && target.accountId) {
      return { ok: false, error: "Cannot edit the gender of a registered player account" };
    }

    await repository.updatePlayer({
      id: parsed.data.playerId,
      groupId: parsed.data.groupId,
      name: parsed.data.name,
      gender: parsed.data.gender,
      active: parsed.data.active,
    });
    revalidatePath(`/g/${parsed.data.groupId}`);
    revalidatePath(`/g/${parsed.data.groupId}/players`);
    revalidatePath("/players");
    return { ok: true, data: undefined };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to update player";
    return { ok: false, error: message };
  }
}

export async function deletePlayerAction(input: unknown): Promise<ActionResult> {
  const parsed = deletePlayerSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid player delete data",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    await requireOrganizer(parsed.data.groupId);
    const repository = getActionRepository();
    await repository.deletePlayer(parsed.data.playerId, parsed.data.groupId);
    revalidatePath(`/g/${parsed.data.groupId}`);
    revalidatePath(`/g/${parsed.data.groupId}/players`);
    revalidatePath(`/g/${parsed.data.groupId}/sessions`);
    return { ok: true, data: undefined };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to delete player";
    return { ok: false, error: message };
  }
}

export async function searchPlayersByUsernameAction(
  input: unknown,
): Promise<ActionResult<readonly SearchPlayerResult[]>> {
  const parsed = searchPlayersSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid search query",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    const repository = getActionRepository();
    const viewerAccountId = await getActivePlayerAccountId();
    const [matchingAccounts, groupPlayers] = await Promise.all([
      repository.searchPlayerAccounts(parsed.data.query, 10),
      repository.listPlayers(parsed.data.groupId),
    ]);

    const groupAccountIds = new Set(
      groupPlayers.map((p) => p.accountId).filter(Boolean) as string[],
    );

    const results: SearchPlayerResult[] = await Promise.all(
      matchingAccounts.map(async (account) => {
        const [bestPartner, pairSynergy] = await Promise.all([
          repository.getBestPartner(account.id),
          viewerAccountId && viewerAccountId !== account.id
            ? repository.getPairSynergy(viewerAccountId, account.id)
            : Promise.resolve(null),
        ]);

        const sanitized = resolveProfileVisibility(viewerAccountId, account, {
          bestPartner,
          viewerSynergyScore: pairSynergy?.synergyScore ?? null,
        });

        return {
          ...sanitized,
          alreadyInGroup: groupAccountIds.has(account.id),
        };
      }),
    );

    return { ok: true, data: results };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to search players";
    return { ok: false, error: message };
  }
}

export async function updatePlayerPrivacyAction(
  input: unknown,
): Promise<ActionResult<void>> {
  const parsed = updatePrivacySchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid privacy setting",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    const accountId = await getActivePlayerAccountId();
    if (!accountId) {
      return { ok: false, error: "You must be signed in to change privacy settings." };
    }
    const repository = getActionRepository();
    await repository.updatePlayerPrivacy(accountId, parsed.data.isPublic);
    try {
      revalidatePath("/players");
    } catch {
      // Non-request test contexts.
    }
    return { ok: true, data: undefined };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to update privacy";
    return { ok: false, error: message };
  }
}

export async function addPlayerByAccountIdAction(
  input: unknown,
): Promise<ActionResult<PlayerRecord>> {
  const parsed = addPlayerByAccountSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid parameters",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    await requireOrganizer(parsed.data.groupId);
    const repository = getActionRepository();
    const player = await repository.addPlayerToGroup(parsed.data.accountId, parsed.data.groupId);
    if (!player) {
      return { ok: false, error: "Failed to add player to group roster." };
    }
    revalidatePath(`/g/${parsed.data.groupId}`);
    revalidatePath(`/g/${parsed.data.groupId}/players`);
    revalidatePath("/players");
    revalidatePath("/players/groups");
    return { ok: true, data: player };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to add player to group";
    return { ok: false, error: message };
  }
}

export async function linkGuestPlayerAction(
  input: unknown,
): Promise<ActionResult<PlayerRecord>> {
  const parsed = linkGuestPlayerSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "Invalid parameters",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    const repository = getActionRepository();
    const group = await repository.getGroup(parsed.data.groupId);
    if (!group) return { ok: false, error: "Group not found." };

    const callerAccountId = await getActivePlayerAccountId();
    const isHost = Boolean(callerAccountId && group.ownerAccountId === callerAccountId);
    const isAccountOrganizer = Boolean(
      callerAccountId && (await repository.isGroupOrganizer(parsed.data.groupId, callerAccountId)),
    );
    const organizerSession = await getActiveOrganizerSession();
    const isSessionOrganizer = Boolean(
      organizerSession && organizerSession.groupId === parsed.data.groupId,
    );

    if (!isHost && !isAccountOrganizer && !isSessionOrganizer) {
      return { ok: false, error: "Only the host or a group organizer can link players." };
    }

    const groupPlayers = await repository.listPlayers(parsed.data.groupId, { includeInactive: true });
    const targetPlayer = groupPlayers.find((p) => p.id === parsed.data.playerId);
    if (!targetPlayer) {
      return { ok: false, error: "Player not found." };
    }
    if (targetPlayer.accountId) {
      return { ok: false, error: "This player is already linked to an account." };
    }
    const targetAccount = await repository.getPlayerAccount(parsed.data.targetAccountId);
    if (!targetAccount) {
      return { ok: false, error: "Player account not found." };
    }

    const linked = await repository.linkGuestPlayer(
      parsed.data.groupId,
      parsed.data.playerId,
      parsed.data.targetAccountId,
    );

    if (!linked) {
      return { ok: false, error: "Unable to link guest player to that account." };
    }

    try {
      await replayRatings(parsed.data.groupId, repository);
    } catch {
      // Replay rating fallback
    }

    revalidatePath(`/g/${parsed.data.groupId}`);
    revalidatePath(`/g/${parsed.data.groupId}/players`);
    revalidatePath("/players");
    revalidatePath("/players/groups");

    return { ok: true, data: linked };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to link guest player";
    return { ok: false, error: message };
  }
}

export async function mergeGuestPlayersAction(
  input: unknown,
): Promise<ActionResult<PlayerRecord>> {
  const parsed = mergeGuestPlayersSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: parsed.error.issues[0]?.message ?? "Invalid parameters",
      fieldErrors: parsed.error.flatten().fieldErrors,
    };
  }

  try {
    const repository = getActionRepository();
    const group = await repository.getGroup(parsed.data.groupId);
    if (!group) return { ok: false, error: "Group not found." };

    const callerAccountId = await getActivePlayerAccountId();
    const isHost = Boolean(callerAccountId && group.ownerAccountId === callerAccountId);
    const isAccountOrganizer = Boolean(
      callerAccountId && (await repository.isGroupOrganizer(parsed.data.groupId, callerAccountId)),
    );
    const organizerSession = await getActiveOrganizerSession();
    const isSessionOrganizer = Boolean(
      organizerSession && organizerSession.groupId === parsed.data.groupId,
    );

    if (!isHost && !isAccountOrganizer && !isSessionOrganizer) {
      return { ok: false, error: "Only the host or a group organizer can merge guest players." };
    }

    const groupPlayers = await repository.listPlayers(parsed.data.groupId, { includeInactive: true });
    const targetPlayer = groupPlayers.find((p) => p.id === parsed.data.targetPlayerId);
    if (!targetPlayer) {
      return { ok: false, error: "Target player not found." };
    }
    if (targetPlayer.accountId) {
      return { ok: false, error: "Registered account players cannot be merged as guests." };
    }

    for (const sourceId of parsed.data.sourcePlayerIds) {
      if (sourceId === targetPlayer.id) continue;
      const sourcePlayer = groupPlayers.find((p) => p.id === sourceId);
      if (!sourcePlayer) {
        return { ok: false, error: `Guest player with ID ${sourceId} not found.` };
      }
      if (sourcePlayer.accountId) {
        return { ok: false, error: "Registered account players cannot be merged as guests." };
      }
    }

    const merged = await repository.mergeGuestPlayers(
      parsed.data.groupId,
      parsed.data.targetPlayerId,
      parsed.data.sourcePlayerIds,
      parsed.data.mergedName,
    );

    revalidatePath(`/g/${parsed.data.groupId}`);
    revalidatePath(`/g/${parsed.data.groupId}/players`);
    revalidatePath("/players");
    revalidatePath("/players/groups");

    return { ok: true, data: merged };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to merge guest players";
    return { ok: false, error: message };
  }
}

