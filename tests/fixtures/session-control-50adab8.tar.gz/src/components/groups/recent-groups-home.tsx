"use client";

import React, { useEffect, useMemo, useSyncExternalStore } from "react";
import Link from "next/link";
import {
  getRecentGroupsSnapshot,
  removeRecentGroup,
  subscribeRecentGroups,
  type RecentGroup,
} from "@/lib/storage/recent-groups";

const emptySubscribe = () => () => {};

export function RecentGroupsHome({
  excludeGroupId,
  memberGroupIds,
}: {
  excludeGroupId?: string;
  memberGroupIds?: string[];
} = {}) {
  const isTest = process.env.NODE_ENV === "test";
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => isTest);

  const json = useSyncExternalStore(
    subscribeRecentGroups,
    getRecentGroupsSnapshot,
    () => (isTest ? getRecentGroupsSnapshot() : "[]")
  );

  const groups: RecentGroup[] = useMemo(() => {
    try {
      const parsed: RecentGroup[] = JSON.parse(json);
      return parsed.filter((g) => {
        if (excludeGroupId && g.id === excludeGroupId) return false;
        if (memberGroupIds && !memberGroupIds.includes(g.id)) return false;
        return true;
      });
    } catch {
      return [];
    }
  }, [json, excludeGroupId, memberGroupIds]);

  useEffect(() => {
    if (!memberGroupIds) return;
    try {
      const parsed: RecentGroup[] = JSON.parse(json);
      const stale = parsed.filter((g) => !memberGroupIds.includes(g.id));
      for (const g of stale) {
        removeRecentGroup(g.id);
      }
    } catch {
      // ignore
    }
  }, [json, memberGroupIds]);

  if (!mounted || !groups || groups.length === 0) {
    return null;
  }

  return (
    <div
      className="p-4 sm:p-5 rounded-2xl bg-[#e0f2fe] border-2 border-black shadow-[4px_4px_0px_0px_#000] text-left space-y-3"
    >
      <div className="flex items-center gap-2">
        <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider text-black bg-white border border-black shadow-[1px_1px_0px_0px_#000]">
          Your Recent Groups ({groups.length})
        </span>
      </div>

      <div className="space-y-2 max-h-48 overflow-y-auto pr-0.5">
        {groups.map((group) => (
          <div
            key={group.id}
            className="p-2.5 rounded-xl bg-white border-2 border-black shadow-[2px_2px_0px_0px_#000] flex items-center justify-between gap-2"
          >
            <div className="min-w-0 flex-1">
              <span className="font-display text-base font-black uppercase text-black block truncate">
                {group.name}
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <Link
                href={`/g/${group.id}`}
                className="px-3 py-1.5 rounded-lg bg-[#ccff00] hover:bg-[#b8eb00] text-black text-xs font-black uppercase border border-black shadow-[1px_1px_0px_0px_#000] active:translate-x-0.5 active:translate-y-0.5 transition-all font-display"
              >
                Open →
              </Link>
              <button
                type="button"
                onClick={() => removeRecentGroup(group.id)}
                title="Forget"
                aria-label={`Forget ${group.name}`}
                className="w-6 h-6 flex items-center justify-center rounded text-neutral-400 hover:text-black font-black text-sm cursor-pointer"
              >
                ×
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
