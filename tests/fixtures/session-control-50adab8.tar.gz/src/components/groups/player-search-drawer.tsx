"use client";

import React, { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  searchPlayersByUsernameAction,
  addPlayerByAccountIdAction,
  type SearchPlayerResult,
} from "@/app/actions/players";
import { Alert, Button, Input } from "@/components/ui";
import { formatDupr, eloToDupr, getSkillTier } from "@/lib/domain/rating-display";
import { LockIcon, HandshakeIcon, ZapIcon, CheckIcon } from "@/components/ui/icons";

interface PlayerSearchDrawerProps {
  readonly groupId: string;
  readonly onPlayerAdded?: (player: { id: string; name: string }) => void;
}

export function PlayerSearchDrawer({ groupId, onPlayerAdded }: PlayerSearchDrawerProps) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<readonly SearchPlayerResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSearching, startSearching] = useTransition();
  const [addingAccountId, setAddingAccountId] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setError("Please enter at least 2 characters.");
      return;
    }
    setError(null);
    startSearching(async () => {
      const res = await searchPlayersByUsernameAction({ query: trimmed, groupId });
      setHasSearched(true);
      if (res.ok) {
        setResults(res.data);
      } else {
        setError(res.error);
        setResults([]);
      }
    });
  };

  const handleAddPlayer = async (accountId: string) => {
    setAddingAccountId(accountId);
    setError(null);
    try {
      const res = await addPlayerByAccountIdAction({ groupId, accountId });
      if (res.ok) {
        setResults((prev) =>
          prev.map((r) => (r.accountId === accountId ? { ...r, alreadyInGroup: true } : r)),
        );
        onPlayerAdded?.(res.data);
        router.refresh();
      } else {
        setError(res.error);
      }
    } catch {
      setError("Failed to add player to group.");
    } finally {
      setAddingAccountId(null);
    }
  };

  return (
    <section className="rounded-3xl border-[3px] border-black bg-white p-5 shadow-[5px_5px_0px_0px_#000]">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-black uppercase">Find & Add Players</h2>
          <p className="text-xs text-neutral-600 font-bold">Search by @username to view chemistry and add to roster</p>
        </div>
      </div>

      <form onSubmit={handleSearch} className="flex gap-2">
        <Input
          type="text"
          sizeVariant="sm"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            if (error) setError(null);
          }}
          placeholder="Search by @username or name..."
          className="flex-1"
        />
        <Button
          type="submit"
          size="sm"
          variant="primary"
          disabled={isSearching}
        >
          {isSearching ? "Searching..." : "Search"}
        </Button>
      </form>

      {error && (
        <Alert variant="danger-soft" size="sm" className="mt-3">
          {error}
        </Alert>
      )}

      {hasSearched && results.length === 0 && !isSearching && !error && (
        <p className="mt-4 text-center text-xs font-bold text-neutral-500">
          No players found matching &ldquo;{query}&rdquo;.
        </p>
      )}

      {results.length > 0 && (
        <ul className="mt-4 space-y-3">
          {results.map((player) => (
            <li
              key={player.accountId}
              className="rounded-2xl border-2 border-black bg-neutral-50 p-3 shadow-[3px_3px_0px_0px_#000]"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-sm">{player.name}</span>
                    <span className="rounded-md border border-neutral-400 bg-neutral-200 px-1.5 py-0.5 text-[10px] font-bold text-neutral-700">
                      @{player.username}
                    </span>
                    {player.isRestricted && (
                      <span className="inline-flex items-center gap-1 rounded-full border border-neutral-300 bg-neutral-100 px-2 py-0.5 text-[10px] font-bold text-neutral-600">
                        <LockIcon className="h-3 w-3 shrink-0" />
                        <span>Private Profile</span>
                      </span>
                    )}
                  </div>

                  {!player.isRestricted && (
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-neutral-600 font-bold">
                      {player.rating !== undefined && (
                        <span>Rating: {formatDupr(player.rating)}</span>
                      )}
                      {player.rating !== undefined && (
                        <span>· {getSkillTier(eloToDupr(player.rating)).name}</span>
                      )}
                      {player.bestPartner && (
                        <span className="inline-flex items-center gap-1 text-amber-700">
                          <span>·</span>
                          <HandshakeIcon className="h-3 w-3 shrink-0" />
                          <span>Best: @{player.bestPartner.username} ({player.bestPartner.synergyScore > 0 ? `+${player.bestPartner.synergyScore}%` : `${player.bestPartner.synergyScore}%`} synergy)</span>
                        </span>
                      )}
                      {player.viewerSynergyScore !== null && player.viewerSynergyScore !== undefined && (
                        <span className="inline-flex items-center gap-1 text-emerald-700">
                          <span>·</span>
                          <ZapIcon className="h-3 w-3 shrink-0" />
                          <span>Chemistry with you: {player.viewerSynergyScore > 0 ? `+${player.viewerSynergyScore}%` : `${player.viewerSynergyScore}%`}</span>
                        </span>
                      )}
                    </div>
                  )}

                  {player.isRestricted && (
                    <p className="mt-1 text-[11px] font-bold text-neutral-500">
                      This player&apos;s ratings and chemistry stats are private.
                    </p>
                  )}
                </div>

                <button
                  type="button"
                  disabled={player.alreadyInGroup || addingAccountId === player.accountId}
                  onClick={() => handleAddPlayer(player.accountId)}
                  className={`whitespace-nowrap rounded-xl border-2 border-black px-3 py-1.5 text-xs font-black uppercase shadow-[2px_2px_0px_0px_#000] active:translate-x-[1px] active:translate-y-[1px] disabled:opacity-60 disabled:shadow-none ${
                    player.alreadyInGroup
                      ? "bg-neutral-200 text-neutral-600"
                      : "bg-[#ccff00] hover:bg-[#b8e600]"
                  }`}
                >
                  {player.alreadyInGroup ? (
                    <span className="inline-flex items-center gap-1">
                      <span>In Group</span>
                      <CheckIcon className="h-3 w-3 shrink-0" />
                    </span>
                  ) : addingAccountId === player.accountId ? (
                    "Adding..."
                  ) : (
                    "Add to Group"
                  )}
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
