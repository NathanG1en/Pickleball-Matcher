"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import { Button, ConfirmDialog, Input, Label } from "@/components/ui";
import { formatDupr, eloToDupr, getSkillTier, duprToElo } from "@/lib/domain/rating-display";
import type { PlayerRecord } from "@/lib/domain/types";

export interface PlayerRosterProps {
  readonly groupId: string;
  readonly players: readonly PlayerRecord[];
  readonly isPending?: boolean;
  readonly onAddPlayer?: (name: string, initialRating: number, gender?: "male" | "female") => void;
  readonly onDeletePlayer?: (player: PlayerRecord) => void;
  readonly canManage?: boolean;
}

export function PlayerRoster({
  players,
  isPending = false,
  onAddPlayer,
  onDeletePlayer,
  canManage = true,
}: PlayerRosterProps) {
  const sortedPlayers = useMemo(
    () =>
      [...players].sort((a, b) =>
        a.name.localeCompare(b.name, undefined, { sensitivity: "base" }),
      ),
    [players],
  );
  const [name, setName] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [selectedPreset, setSelectedPreset] = useState("3.5");
  const [customRating, setCustomRating] = useState(false);
  const [customRatingInput, setCustomRatingInput] = useState("3.5");
  const [playerToDelete, setPlayerToDelete] = useState<PlayerRecord | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && onAddPlayer) {
      const dupr = customRating ? parseFloat(customRatingInput) || 3.5 : parseFloat(selectedPreset);
      const elo = duprToElo(dupr);
      onAddPlayer(name.trim(), elo, gender);
      setName("");
      setGender("male");
      setSelectedPreset("3.5");
      setCustomRating(false);
      setCustomRatingInput("3.5");
    }
  };

  const showAddForm = canManage && Boolean(onAddPlayer);
  const showDelete = canManage && Boolean(onDeletePlayer);

  return (
    <div className="player-roster space-y-6">
      {/* Add Player Form */}
      {showAddForm && (
        <section className="bg-white border-[3px] border-black rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] text-black">
          <h2 className="font-display text-2xl font-black uppercase text-black mb-1">Add Player</h2>
          <p className="text-xs font-bold text-neutral-600 mb-4">
            Add a regular player to your group&apos;s roster.
          </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="player-name-input">
              Player Name
            </Label>
            <Input
              id="player-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jordan Smith"
            />
          </div>

          <div>
            <label htmlFor="player-gender-select" className="block text-xs uppercase font-black tracking-wider text-black mb-1.5">
              Gender
            </label>
            <select
              id="player-gender-select"
              value={gender}
              onChange={(e) => setGender(e.target.value as "male" | "female")}
              className="w-full bg-white border-2 border-black rounded-xl px-4 py-2.5 text-black font-bold shadow-[3px_3px_0px_0px_#000] focus:shadow-[5px_5px_0px_0px_#000] focus:outline-none transition-shadow cursor-pointer"
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>

          <div>
            <label htmlFor="player-rating-select" className="block text-xs uppercase font-black tracking-wider text-black mb-1.5">
              Initial Skill Level
            </label>
            <select
              id="player-rating-select"
              value={selectedPreset}
              disabled={customRating}
              onChange={(e) => {
                setSelectedPreset(e.target.value);
                if (!customRating) setCustomRatingInput(e.target.value);
              }}
              className="w-full bg-white border-2 border-black rounded-xl px-4 py-2.5 text-black font-bold shadow-[3px_3px_0px_0px_#000] focus:shadow-[5px_5px_0px_0px_#000] focus:outline-none transition-shadow disabled:opacity-60"
            >
              <option value="2.0">Beginner Level (2.0 – 2.499)</option>
              <option value="2.5">Advanced Beginner Level (2.5 – 2.999)</option>
              <option value="3.0">Intermediate Level (3.0 – 3.499)</option>
              <option value="3.5">Advanced Intermediate Level (3.5 – 3.999)</option>
              <option value="4.0">Competitive Level (4.0 – 4.499)</option>
              <option value="4.5">Advanced Competitive Level (4.5 – 4.999)</option>
            </select>

            <label className="flex items-center gap-2 text-xs font-bold text-black mt-2">
              <input
                type="checkbox"
                checked={customRating}
                onChange={(e) => {
                  setCustomRating(e.target.checked);
                  if (!e.target.checked) setCustomRatingInput(selectedPreset);
                }}
                className="h-4 w-4 accent-black"
              />
              Enter custom rating (e.g. 5.0+)
            </label>

            {customRating && (
              <div className="mt-2">
                <Input
                  id="custom-player-rating"
                  type="number"
                  min={2.0}
                  max={8.0}
                  step={0.001}
                  value={customRatingInput}
                  onChange={(e) => setCustomRatingInput(e.target.value)}
                  placeholder="e.g. 5.25"
                />
              </div>
            )}
          </div>

          <Button type="submit" variant="primary" disabled={!name.trim() || isPending} className="font-display text-base uppercase tracking-wider">
            Add Player
          </Button>
        </form>
      </section>
      )}

      {/* Roster List */}
      <section className="bg-white border-[3px] border-black rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_0px_#000] text-black">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-2xl font-black uppercase text-black">Group Roster ({players.length})</h2>
        </div>

        <div className="divide-y-2 divide-neutral-100">
          {sortedPlayers.map((player) => (
            <div key={player.id} className="py-3 flex items-center justify-between">
              <div>
                <span className="font-black text-black text-base block">
                  {player.name}
                  {player.username ? (
                    <>
                      {" "}
                      (
                      <Link
                        href={`/players/${encodeURIComponent(player.username)}`}
                        className="underline hover:text-black cursor-pointer"
                      >
                        @{player.username}
                      </Link>
                      )
                    </>
                  ) : (
                    ""
                  )}
                  {player.gender && (
                    <span className="ml-2 rounded border border-black/40 bg-neutral-100 px-1.5 py-0.5 text-[9px] font-black uppercase text-neutral-800 align-middle">
                      {player.gender}
                    </span>
                  )}
                </span>
                <span className="text-xs font-bold text-neutral-600 block mt-0.5">
                  Rating: {formatDupr(player.rating)} ({getSkillTier(eloToDupr(player.rating)).name}) · {player.ratedGamesPlayed} games played
                </span>
              </div>
              <div className="flex items-center gap-3">
                {!canManage && player.username && (
                  <Link
                    href={`/players/${encodeURIComponent(player.username)}`}
                    className="rounded-lg border-2 border-black bg-white px-2.5 py-1 text-[11px] font-black uppercase text-black shadow-[1.5px_1.5px_0px_0px_#000] hover:bg-[#ccff00] active:translate-x-0.5 active:translate-y-0.5 transition-transform shrink-0 mr-2"
                  >
                    View profile
                  </Link>
                )}
                {showDelete && (
                  <button
                    type="button"
                    onClick={() => setPlayerToDelete(player)}
                    disabled={isPending}
                    className="text-xs font-black uppercase text-rose-600 hover:text-rose-800 hover:underline cursor-pointer"
                  >
                    Delete
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Delete Confirmation Modal */}
      <ConfirmDialog
        isOpen={Boolean(showDelete && playerToDelete)}
        onClose={() => setPlayerToDelete(null)}
        onConfirm={() => {
          if (playerToDelete && onDeletePlayer) {
            onDeletePlayer(playerToDelete);
            setPlayerToDelete(null);
          }
        }}
        title="Are you sure?"
        description={
          !playerToDelete?.accountId ? (
            `Are you sure you want to remove "${playerToDelete?.name}"? They have played ${playerToDelete?.ratedGamesPlayed ?? 0} ${(playerToDelete?.ratedGamesPlayed ?? 0) === 1 ? "game" : "games"}.`
          ) : (
            <>
              Are you sure you want to delete <span className="font-black text-black">{playerToDelete?.name}</span> from the roster?
            </>
          )
        }
        confirmText="Delete"
        cancelText="Cancel"
        confirmVariant="danger"
        disabled={isPending}
      />
    </div>
  );
}
