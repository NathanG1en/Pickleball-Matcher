import { z } from "zod";

import { entityIdSchema } from "@/lib/validation/group";

const aggregateVersionSchema = z.coerce.number().int().positive();
const idempotencyKeySchema = entityIdSchema;

export const stayTogetherPairsSchema = z.array(z.tuple([entityIdSchema, entityIdSchema])).max(12);

export const updateStayTogetherPairsSchema = z.object({
  groupId: entityIdSchema, sessionId: entityIdSchema, sessionVersion: aggregateVersionSchema, pairs: stayTogetherPairsSchema,
}).strict();

export const startSessionSchema = z
  .object({
    groupId: entityIdSchema,
    courtCount: z.coerce.number().int().min(1).max(6),
    courtPlayerCounts: z.array(z.coerce.number().int().min(2).max(4)).max(6).optional(),
    playerIds: z.array(entityIdSchema).min(2).max(24),
    stayTogetherPairs: stayTogetherPairsSchema.optional(),
    idempotencyKey: idempotencyKeySchema,
  })
  .strict()
  .refine(({ playerIds }) => new Set(playerIds).size === playerIds.length, {
    path: ["playerIds"],
    message: "Players must be unique",
  })
  .refine(({ courtCount, courtPlayerCounts, playerIds }) =>
    !courtPlayerCounts || (courtPlayerCounts.length === courtCount && courtPlayerCounts.reduce((sum, size) => sum + size, 0) <= playerIds.length), {
      path: ["courtPlayerCounts"],
      message: "Court sizes must match the court count and cannot exceed the selected players.",
    });

export const changeAttendanceSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    playerId: entityIdSchema,
    present: z.boolean(),
    sessionVersion: aggregateVersionSchema,
    idempotencyKey: idempotencyKeySchema,
  })
  .strict();

export const proposeRoundSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    sessionVersion: aggregateVersionSchema,
    seed: z.coerce.number().int().min(0).max(0xffff_ffff).optional(),
    temperature: z.coerce.number().min(0).max(2).optional(),
  })
  .strict();

export const manualCourtSchema = z
  .object({
    courtNumber: z.coerce.number().int().positive(),
    team1: z.array(entityIdSchema).min(1).max(2),
    team2: z.array(entityIdSchema).min(1).max(2),
  })
  .strict()
  .refine(({ team1, team2 }) => team1.length + team2.length !== 3 || (team1.length === 2 || team2.length === 2), {
    message: "A court must be 1v1, 2v2, or 2v1.",
  });

export const startRoundSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    sessionVersion: aggregateVersionSchema,
    seed: z.coerce.number().int().min(0).max(0xffff_ffff),
    idempotencyKey: idempotencyKeySchema,
    manualCourts: z.array(manualCourtSchema).optional(),
    manualSitting: z.array(entityIdSchema).optional(),
  })
  .strict()
  .refine(
    ({ manualCourts, manualSitting }) => {
      if (!manualCourts && !manualSitting) return true;
      if (!manualCourts || !manualSitting) return false;
      const allPlayers = [
        ...manualCourts.flatMap((c) => [...c.team1, ...c.team2]),
        ...manualSitting,
      ];
      return new Set(allPlayers).size === allPlayers.length;
    },
    {
      message: "All players across courts and sitting must be unique",
    },
  );

const existingSessionMutation = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    sessionVersion: aggregateVersionSchema,
    idempotencyKey: idempotencyKeySchema,
  })
  .strict();

export const completeRoundSchema = existingSessionMutation.extend({
  roundId: entityIdSchema,
  roundVersion: aggregateVersionSchema,
});

export const undoLatestRoundSchema = existingSessionMutation.extend({
  roundId: entityIdSchema,
  roundVersion: aggregateVersionSchema,
});

export const reshuffleRoundSchema = existingSessionMutation.extend({
  roundId: entityIdSchema,
  roundVersion: aggregateVersionSchema,
  seed: z.coerce.number().int().min(0).max(0xffff_ffff).optional(),
  temperature: z.coerce.number().min(0).max(2).optional(),
});

export const endSessionSchema = existingSessionMutation;

export const updateSessionNameSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    name: z.string().trim().min(1, "Session name cannot be blank.").max(80, "Session name must be 80 characters or fewer."),
  })
  .strict();

export const deleteSessionSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
  })
  .strict();

export const duplicateSessionSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
  })
  .strict();

export const updateCourtConfigSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    sessionVersion: aggregateVersionSchema,
    courtCount: z.coerce.number().int().min(1).max(6),
    courtPlayerCounts: z.array(z.coerce.number().int().min(2).max(4)).max(6).optional(),
    idempotencyKey: idempotencyKeySchema,
  })
  .strict()
  .refine(
    ({ courtCount, courtPlayerCounts }) =>
      !courtPlayerCounts || courtPlayerCounts.length === courtCount,
    {
      path: ["courtPlayerCounts"],
      message: "Court sizes must match the court count.",
    },
  );

export const submitSessionPickupGameSchema = z
  .object({
    groupId: entityIdSchema,
    sessionId: entityIdSchema,
    team1PlayerIds: z.array(entityIdSchema).min(1).max(2),
    team2PlayerIds: z.array(entityIdSchema).min(1).max(2),
    team1Score: z.coerce.number().int().min(0, "Scores cannot be negative.").max(99, "Scores must be under 100."),
    team2Score: z.coerce.number().int().min(0, "Scores cannot be negative.").max(99, "Scores must be under 100."),
    rated: z.boolean().optional().default(true),
  })
  .strict()
  .refine((data) => data.team1Score !== data.team2Score, {
    path: ["team2Score"],
    message: "Ties are not allowed. Please enter winning and losing scores.",
  })
  .refine(
    (data) => {
      const all = [...data.team1PlayerIds, ...data.team2PlayerIds];
      return new Set(all).size === all.length;
    },
    {
      path: ["team2PlayerIds"],
      message: "A player cannot be selected more than once in the same game.",
    },
  );

export type SubmitSessionPickupGameInput = z.infer<typeof submitSessionPickupGameSchema>;


